/*
 * Created on Dec 4, 2004
 */
package com.lamsinternational.lams.learningdesign.dao;

import java.util.List;

import com.lamsinternational.lams.learningdesign.LearningDesign;
;
/**
 * @author manpreet
 */
public interface ILearningDesignDAO extends IBaseDAO{
	
	/**
	 * @param learningDesignId
	 * @return LearningDesign populated LearningDesign object
	 */
	public LearningDesign getLearningDesignById(Long learningDesignId);
	/**
	 * @param title
	 * @return LearningDesign populated LearningDesign object
	 */
	public LearningDesign getLearningDesignByTitle(String title);
	
	/**
	 * @return List of all Learning designs
	 */
	public List getAllLearningDesigns();	
}
