/*
 * Created on Dec 4, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.lamsinternational.lams.learningdesign.dao.hibernate;

import java.util.List;

import com.lamsinternational.lams.learningdesign.LearningDesign;
import com.lamsinternational.lams.learningdesign.dao.ILearningDesignDAO;

/**
 * @author manpreet
 */
public class LearningDesignDAO extends BaseDAO implements ILearningDesignDAO {

	private static final String FIND_ALL ="from lams_learning_design";
	
	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.ILearningDesignDAO#getLearningDesignById(java.lang.Long)
	 */
	public LearningDesign getLearningDesignById(Long learningDesignId) {
		return (LearningDesign)super.find(LearningDesign.class,learningDesignId);	
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.ILearningDesignDAO#getLearningDesignByTitle(java.lang.String)
	 */
	public LearningDesign getLearningDesignByTitle(String title) {
			return (LearningDesign) super.find(LearningDesign.class,title);
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.ILearningDesignDAO#getAllLearningDesigns()
	 */
	public List getAllLearningDesigns() {
		return super.findAll(LearningDesign.class);		
	}
}
