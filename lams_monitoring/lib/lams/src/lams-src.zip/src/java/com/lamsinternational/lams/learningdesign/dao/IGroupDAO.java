/*
 * Created on Dec 6, 2004
 */
package com.lamsinternational.lams.learningdesign.dao;

import com.lamsinternational.lams.learningdesign.Group;

/**
 * @author manpreet 
 */
public interface IGroupDAO extends IBaseDAO {
	
	/**
	 * @param groupID
	 * @return Group populated Group object
	 */
	public Group getGroupById(Long groupID); 

}
