package com.lamsinternational.lams.learningdesign;

import com.lamsinternational.lams.usermanagement.User;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_learning_design"
 *     
*/
public class LearningDesign implements Serializable {

    /** identifier field */
    private Long learningDesignId;

    /** nullable persistent field */
    private Integer id;

    /** nullable persistent field */
    private String description;

    /** nullable persistent field */
    private String title;

    /** nullable persistent field */
    private Long firstActivityId;

    /** nullable persistent field */
    private Integer maxId;

    /** persistent field */
    private Boolean validDesign;

    /** persistent field */
    private Boolean readOnly;

    /** nullable persistent field */
    private Date dateReadOnly;

    /** nullable persistent field */
    private Long readAccess;

    /** nullable persistent field */
    private Long writeAccess;

    /** nullable persistent field */
    private String helpText;

    /** persistent field */
    private Boolean lessonCopy;

    /** persistent field */
    private Date createDateTime;

    /** persistent field */
    private String version;

    /** nullable persistent field */
    private Date openDateTime;

    /** nullable persistent field */
    private Date closeDateTime;

    /** persistent field */
    private User user;

    /** persistent field */
    private com.lamsinternational.lams.learningdesign.LearningDesign learningDesign;

    /** persistent field */
    private Set learningDesigns;

    /** persistent field */
    private Set lessons;

    /** persistent field */
    private Set transitions;

    /** persistent field */
    private Set activities;

    /** full constructor */
    public LearningDesign(Long learningDesignId, Integer id, String description, String title, Long firstActivityId, Integer maxId, Boolean validDesign, Boolean readOnly, Date dateReadOnly, Long readAccess, Long writeAccess, String helpText, Boolean lessonCopy, Date createDateTime, String version, Date openDateTime, Date closeDateTime, User user, com.lamsinternational.lams.learningdesign.LearningDesign learningDesign, Set learningDesigns, Set lessons, Set transitions, Set activities) {
        this.learningDesignId = learningDesignId;
        this.id = id;
        this.description = description;
        this.title = title;
        this.firstActivityId = firstActivityId;
        this.maxId = maxId;
        this.validDesign = validDesign;
        this.readOnly = readOnly;
        this.dateReadOnly = dateReadOnly;
        this.readAccess = readAccess;
        this.writeAccess = writeAccess;
        this.helpText = helpText;
        this.lessonCopy = lessonCopy;
        this.createDateTime = createDateTime;
        this.version = version;
        this.openDateTime = openDateTime;
        this.closeDateTime = closeDateTime;
        this.user = user;
        this.learningDesign = learningDesign;
        this.learningDesigns = learningDesigns;
        this.lessons = lessons;
        this.transitions = transitions;
        this.activities = activities;
    }

    /** default constructor */
    public LearningDesign() {
    }

    /** minimal constructor */
    public LearningDesign(Long learningDesignId, Boolean validDesign, Boolean readOnly, Boolean lessonCopy, Date createDateTime, String version, User user, com.lamsinternational.lams.learningdesign.LearningDesign learningDesign, Set learningDesigns, Set lessons, Set transitions, Set activities) {
        this.learningDesignId = learningDesignId;
        this.validDesign = validDesign;
        this.readOnly = readOnly;
        this.lessonCopy = lessonCopy;
        this.createDateTime = createDateTime;
        this.version = version;
        this.user = user;
        this.learningDesign = learningDesign;
        this.learningDesigns = learningDesigns;
        this.lessons = lessons;
        this.transitions = transitions;
        this.activities = activities;
    }

    /** 
     *            @hibernate.id
     *             generator-class="identity"
     *             type="java.lang.Long"
     *             column="learning_design_id"
     *         
     */
    public Long getLearningDesignId() {
        return this.learningDesignId;
    }

    public void setLearningDesignId(Long learningDesignId) {
        this.learningDesignId = learningDesignId;
    }

    /** 
     *            @hibernate.property
     *             column="id"
     *             length="11"
     *         
     */
    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /** 
     *            @hibernate.property
     *             column="description"
     *             length="65535"
     *         
     */
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /** 
     *            @hibernate.property
     *             column="title"
     *             length="255"
     *         
     */
    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /** 
     *            @hibernate.property
     *             column="first_activity_id"
     *             length="20"
     *         
     */
    public Long getFirstActivityId() {
        return this.firstActivityId;
    }

    public void setFirstActivityId(Long firstActivityId) {
        this.firstActivityId = firstActivityId;
    }

    /** 
     *            @hibernate.property
     *             column="max_id"
     *             length="11"
     *         
     */
    public Integer getMaxId() {
        return this.maxId;
    }

    public void setMaxId(Integer maxId) {
        this.maxId = maxId;
    }

    /** 
     *            @hibernate.property
     *             column="valid_design_flag"
     *             length="4"
     *             not-null="true"
     *         
     */
    public Boolean getValidDesign() {
        return this.validDesign;
    }

    public void setValidDesign(Boolean validDesign) {
        this.validDesign = validDesign;
    }

    /** 
     *            @hibernate.property
     *             column="read_only_flag"
     *             length="4"
     *             not-null="true"
     *         
     */
    public Boolean getReadOnly() {
        return this.readOnly;
    }

    public void setReadOnly(Boolean readOnly) {
        this.readOnly = readOnly;
    }

    /** 
     *            @hibernate.property
     *             column="date_read_only"
     *             length="19"
     *         
     */
    public Date getDateReadOnly() {
        return this.dateReadOnly;
    }

    public void setDateReadOnly(Date dateReadOnly) {
        this.dateReadOnly = dateReadOnly;
    }

    /** 
     *            @hibernate.property
     *             column="read_access"
     *             length="20"
     *         
     */
    public Long getReadAccess() {
        return this.readAccess;
    }

    public void setReadAccess(Long readAccess) {
        this.readAccess = readAccess;
    }

    /** 
     *            @hibernate.property
     *             column="write_access"
     *             length="20"
     *         
     */
    public Long getWriteAccess() {
        return this.writeAccess;
    }

    public void setWriteAccess(Long writeAccess) {
        this.writeAccess = writeAccess;
    }

    /** 
     *            @hibernate.property
     *             column="help_text"
     *             length="65535"
     *         
     */
    public String getHelpText() {
        return this.helpText;
    }

    public void setHelpText(String helpText) {
        this.helpText = helpText;
    }

    /** 
     *            @hibernate.property
     *             column="lesson_copy_flag"
     *             length="4"
     *             not-null="true"
     *         
     */
    public Boolean getLessonCopy() {
        return this.lessonCopy;
    }

    public void setLessonCopy(Boolean lessonCopy) {
        this.lessonCopy = lessonCopy;
    }

    /** 
     *            @hibernate.property
     *             column="create_date_time"
     *             length="19"
     *             not-null="true"
     *         
     */
    public Date getCreateDateTime() {
        return this.createDateTime;
    }

    public void setCreateDateTime(Date createDateTime) {
        this.createDateTime = createDateTime;
    }

    /** 
     *            @hibernate.property
     *             column="version"
     *             length="56"
     *             not-null="true"
     *         
     */
    public String getVersion() {
        return this.version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    /** 
     *            @hibernate.property
     *             column="open_date_time"
     *             length="19"
     *         
     */
    public Date getOpenDateTime() {
        return this.openDateTime;
    }

    public void setOpenDateTime(Date openDateTime) {
        this.openDateTime = openDateTime;
    }

    /** 
     *            @hibernate.property
     *             column="close_date_time"
     *             length="19"
     *         
     */
    public Date getCloseDateTime() {
        return this.closeDateTime;
    }

    public void setCloseDateTime(Date closeDateTime) {
        this.closeDateTime = closeDateTime;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="user_id"         
     *         
     */
    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="parent_learning_design_id"         
     *         
     */
    public com.lamsinternational.lams.learningdesign.LearningDesign getLearningDesign() {
        return this.learningDesign;
    }

    public void setLearningDesign(com.lamsinternational.lams.learningdesign.LearningDesign learningDesign) {
        this.learningDesign = learningDesign;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="parent_learning_design_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.LearningDesign"
     *         
     */
    public Set getLearningDesigns() {
        return this.learningDesigns;
    }

    public void setLearningDesigns(Set learningDesigns) {
        this.learningDesigns = learningDesigns;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="learning_design_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.lesson.Lesson"
     *         
     */
    public Set getLessons() {
        return this.lessons;
    }

    public void setLessons(Set lessons) {
        this.lessons = lessons;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="learning_design_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Transition"
     *         
     */
    public Set getTransitions() {
        return this.transitions;
    }

    public void setTransitions(Set transitions) {
        this.transitions = transitions;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="learning_design_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Activity"
     *         
     */
    public Set getActivities() {
        return this.activities;
    }

    public void setActivities(Set activities) {
        this.activities = activities;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("learningDesignId", getLearningDesignId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof LearningDesign) ) return false;
        LearningDesign castOther = (LearningDesign) other;
        return new EqualsBuilder()
            .append(this.getReadOnly(), castOther.getReadOnly())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getReadOnly())
            .toHashCode();
    }

}
