package com.lamsinternational.lams.usermanagement.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.lamsinternational.lams.usermanagement.service.UserManagementService;
import com.lamsinternational.lams.usermanagement.Organisation;
import com.lamsinternational.lams.usermanagement.User;
import com.lamsinternational.lams.usermanagement.Role;
import com.lamsinternational.lams.usermanagement.UserOrganisation;
import com.lamsinternational.lams.usermanagement.UserOrganisationRole;
import com.lamsinternational.lams.usermanagement.OrganisationType;
import com.lamsinternational.lams.web.AttributeNames;
import com.lamsinternational.lams.web.HttpSessionManager;

/**
 * @author Fei Yang
 *
 * @struts:action path="/admin/organisation"
 *  			name="OrganisationActionForm"
 * 				input=".admin.organisation"
 * 				scope="session"  
 * 				validate="true"
 * 
 * @struts:action-forward name="admin" path=".admin"
 * @struts:action-forward name="error" path=".admin.error"
 */
public class OrganisationAction extends Action {

	private static Logger log = Logger.getLogger(OrganisationAction.class);
	private static WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(HttpSessionManager.getInstance().getServletContext());
	private static UserManagementService service = (UserManagementService) ctx.getBean("userManagementServiceTarget");
	
    /**
     * Perform is called when the OrganisationActionForm is processed.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param actionForm The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet exception occurs
     */
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception
  	{

        ActionErrors errors = new ActionErrors();
System.out.println(form==null?"null":form.toString());
		log.debug("Form type is "+form.getClass().toString());
		log.debug("Form is "+form.toString());

		OrganisationActionForm orgForm = (OrganisationActionForm) form;
		
       // -- isCancelled?
        if (isCancelled(request)) {
			mapping.findForward("admin");
        }

        if (errors.isEmpty()) 
        {
        	log.debug("Call update organisation, based on form data "+orgForm);
        	Organisation org = null;
        	
        	try {
	        	if(orgForm.getOrgId().intValue()!=-1){//edit organisation
	        		org = (Organisation)request.getSession(true).getAttribute(AttributeNames.ADMIN_ORGANISATION);
	        		org.setName(orgForm.getName());
	        		org.setDescription(orgForm.getDescription());
	        		service.saveOrUpdateOrganisation(org);
	        	}else{//create child organisation
	        		org = new Organisation();
	        		org.setName(orgForm.getName());
	        		org.setDescription(orgForm.getDescription());
	        		Organisation parentOrg = (Organisation)request.getSession(true).getAttribute(AttributeNames.ADMIN_ORGANISATION);
	        		org.setParentOrganisation(parentOrg);
	        		org.setCreateDate(new Date());
	        		OrganisationType orgType;
	        		if(parentOrg.getOrganisationType().getName().equals(OrganisationType.ROOT)){
	        			orgType = service.getOrganisationTypeByName(OrganisationType.BASE);
	        		}else{
	        			orgType = service.getOrganisationTypeByName(OrganisationType.SUB);
	        		}
	        		org.setOrganisationType(orgType);
	        		service.saveOrUpdateOrganisation(org);
	        		UserOrganisation userOrg = new UserOrganisation();
	        		User user = service.getUserByLogin(request.getRemoteUser());
	        		userOrg.setUser(user);
	        		userOrg.setOrganisation(org);
	        		service.saveOrUpdateUserOrganisation(userOrg);
	        		UserOrganisationRole userOrgRole = new UserOrganisationRole();
	        		userOrgRole.setUserOrganisation(userOrg);
	        		userOrgRole.setRole(service.getRoleByName(Role.ADMIN));
	        		service.saveOrUpdateUserOrganisationRole(userOrgRole);
	        	}
			} catch (Exception e) {
				log.error("Exception happened when getOrganisationEdit",e);
				errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(e.getMessage()));				
			}
			
        } 

        // -- Report any errors
        if (!errors.isEmpty()) {
            saveErrors(request, errors);
            if (mapping.getInput()!=null)
                return (new ActionForward(mapping.getInput()));
            // If no input page, use error forwarding
            return (mapping.findForward("error"));
        }else{
        	return mapping.findForward("admin");
        }


    } // end ActionForward


} // end Action


