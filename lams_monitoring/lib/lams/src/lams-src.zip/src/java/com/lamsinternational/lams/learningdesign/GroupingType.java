package com.lamsinternational.lams.learningdesign;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_grouping_type"
 *     
*/
public class GroupingType implements Serializable {

    /** identifier field */
    private Integer groupingTypeId;

    /** persistent field */
    private String description;

    /** persistent field */
    private Set groupings;

    /** full constructor */
    public GroupingType(Integer groupingTypeId, String description, Set groupings) {
        this.groupingTypeId = groupingTypeId;
        this.description = description;
        this.groupings = groupings;
    }

    /** default constructor */
    public GroupingType() {
    }

    /** 
     *            @hibernate.id
     *             generator-class="assigned"
     *             type="java.lang.Integer"
     *             column="grouping_type_id"
     *         
     */
    public Integer getGroupingTypeId() {
        return this.groupingTypeId;
    }

    public void setGroupingTypeId(Integer groupingTypeId) {
        this.groupingTypeId = groupingTypeId;
    }

    /** 
     *            @hibernate.property
     *             column="description"
     *             length="128"
     *             not-null="true"
     *         
     */
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="grouping_type_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Grouping"
     *         
     */
    public Set getGroupings() {
        return this.groupings;
    }

    public void setGroupings(Set groupings) {
        this.groupings = groupings;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("groupingTypeId", getGroupingTypeId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof GroupingType) ) return false;
        GroupingType castOther = (GroupingType) other;
        return new EqualsBuilder()
            .append(this.getGroupingTypeId(), castOther.getGroupingTypeId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getGroupingTypeId())
            .toHashCode();
    }

}
