/*
 * Created on Dec 7, 2004
 */
package com.lamsinternational.lams.learningdesign.service;

import java.util.List;

import com.lamsinternational.lams.learningdesign.dao.hibernate.LearningDesignDAO;
import com.lamsinternational.lams.learningdesign.LearningDesign;
import com.lamsinternational.lams.learningdesign.service.IAuthoringService;

/**
 * @author manpreet
 */
public class AuthoringService implements IAuthoringService {
	
	protected LearningDesignDAO learningDesignDAO;
	
	public void setLearningDesignDAO(LearningDesignDAO learningDesignDAO){
		this.learningDesignDAO = learningDesignDAO;
	}
	public LearningDesign getLearningDesign(Long learningDesignID){
		return learningDesignDAO.getLearningDesignById(learningDesignID);
	}
	
	public void saveLearningDesign(LearningDesign learningDesign){
		learningDesignDAO.insert(learningDesign);
	}
	public List getAllLearningDesigns(){
		return learningDesignDAO.getAllLearningDesigns();		
	}
	/* 
	 * @see com.lamsinternational.lams.learningdesign.service.interfaces.IAuthoringService#updateLearningDesign(java.lang.Long)
	 */
	public void updateLearningDesign(Long learningDesignID) {
		// TODO Auto-generated method stub
		
	}

}
