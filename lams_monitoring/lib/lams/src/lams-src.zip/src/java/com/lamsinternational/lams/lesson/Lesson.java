package com.lamsinternational.lams.lesson;

import com.lamsinternational.lams.learningdesign.Grouping;
import com.lamsinternational.lams.learningdesign.LearningDesign;
import com.lamsinternational.lams.usermanagement.Organisation;
import com.lamsinternational.lams.usermanagement.User;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_lesson"
 *     
*/
public class Lesson implements Serializable {

    /** identifier field */
    private Long lessonId;

    /** persistent field */
    private Date createDateTime;

    /** nullable persistent field */
    private Date startDateTime;

    /** nullable persistent field */
    private Date endDateTime;

    /** persistent field */
    private User user;

    /** persistent field */
    private com.lamsinternational.lams.lesson.LessonState lessonState;

    /** persistent field */
    private LearningDesign learningDesign;

    /** persistent field */
    private Grouping grouping;

    /** persistent field */
    private Organisation organisation;

    /** persistent field */
    private Set learnerProgresses;

    
    /** full constructor */
    public Lesson(Long lessonId, Date createDateTime, Date startDateTime, Date endDateTime, User user, com.lamsinternational.lams.lesson.LessonState lessonState, LearningDesign learningDesign, Grouping grouping, Organisation organisation, Set learnerProgresses) {
        this.lessonId = lessonId;
        this.createDateTime = createDateTime;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.user = user;
        this.lessonState = lessonState;
        this.learningDesign = learningDesign;
        this.grouping = grouping;
        this.organisation = organisation;
        this.learnerProgresses = learnerProgresses;        
    }

    /** default constructor */
    public Lesson() {
    }

    /** minimal constructor */
    public Lesson(Long lessonId, Date createDateTime, User user, com.lamsinternational.lams.lesson.LessonState lessonState, LearningDesign learningDesign, Grouping grouping, Organisation organisation, Set learnerProgresses) {
        this.lessonId = lessonId;
        this.createDateTime = createDateTime;
        this.user = user;
        this.lessonState = lessonState;
        this.learningDesign = learningDesign;
        this.grouping = grouping;
        this.organisation = organisation;
        this.learnerProgresses = learnerProgresses;        
    }

    /** 
     *            @hibernate.id
     *             generator-class="identity"
     *             type="java.lang.Long"
     *             column="lesson_id"
     *         
     */
    public Long getLessonId() {
        return this.lessonId;
    }

    public void setLessonId(Long lessonId) {
        this.lessonId = lessonId;
    }

    /** 
     *            @hibernate.property
     *             column="create_date_time"
     *             length="19"
     *             not-null="true"
     *         
     */
    public Date getCreateDateTime() {
        return this.createDateTime;
    }

    public void setCreateDateTime(Date createDateTime) {
        this.createDateTime = createDateTime;
    }

    /** 
     *            @hibernate.property
     *             column="start_date_time"
     *             length="19"
     *         
     */
    public Date getStartDateTime() {
        return this.startDateTime;
    }

    public void setStartDateTime(Date startDateTime) {
        this.startDateTime = startDateTime;
    }

    /** 
     *            @hibernate.property
     *             column="end_date_time"
     *             length="19"
     *         
     */
    public Date getEndDateTime() {
        return this.endDateTime;
    }

    public void setEndDateTime(Date endDateTime) {
        this.endDateTime = endDateTime;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="user_id"         
     *         
     */
    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="lams_lesson_state_id"         
     *         
     */
    public com.lamsinternational.lams.lesson.LessonState getLessonState() {
        return this.lessonState;
    }

    public void setLessonState(com.lamsinternational.lams.lesson.LessonState lessonState) {
        this.lessonState = lessonState;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="learning_design_id"         
     *         
     */
    public LearningDesign getLearningDesign() {
        return this.learningDesign;
    }

    public void setLearningDesign(LearningDesign learningDesign) {
        this.learningDesign = learningDesign;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="class_grouping_id"         
     *         
     */
    public Grouping getGrouping() {
        return this.grouping;
    }

    public void setGrouping(Grouping grouping) {
        this.grouping = grouping;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="organisation_id"         
     *         
     */
    public Organisation getOrganisation() {
        return this.organisation;
    }

    public void setOrganisation(Organisation organisation) {
        this.organisation = organisation;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="lesson_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.lesson.LearnerProgress"
     *         
     */
    public Set getLearnerProgresses() {
        return this.learnerProgresses;
    }

    public void setLearnerProgresses(Set learnerProgresses) {
        this.learnerProgresses = learnerProgresses;
    }

       public String toString() {
        return new ToStringBuilder(this)
            .append("lessonId", getLessonId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof Lesson) ) return false;
        Lesson castOther = (Lesson) other;
        return new EqualsBuilder()
            .append(this.getLessonId(), castOther.getLessonId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getLessonId())
            .toHashCode();
    }

}
