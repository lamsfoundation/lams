package com.lamsinternational.lams.learningdesign;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 * @hibernate.class 
*/
public class RandomGroupingActivity extends GroupingActivity implements Serializable {

    /** full constructor */
    public RandomGroupingActivity(Long activityId, Integer id, String description, String title, Integer xcoord, Integer ycoord, Integer orderId, Boolean defineLater, java.util.Date createDateTime, String offlineInstructions, Long toolContentId, com.lamsinternational.lams.learningdesign.LearningLibrary learningLibrary, com.lamsinternational.lams.learningdesign.GateActivityLevel gateActivityLevel, com.lamsinternational.lams.learningdesign.Activity activity, com.lamsinternational.lams.tool.Tool tool, com.lamsinternational.lams.learningdesign.LearningDesign learningDesign, com.lamsinternational.lams.learningdesign.Grouping grouping, com.lamsinternational.lams.learningdesign.ActivityType activityType, java.util.Set progressCurrents, java.util.Set progressCompleteds, java.util.Set transitionsByToActivityId, java.util.Set transitionsByFromActivityId, java.util.Set activities) {
        super(activityId, id, description, title, xcoord, ycoord, orderId, defineLater, createDateTime, offlineInstructions, toolContentId, learningLibrary, gateActivityLevel, activity, tool, learningDesign, grouping, activityType, progressCurrents, progressCompleteds, transitionsByToActivityId, transitionsByFromActivityId, activities);
    }

    /** default constructor */
    public RandomGroupingActivity() {
    }

    /** minimal constructor */
    public RandomGroupingActivity(Long activityId, Boolean defineLater, java.util.Date createDateTime, com.lamsinternational.lams.learningdesign.LearningLibrary learningLibrary, com.lamsinternational.lams.learningdesign.GateActivityLevel gateActivityLevel, com.lamsinternational.lams.learningdesign.Activity activity, com.lamsinternational.lams.tool.Tool tool, com.lamsinternational.lams.learningdesign.LearningDesign learningDesign, com.lamsinternational.lams.learningdesign.Grouping grouping, com.lamsinternational.lams.learningdesign.ActivityType activityType, java.util.Set progressCurrents, java.util.Set progressCompleteds, java.util.Set transitionsByToActivityId, java.util.Set transitionsByFromActivityId, java.util.Set activities) {
      super(activityId, defineLater, createDateTime, learningLibrary, gateActivityLevel, activity, tool, learningDesign, grouping, activityType, progressCurrents, progressCompleteds, transitionsByToActivityId, transitionsByFromActivityId, activities);
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("activityId", getActivityId())
            .toString();
    }

}
