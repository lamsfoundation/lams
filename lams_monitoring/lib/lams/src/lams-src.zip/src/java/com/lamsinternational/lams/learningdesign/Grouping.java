package com.lamsinternational.lams.learningdesign;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_grouping"
 *     
*/
public class Grouping implements Serializable {

    /** identifier field */
    private Long groupingId;

    /** nullable persistent field */
    private Integer numberOfGroups;

    /** nullable persistent field */
    private Integer learnersPerGroup;

    /** nullable persistent field */
    private Long staffGroupId;
    
    /** nullable persistent field */
    private Integer maxNumberOfGroups;

    /** persistent field */
    private com.lamsinternational.lams.learningdesign.GroupingType groupingType;

    /** persistent field */
    private Set groups;

    /** persistent field */
    private Set lessons;

    /** persistent field */
    private Set activities;

    /** full constructor */
    public Grouping(Long groupingId, Integer numberOfGroups, Integer learnersPerGroup, Long staffGroupId, com.lamsinternational.lams.learningdesign.GroupingType groupingType, Set groups, Set lessons, Set activities) {
        this.groupingId = groupingId;
        this.numberOfGroups = numberOfGroups;
        this.learnersPerGroup = learnersPerGroup;
        this.staffGroupId = staffGroupId;
        this.groupingType = groupingType;
        this.groups = groups;
        this.lessons = lessons;
        this.activities = activities;
    }

    /** default constructor */
    public Grouping() {
    }

    /** minimal constructor */
    public Grouping(Long groupingId, com.lamsinternational.lams.learningdesign.GroupingType groupingType, Set groups, Set lessons, Set activities) {
        this.groupingId = groupingId;
        this.groupingType = groupingType;
        this.groups = groups;
        this.lessons = lessons;
        this.activities = activities;
    }

    /** 
     *            @hibernate.id
     *             generator-class="identity"
     *             type="java.lang.Long"
     *             column="grouping_id"
     *         
     */
    public Long getGroupingId() {
        return this.groupingId;
    }

    public void setGroupingId(Long groupingId) {
        this.groupingId = groupingId;
    }

    /** 
     *            @hibernate.property
     *             column="number_of_groups"
     *             length="11"
     *         
     */
    public Integer getNumberOfGroups() {
        return this.numberOfGroups;
    }

    public void setNumberOfGroups(Integer numberOfGroups) {
        this.numberOfGroups = numberOfGroups;
    }

    /** 
     *            @hibernate.property
     *             column="learners_per_group"
     *             length="11"
     *         
     */
    public Integer getLearnersPerGroup() {
        return this.learnersPerGroup;
    }

    public void setLearnersPerGroup(Integer learnersPerGroup) {
        this.learnersPerGroup = learnersPerGroup;
    }

    /** 
     *            @hibernate.property
     *             column="staff_group_id"
     *             length="20"
     *         
     */
    public Long getStaffGroupId() {
        return this.staffGroupId;
    }

    public void setStaffGroupId(Long staffGroupId) {
        this.staffGroupId = staffGroupId;
    }

    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="grouping_type_id"         
     *         
     */
    public com.lamsinternational.lams.learningdesign.GroupingType getGroupingType() {
        return this.groupingType;
    }

    public void setGroupingType(com.lamsinternational.lams.learningdesign.GroupingType groupingType) {
        this.groupingType = groupingType;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="grouping_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Group"
     *         
     */
    public Set getGroups() {
        return this.groups;
    }

    public void setGroups(Set groups) {
        this.groups = groups;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="class_grouping_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.lesson.Lesson"
     *         
     */
    public Set getLessons() {
        return this.lessons;
    }

    public void setLessons(Set lessons) {
        this.lessons = lessons;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="grouping_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Activity"
     *         
     */
    public Set getActivities() {
        return this.activities;
    }

    public void setActivities(Set activities) {
        this.activities = activities;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("groupingId", getGroupingId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof Grouping) ) return false;
        Grouping castOther = (Grouping) other;
        return new EqualsBuilder()
            .append(this.getGroupingId(), castOther.getGroupingId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getGroupingId())
            .toHashCode();
    }    
	/**
	 * @hibernate.property column="max_number_of_groups" length="3"
	 * @return Returns the maxNumberOfGroups.
	 */
	public Integer getMaxNumberOfGroups() {
		return maxNumberOfGroups;
	}
	/**
	 * @param maxNumberOfGroups The maxNumberOfGroups to set.
	 */
	public void setMaxNumberOfGroups(Integer maxNumberOfGroups) {
		this.maxNumberOfGroups = maxNumberOfGroups;
	}
}
