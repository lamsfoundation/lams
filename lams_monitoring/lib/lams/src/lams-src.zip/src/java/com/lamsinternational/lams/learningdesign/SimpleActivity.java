package com.lamsinternational.lams.learningdesign;

import com.lamsinternational.lams.tool.Tool;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 * @hibernate.class 
*/
public abstract class SimpleActivity extends Activity implements Serializable {

    /** full constructor */
    public SimpleActivity(Long activityId, Integer id, String description, String title, Integer xcoord, Integer ycoord, Integer orderId, Boolean defineLater, Date createDateTime, String offlineInstructions, Long toolContentId, com.lamsinternational.lams.learningdesign.LearningLibrary learningLibrary, com.lamsinternational.lams.learningdesign.GateActivityLevel gateActivityLevel, com.lamsinternational.lams.learningdesign.Activity activity, Tool tool, com.lamsinternational.lams.learningdesign.LearningDesign learningDesign, com.lamsinternational.lams.learningdesign.Grouping grouping, com.lamsinternational.lams.learningdesign.ActivityType activityType, Set progressCurrents, Set progressCompleteds, Set transitionsByToActivityId, Set transitionsByFromActivityId, Set activities) {
        super(activityId, id, description, title, xcoord, ycoord, orderId, defineLater, createDateTime, offlineInstructions, toolContentId, learningLibrary, gateActivityLevel, activity, tool, learningDesign, grouping, activityType, progressCurrents, progressCompleteds, transitionsByToActivityId, transitionsByFromActivityId, activities);
    }

    /** default constructor */
    public SimpleActivity() {
    }

    /** minimal constructor */
    public SimpleActivity(Long activityId, Boolean defineLater, Date createDateTime, com.lamsinternational.lams.learningdesign.LearningLibrary learningLibrary, com.lamsinternational.lams.learningdesign.GateActivityLevel gateActivityLevel, com.lamsinternational.lams.learningdesign.Activity activity, Tool tool, com.lamsinternational.lams.learningdesign.LearningDesign learningDesign, com.lamsinternational.lams.learningdesign.Grouping grouping, com.lamsinternational.lams.learningdesign.ActivityType activityType, Set progressCurrents, Set progressCompleteds, Set transitionsByToActivityId, Set transitionsByFromActivityId, Set activities) {
      super(activityId, defineLater, createDateTime, learningLibrary, gateActivityLevel, activity, tool, learningDesign, grouping, activityType, progressCurrents, progressCompleteds, transitionsByToActivityId, transitionsByFromActivityId, activities);
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("activityId", getActivityId())
            .toString();
    }

}
