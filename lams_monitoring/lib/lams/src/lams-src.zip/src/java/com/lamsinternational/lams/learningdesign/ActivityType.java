package com.lamsinternational.lams.learningdesign;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_learning_activity_type"
 *     
*/
public class ActivityType implements Serializable {

    /** identifier field */
    private Integer learningActivityTypeId;

    /** persistent field */
    private String description;

    /** persistent field */
    private Set activities;

    /** full constructor */
    public ActivityType(Integer learningActivityTypeId, String description, Set activities) {
        this.learningActivityTypeId = learningActivityTypeId;
        this.description = description;
        this.activities = activities;
    }

    /** default constructor */
    public ActivityType() {
    }

    /** 
     *            @hibernate.id
     *             generator-class="assigned"
     *             type="java.lang.Integer"
     *             column="learning_activity_type_id"
     *         
     */
    public Integer getLearningActivityTypeId() {
        return this.learningActivityTypeId;
    }

    public void setLearningActivityTypeId(Integer learningActivityTypeId) {
        this.learningActivityTypeId = learningActivityTypeId;
    }

    /** 
     *            @hibernate.property
     *             column="description"
     *             length="255"
     *             not-null="true"
     *         
     */
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="learning_activity_type_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Activity"
     *         
     */
    public Set getActivities() {
        return this.activities;
    }

    public void setActivities(Set activities) {
        this.activities = activities;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("learningActivityTypeId", getLearningActivityTypeId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof ActivityType) ) return false;
        ActivityType castOther = (ActivityType) other;
        return new EqualsBuilder()
            .append(this.getLearningActivityTypeId(), castOther.getLearningActivityTypeId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getLearningActivityTypeId())
            .toHashCode();
    }

}
