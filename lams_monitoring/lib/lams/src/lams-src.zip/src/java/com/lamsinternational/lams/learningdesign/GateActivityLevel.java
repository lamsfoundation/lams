package com.lamsinternational.lams.learningdesign;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_gate_activity_level"
 *     
*/
public class GateActivityLevel implements Serializable {

    /** identifier field */
    private Integer gateActivityLevelId;

    /** persistent field */
    private String description;

    /** persistent field */
    private Set activities;

    /** full constructor */
    public GateActivityLevel(Integer gateActivityLevelId, String description, Set activities) {
        this.gateActivityLevelId = gateActivityLevelId;
        this.description = description;
        this.activities = activities;
    }

    /** default constructor */
    public GateActivityLevel() {
    }

    /** 
     *            @hibernate.id
     *             generator-class="assigned"
     *             type="java.lang.Integer"
     *             column="gate_activity_level_id"
     *         
     */
    public Integer getGateActivityLevelId() {
        return this.gateActivityLevelId;
    }

    public void setGateActivityLevelId(Integer gateActivityLevelId) {
        this.gateActivityLevelId = gateActivityLevelId;
    }

    /** 
     *            @hibernate.property
     *             column="description"
     *             length="128"
     *             not-null="true"
     *         
     */
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /** 
     *            @hibernate.set
     *             lazy="true"
     *             inverse="true"
     *             cascade="none"
     *            @hibernate.collection-key
     *             column="gate_activity_level_id"
     *            @hibernate.collection-one-to-many
     *             class="com.lamsinternational.lams.learningdesign.Activity"
     *         
     */
    public Set getActivities() {
        return this.activities;
    }

    public void setActivities(Set activities) {
        this.activities = activities;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("gateActivityLevelId", getGateActivityLevelId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof GateActivityLevel) ) return false;
        GateActivityLevel castOther = (GateActivityLevel) other;
        return new EqualsBuilder()
            .append(this.getGateActivityLevelId(), castOther.getGateActivityLevelId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getGateActivityLevelId())
            .toHashCode();
    }

}
