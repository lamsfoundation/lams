package com.lamsinternational.lams.lesson;

import com.lamsinternational.lams.learningdesign.Activity;
import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 *        @hibernate.class
 *         table="lams_progress_current"
 *     
*/
public class ProgressCurrent implements Serializable {

    /** identifier field */
    private com.lamsinternational.lams.lesson.ProgressCurrentPK comp_id;

    /** nullable persistent field */
    private com.lamsinternational.lams.lesson.LearnerProgress learnerProgress;

    /** nullable persistent field */
    private Activity activity;

    /** full constructor */
    public ProgressCurrent(com.lamsinternational.lams.lesson.ProgressCurrentPK comp_id, com.lamsinternational.lams.lesson.LearnerProgress learnerProgress, Activity activity) {
        this.comp_id = comp_id;
        this.learnerProgress = learnerProgress;
        this.activity = activity;
    }

    /** default constructor */
    public ProgressCurrent() {
    }

    /** minimal constructor */
    public ProgressCurrent(com.lamsinternational.lams.lesson.ProgressCurrentPK comp_id) {
        this.comp_id = comp_id;
    }

    /** 
     *            @hibernate.id
     *             generator-class="assigned"
     *         
     */
    public com.lamsinternational.lams.lesson.ProgressCurrentPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(com.lamsinternational.lams.lesson.ProgressCurrentPK comp_id) {
        this.comp_id = comp_id;
    }

    /** 
     *            @hibernate.many-to-one
     *             update="false"
     *             insert="false"
     *         
     *            @hibernate.column
     *             name="learner_progress_id"
     *         
     */
    public com.lamsinternational.lams.lesson.LearnerProgress getLearnerProgress() {
        return this.learnerProgress;
    }

    public void setLearnerProgress(com.lamsinternational.lams.lesson.LearnerProgress learnerProgress) {
        this.learnerProgress = learnerProgress;
    }

    /** 
     *            @hibernate.many-to-one
     *             update="false"
     *             insert="false"
     *         
     *            @hibernate.column
     *             name="activity_id"
     *         
     */
    public Activity getActivity() {
        return this.activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof ProgressCurrent) ) return false;
        ProgressCurrent castOther = (ProgressCurrent) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
