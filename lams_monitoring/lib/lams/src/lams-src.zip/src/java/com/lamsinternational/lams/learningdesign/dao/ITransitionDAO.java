/*
 * Created on Dec 6, 2004
 */
package com.lamsinternational.lams.learningdesign.dao;

import com.lamsinternational.lams.learningdesign.Transition;

/**
 * @author MMINHAS
 */
public interface ITransitionDAO extends IBaseDAO {
	
	/**
	 * @param transitionID
	 * @return Transition populated Transition object
	 */
	public Transition getTransitionById(Long transitionID);

}
