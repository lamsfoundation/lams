/*
 * Created on 2005-1-14
 *
 * Last modified on 2005-1-14
 */
package com.lamsinternational.lams.web;

/**
 * TODO Add description here
 *
 * <p>
 * <a href="AttributeNames.java.html"><i>View Source</i></a>
 * </p>
 * 
 * @author <a href="mailto:fyang@melcoe.mq.edu.au">Fei Yang</a>
 */
public class AttributeNames {

	public static final String ADMIN_ORGANISATION = "organisation";
	public static final String ADMIN_USERS = "users";
	public static final String ADMIN_ERR_MSG = "errormsg";

}
