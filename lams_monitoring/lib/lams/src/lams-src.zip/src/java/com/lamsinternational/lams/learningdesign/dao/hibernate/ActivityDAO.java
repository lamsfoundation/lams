/*
 * Created on Dec 3, 2004
 */
package com.lamsinternational.lams.learningdesign.dao.hibernate;

import java.util.List;
import com.lamsinternational.lams.learningdesign.Activity;
import com.lamsinternational.lams.learningdesign.dao.IActivityDAO;

/**
 * @author MMINHAS 
 */
public class ActivityDAO extends BaseDAO implements IActivityDAO {
	
	private static final String FIND_BY_PARENT = "from lams_learning_activity activity where activity.parent_activity_id=?" ;	
	private static final String FIND_BY_LEARNING_DESIGN_ID ="from lams_learning_activity activity where activity.learning_design_id=?" ;

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#getActivityById(java.lang.Long)
	 */
	public Activity getActivityById(Long activityId) {
		return (Activity) super.find(Activity.class,activityId);		
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#getActivityByParentActivityId(java.lang.Long)
	 */
	public Activity getActivityByParentActivityId(Long parentActivityId) {
		List list = this.getHibernateTemplate().find(FIND_BY_PARENT,parentActivityId);
		if(list.size()==0)
			return null;
		else
			return (Activity) list.get(0);
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#getAllActivities()
	 */
	public List getAllActivities() {
		return super.findAll(Activity.class);						
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#getActivitiesByLearningDesignId(java.lang.Long)
	 */
	public List getActivitiesByLearningDesignId(Long learningDesignId) {
		return this.getHibernateTemplate().find(FIND_BY_LEARNING_DESIGN_ID,learningDesignId);		
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#insertActivity(com.lamsinternational.lams.learningdesign.Activity)
	 */
	public void insertActivity(Activity activity) {
		this.getHibernateTemplate().save(activity);
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#updateActivity(com.lamsinternational.lams.learningdesign.Activity)
	 */
	public void updateActivity(Activity activity) {
		this.getHibernateTemplate().update(activity);
	}

	/* 
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.IActivityDAO#deleteActivity(com.lamsinternational.lams.learningdesign.Activity)
	 */
	public void deleteActivity(Activity activity) {
		this.getHibernateTemplate().delete(activity);
	}

}
