/*
 * Created on Dec 2, 2004
 *
 * Last modified on Dec 2, 2004
 */
package com.lamsinternational.lams.usermanagement.dao.hibernate;

import java.util.List;

import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import com.lamsinternational.lams.usermanagement.AuthenticationMethod;
import com.lamsinternational.lams.usermanagement.User;
import com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO;

/**
 * This class interacts with Spring's HibernateTemplate to save/delete and
 * retrieve AuthenticationMethodType objects.
 *
 * <p>
 * <a href="AuthenticationMethodDAO.java.html"><i>View Source</i></a>
 * </p>
 * 
 * @author <a href="mailto:fyang@melcoe.mq.edu.au">Fei Yang</a>
 */
public class AuthenticationMethodDAO extends HibernateDaoSupport
		implements IAuthenticationMethodDAO {

	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#getAllAuthenticationMethods()
	 */
	public List getAllAuthenticationMethods() {
		return getHibernateTemplate().find("from AuthenticationMethod");
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#getAuthenticationMethodById(java.lang.Integer)
	 */
	public AuthenticationMethod getAuthenticationMethodById(Integer authenticationMethodId) {
		return (AuthenticationMethod)getHibernateTemplate().get(AuthenticationMethod.class, authenticationMethodId);
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#getAuthenticationMethodByUser(com.lamsinternational.lams.usermanagement.User)
	 */
	public AuthenticationMethod getAuthenticationMethodByUser(User user){
		String queryString = "from AuthenticationMethod am where am.authenticationMethodId=?";
		List list = getHibernateTemplate().find(queryString,user.getAuthenticationMethod().getAuthenticationMethodId());
		return (AuthenticationMethod)list.get(0);
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#saveAuthenticationMethod(com.lamsinternational.lams.usermanagement.AuthenticationMethod)
	 */
	public void saveAuthenticationMethod(AuthenticationMethod authenticationMethod) {
		getHibernateTemplate().save(authenticationMethod);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#updateAuthenticationMethod(com.lamsinternational.lams.usermanagement.AuthenticationMethod)
	 */
	public void updateAuthenticationMethod(AuthenticationMethod authenticationMethod) {
		getHibernateTemplate().update(authenticationMethod);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#saveOrUpdateAuthenticationMethod(com.lamsinternational.lams.usermanagement.AuthenticationMethod)
	 */
	public void saveOrUpdateAuthenticationMethod(AuthenticationMethod authenticationMethod) {
		getHibernateTemplate().saveOrUpdate(authenticationMethod);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#deleteAuthenticationMethod(com.lamsinternational.lams.usermanagement.AuthenticationMethod)
	 */
	public void deleteAuthenticationMethod(AuthenticationMethod authenticationMethod) {
		getHibernateTemplate().delete(authenticationMethod);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO#deleteAuthenticationMethodById(java.lang.Integer)
	 */
	public void deleteAuthenticationMethodById(Integer authenticationMethodId) {
		getHibernateTemplate().delete(getAuthenticationMethodById(authenticationMethodId));
	}

}
