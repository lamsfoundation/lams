/*
 * Created on Dec 6, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.lamsinternational.lams.learningdesign.dao.hibernate;

import com.lamsinternational.lams.learningdesign.Transition;
import com.lamsinternational.lams.learningdesign.dao.ITransitionDAO;

/**
 * @author MMINHAS
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TransitionDAO extends BaseDAO implements ITransitionDAO {

	/* (non-Javadoc)
	 * @see com.lamsinternational.lams.learningdesign.dao.interfaces.ITransitionDAO#getTransitionById(java.lang.Long)
	 */
	public Transition getTransitionById(Long transitionID) {
		// TODO Auto-generated method stub
		return null;
	}

}
