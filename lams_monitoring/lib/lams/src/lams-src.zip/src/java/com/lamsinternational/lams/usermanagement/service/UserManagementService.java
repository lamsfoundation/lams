/*
 * Created on Nov 22, 2004
 *
 * Last modified on Nov 22, 2004
 */
package com.lamsinternational.lams.usermanagement.service;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO;
import com.lamsinternational.lams.usermanagement.dao.IOrganisationDAO;
import com.lamsinternational.lams.usermanagement.dao.IOrganisationTypeDAO;
import com.lamsinternational.lams.usermanagement.dao.IUserOrganisationDAO;
import com.lamsinternational.lams.usermanagement.dao.IUserOrganisationRoleDAO;
import com.lamsinternational.lams.usermanagement.dao.IUserDAO;
import com.lamsinternational.lams.usermanagement.dao.IRoleDAO;
import com.lamsinternational.lams.usermanagement.Organisation;
import com.lamsinternational.lams.usermanagement.OrganisationType;
import com.lamsinternational.lams.usermanagement.Role;
import com.lamsinternational.lams.usermanagement.User;
import com.lamsinternational.lams.usermanagement.UserOrganisation;
import com.lamsinternational.lams.usermanagement.UserOrganisationRole;
import com.lamsinternational.lams.usermanagement.AuthenticationMethod;

/**
 * TODO Add description here
 *
 * <p>
 * <a href="UserManagementService.java.html"><i>View Source</i></a>
 * </p>
 * 
 * @author <a href="mailto:fyang@melcoe.mq.edu.au">Fei Yang</a>
 */
public class UserManagementService implements IUserManagementService {

	private IUserDAO userDAO;
	private IRoleDAO roleDAO;
	private IOrganisationDAO organisationDAO;
	private IOrganisationTypeDAO organisationTypeDAO;
	private IUserOrganisationDAO userOrganisationDAO;
	private IUserOrganisationRoleDAO userOrganisationRoleDAO;
	private IAuthenticationMethodDAO authenticationMethodDAO;
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setUserDAO(com.lamsinternational.lams.usermanagement.dao.IUserDAO)
	 */
	public void setUserDAO(IUserDAO userDAO) {
		this.userDAO = userDAO;
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setRoleDAO(com.lamsinternational.lams.usermanagement.dao.IRoleDAO)
	 */
	public void setRoleDAO(IRoleDAO roleDAO) {
		this.roleDAO = roleDAO;
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setOrganisationDAO(com.lamsinternational.lams.usermanagement.dao.IOrganisationDAO)
	 */
	public void setOrganisationDAO(IOrganisationDAO organisationDAO) {
		this.organisationDAO = organisationDAO;
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setOrganisationTypeDAO(com.lamsinternational.lams.usermanagement.dao.IOrganisationTypeDAO)
	 */
	public void setOrganisationTypeDAO(IOrganisationTypeDAO organisationTypeDAO){
		this.organisationTypeDAO = organisationTypeDAO;
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setUserOrganisationDAO(com.lamsinternational.lams.usermanagement.dao.IUserOrganisationDAO)
	 */
	public void setUserOrganisationDAO(IUserOrganisationDAO userOrganisationDAO) {
		this.userOrganisationDAO = userOrganisationDAO;
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setUserOrganisationRoleDAO(com.lamsinternational.lams.usermanagement.dao.IUserOrganisationRoleDAO)
	 */
	public void setUserOrganisationRoleDAO(IUserOrganisationRoleDAO userOrganisationRoleDAO) {
		this.userOrganisationRoleDAO = userOrganisationRoleDAO;
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#setOrganisationDAO(com.lamsinternational.lams.usermanagement.dao.IAuthenticationMethodDAO)
	 */
	public void setAuthenticationMethodDAO(IAuthenticationMethodDAO authenticationMethodDAO){
		this.authenticationMethodDAO = authenticationMethodDAO;
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getUserByLogin(java.lang.String)
	 */
	public User getUserByLogin(String login) {
		return userDAO.getUserByLogin(login);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getOrganisationById(java.lang.Integer)
	 */
    public Organisation getOrganisationById(Integer organisationId){
    	return organisationDAO.getOrganisationById(organisationId);
    }

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getOrganisationTypeByName(java.lang.String)
	 */
    public OrganisationType getOrganisationTypeByName(String name){
    	return organisationTypeDAO.getOrganisationTypeByName(name);
    }
    
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getRoleByName(java.lang.String)
	 */
    public Role getRoleByName(String roleName){
    	return roleDAO.getRoleByName(roleName);
    }
    
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getUserOrganisationRole(java.lang.String,java.lang.Integer,java.lang.String)
	 */
    public UserOrganisationRole getUserOrganisationRole(String login, Integer organisationId, String roleName){
    	User user = userDAO.getUserByLogin(login);
    	if(user == null)
    		return null;
    	UserOrganisation userOrganisation = userOrganisationDAO.getUserOrganisation(user.getUserId(),organisationId);
    	if(userOrganisation==null)
    		return null;
    	Role role = roleDAO.getRoleByName(roleName);
    	if(role==null)
    		return null;
    	return userOrganisationRoleDAO.getUserOrganisationRole(userOrganisation.getUserOrganisationId(),role.getRoleId());
    }
    
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getAuthenticationMethodForUser(java.lang.String)
	 */
	public AuthenticationMethod getAuthenticationMethodForUser(String login) {
		return authenticationMethodDAO.getAuthenticationMethodByUser(userDAO.getUserByLogin(login));
	}
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getOrganisationsForUserByRole(com.lamsinternational.lams.usermanagement.User, java.lang.String)
	 */
    public List getOrganisationsForUserByRole(User user, String roleName){
    	List list = new ArrayList();
    	Iterator i = userOrganisationDAO.getUserOrganisationsByUser(user).iterator();
    	while(i.hasNext()){
    		UserOrganisation userOrganisation = (UserOrganisation)i.next();
    		Iterator i2 = userOrganisation.getUserOrganisationRoles().iterator();
    		while(i2.hasNext()){
    			UserOrganisationRole userOrgansiationRole = (UserOrganisationRole)i2.next();
    			if(userOrgansiationRole.getRole().getName().equals(roleName)){
    				list.add(userOrgansiationRole.getUserOrganisation().getOrganisation());
    			}
    		}
    	}
    	return list;
    }

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getRolesForUserByOrganisation(com.lamsinternational.lams.usermanagement.User, java.lang.Integer)
	 */
    public List getRolesForUserByOrganisation(User user, Integer orgId){
    	List list = new ArrayList();
    	UserOrganisation userOrg = userOrganisationDAO.getUserOrganisation(user.getUserId(),orgId);
    	if(userOrg==null)
    		return null;
    	Iterator i = userOrganisationRoleDAO.getUserOrganisationRoles(userOrg.getUserOrganisationId()).iterator();
    	while(i.hasNext()){
    		UserOrganisationRole userOrgRole = (UserOrganisationRole)i.next();
    		list.add(userOrgRole.getRole());
    	}
    	return list;
    }
    
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#getUsersFromOrganisation(int)
	 */
    public List getUsersFromOrganisation(Integer orgId){
    	List list = new ArrayList();
    	Iterator i = userOrganisationDAO.getUserOrganisationsByOrganisationId(orgId).iterator();
    	while(i.hasNext()){
    		UserOrganisation userOrganisation = (UserOrganisation)i.next();
    		list.add(userOrganisation.getUser());
    	}
    	return list;
    }
    
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#createUser(com.lamsinternational.lams.usermanagement.User)
	 */
	public void createUser(User user) {
		userDAO.saveUser(user);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#updateUser(com.lamsinternational.lams.usermanagement.User)
	 */
	public void updateUser(User user) {
		userDAO.updateUser(user);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#updatePassword(java.lang.String,java.lang.String)
	 */
    public void updatePassword(String login, String newPassword){
    	userDAO.updatePassword(login,newPassword);
    }
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#removeUserOrganisation(com.lamsinternational.lams.usermanagement.UserOrganisation)
	 */
	public void removeUserOrganisation(UserOrganisation userOrganisation) {
		userOrganisationDAO.deleteUserOrganisation(userOrganisation);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#saveOrUpdateOrganisation(com.lamsinternational.lams.usermanagement.Organisation)
	 */
	public void saveOrUpdateOrganisation(Organisation organisation) {
		organisationDAO.saveOrUpdateOrganisation(organisation);
	}

	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#saveOrUpdateUserOrganisation(com.lamsinternational.lams.usermanagement.UserOrganisation)
	 */
    public void saveOrUpdateUserOrganisation(UserOrganisation userOrganisation){
    	userOrganisationDAO.saveOrUpdateUserOrganisation(userOrganisation);
    }
	
	/** 
	 * @see com.lamsinternational.lams.usermanagement.service.IUserManagementService#saveOrUpdateUserOrganisationRole(com.lamsinternational.lams.usermanagement.UserOrganisationRole)
	 */
    public void saveOrUpdateUserOrganisationRole(UserOrganisationRole userOrganisationRole){
    	userOrganisationRoleDAO.saveOrUpdateUserOrganisationRole(userOrganisationRole);
    }
}
