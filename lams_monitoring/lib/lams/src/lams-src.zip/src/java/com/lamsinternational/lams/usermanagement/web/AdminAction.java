package com.lamsinternational.lams.usermanagement.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.lamsinternational.lams.usermanagement.Organisation;
import com.lamsinternational.lams.usermanagement.service.UserManagementService;
import com.lamsinternational.lams.web.HttpSessionManager;


/**
 * Main access calls for the normal user adminstration screens.
 * 
 * @author Fei Yang
 * 
 * @struts:action path="/admin"
 * 				  validate="false"
 * 				  parameter="method"
 *
 * @struts:action-forward name="admin" path=".admin"
 * 
 * @struts:action-forward name="organisation" path=".admin.organisation"
 * 
 * @struts:action-forward name="error" path=".admin.error"
 */
public class AdminAction extends DispatchAction {

	private static Logger log = Logger.getLogger(AdminAction.class);

	private static WebApplicationContext ctx = WebApplicationContextUtils
			.getWebApplicationContext(HttpSessionManager.getInstance()
					.getServletContext());

	private static UserManagementService service = (UserManagementService) ctx
			.getBean("userManagementServiceTarget");

	/* ************* Organisation Screens ****************************************************/

	/**
	 * Initial call that loads up the form for editing the
	 * name/description of an organisation.
	 */
	public ActionForward getOrganisationEdit(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {
		log.debug("getOrganisationEdit");
		Integer orgId = null;
		try {
			if (request.getParameter("orgId") != null) {
				orgId = new Integer(request.getParameter("orgId").trim());
			}
		} catch (NumberFormatException e) {
		}

		boolean error = false;

		OrganisationActionForm orgForm = new OrganisationActionForm();

		if (orgId == null || orgId.intValue() == -1) {//create child organisation
			orgForm.setOrgId(new Integer(-1));
			orgForm.setName("");
			orgForm.setDescription("");
			Integer parentOrgId = null;
			try {
				if (request.getParameter("parentOrgId") != null) {
					parentOrgId = new Integer(request.getParameter(
							"parentOrgId").trim());
				}
			} catch (NumberFormatException e) {
			}

			Organisation parent = null;
			if (parentOrgId != null) {
				parent = service.getOrganisationById(parentOrgId);
				if (parent != null) {
					orgForm.setParentOrgId(parent.getOrganisationId());
					orgForm.setParentOrgName(parent.getName());
				}
			}
			if (parent == null) {
				log.warn("Creating new top level organisation (parent organisation id not found)");
			}

		} else {//edit organisation
			Organisation org = service.getOrganisationById(orgId);
			if (org != null) {
				log.debug("Copying properties from org " + org.toString());
				orgForm.setOrgId(org.getOrganisationId());
				orgForm.setName(org.getName());
				orgForm.setDescription(org.getDescription());
			} else {
				log.error("Organisation id " + orgId + " not found");
				error = true;
			}
		}

		request.getSession(true).setAttribute(OrganisationActionForm.formName,
				orgForm);
		return mapping.findForward(error ? "error" : "organisation");
	}

}