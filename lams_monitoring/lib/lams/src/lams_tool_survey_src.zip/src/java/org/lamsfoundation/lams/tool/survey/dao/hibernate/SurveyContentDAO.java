package org.lamsfoundation.lams.tool.survey.dao.hibernate;

import net.sf.hibernate.Hibernate;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;

import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import org.lamsfoundation.lams.tool.survey.SurveyContent;
import org.lamsfoundation.lams.tool.survey.dao.ISurveyContentDAO;

/**
 * 
 * @author Jacky Fang
 */
public class SurveyContentDAO extends HibernateDaoSupport implements
                                                         ISurveyContentDAO
{

    private static final String LOAD_SURVEY_BY_SESSION = "select survey from SurveyContent survey left join fetch "
            + "survey.surveySessions session where session.surveySessionId=:sessionId";

    private static final String COUNT_USER_RESPONSED = "select distinct u.userId from SurveyQueUsr u left join fetch"
            + " u.surveyQueContent as ques where ques.surveyContent = :survey group by u.userId";

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveyContentDAO#getSurveyById(long)
     */
    public SurveyContent getSurveyById(Long surveyId)
    {
        return (SurveyContent) this.getHibernateTemplate()
                                   .load(SurveyContent.class, surveyId);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveyContentDAO#getSurveyBySession(long)
     */
    public SurveyContent getSurveyBySession(final Long sessionId)
    {
        return (SurveyContent) getHibernateTemplate().execute(new HibernateCallback()
                                                     {

                                                         public Object doInHibernate(Session session) throws HibernateException
                                                         {
                                                             return session.createQuery(LOAD_SURVEY_BY_SESSION)
                                                                           .setLong("sessionId",
                                                                                    sessionId.longValue())
                                                                           .uniqueResult();
                                                         }
                                                     });
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveyContentDAO#SaveSurvey(com.lamsinternational.tool.survey.domain.SurveyContent)
     */
    public void SaveSurvey(SurveyContent survey)
    {
        this.getHibernateTemplate().save(survey);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveyContentDAO#UpdateSurvey(com.lamsinternational.tool.survey.domain.SurveyContent)
     */
    public void UpdateSurvey(SurveyContent survey)
    {
        this.getHibernateTemplate().update(survey);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.ISurveyContentDAO#countUserResponsed(org.lamsfoundation.lams.tool.survey.SurveyContent)
     */
    public int countUserResponsed(SurveyContent survey)
    {
        return (getHibernateTemplate().findByNamedParam(COUNT_USER_RESPONSED,
                                                        "survey",
                                                        survey)).size();
    }

    public void removeAllSurveySession(SurveyContent survey)
    {
        this.getHibernateTemplate().deleteAll(survey.getSurveySessions());
    }
    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.ISurveyContentDAO#removeSurvey(org.lamsfoundation.lams.tool.survey.SurveyContent)
     */
    public void removeSurvey(Long surveyId)
    {
        String query = "from survey in class org.lamsfoundation.lams.tool.survey.SurveyContent"
        + " where survey.surveyContentId = ?";
        this.getHibernateTemplate().delete(query,surveyId,Hibernate.LONG);
    }
    
    
    public void flush()
    {
        this.getHibernateTemplate().flush();
    }
}
