
package org.lamsfoundation.lams.tool.survey;


/**
 * This is a constant utility class that defined all constants need to be 
 * shared around the survey tool.
 * 
 * @author Jacky Fang
 *
 */
public class SurveyConstants
{
    /**
     * Private Construtor to avoid instantiation.
     */
    private SurveyConstants(){}
    
    public static final int NOT_SHOWN = -1;
    
    public static final String OPEN_RESPONSE = "Open response";
    
    //-------------------Question Type------------------------//
    public static final String SIMPLE_CHOICE="simpleChoice";
    public static final String MULTIPLE_CHOICE="choiceMultiple";
    public static final String TEXT_ENTRY="textEntry";
    
    public static final int NOT_SHOWN_CANDIDATE_ANSWER_ORDER = -1;
    
}
