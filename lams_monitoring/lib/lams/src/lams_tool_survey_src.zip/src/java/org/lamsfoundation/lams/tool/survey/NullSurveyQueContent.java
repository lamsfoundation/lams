/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2005 
 * Created on 20/01/2005
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey;


/**
 * Null version of Survey Question Content Object.
 * @author Jacky Fang 20/01/2005
 * 
 */
public class NullSurveyQueContent extends SurveyQueContent implements Nullable
{

    /**
     * Empty constructor for null object
     */
    public NullSurveyQueContent()
    {
        super();
    }
    
    /**
     * This object should be null.
     * @see org.lamsfoundation.lams.tool.survey.Nullable#isNull()
     */
    public boolean isNull()
    {
        return true;
    }

}
