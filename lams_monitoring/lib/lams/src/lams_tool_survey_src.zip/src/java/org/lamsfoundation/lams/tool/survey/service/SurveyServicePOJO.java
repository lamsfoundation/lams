package org.lamsfoundation.lams.tool.survey.service;

import java.util.Date;
import java.util.List;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;



import org.lamsfoundation.lams.lesson.Lesson;
import org.lamsfoundation.lams.tool.ILamsToolService;
import org.lamsfoundation.lams.tool.ProgressOutputData;
import org.lamsfoundation.lams.tool.ToolContentManager;
import org.lamsfoundation.lams.tool.ToolSessionExportOutputData;
import org.lamsfoundation.lams.tool.ToolSessionManager;
import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveyContent;
import org.lamsfoundation.lams.tool.survey.SurveySession;
import org.lamsfoundation.lams.tool.survey.dao.IQuestionTypeDAO;
import org.lamsfoundation.lams.tool.survey.dao.ISurveyContentDAO;
import org.lamsfoundation.lams.tool.survey.dao.ISurveySessionDAO;
import org.lamsfoundation.lams.tool.survey.dao.ISurveyUsrRespDAO;
import org.lamsfoundation.lams.usermanagement.User;
import org.lamsfoundation.lams.usermanagement.service.IUserManagementService;




/**
 * The POJO implementation of Survey service. All business logics of survey tool
 * are implemented in this class. It translate the request from presentation
 * layer and perform approporiate database operation.
 * 
 * Two construtors are provided in this class. The constuctor with Hibernate
 * session object allows survey tool to handle long run application transaction.
 * The developer can store Hibernate session in http session and pass across
 * different http request. This implementation also make the testing out side 
 * JBoss container much easier.
 * 
 * Every method is implemented as a Hibernate session transaction. It open an
 * new persistent session or connect to existing persistent session in the 
 * begining and it close or disconnect to the persistent session in the end.
 * 
 * @author Jacky Fang
 *  
 */
public class SurveyServicePOJO implements
                              ISurveyService,
                              ToolSessionManager,
                              ToolContentManager
{

    //---------------------------------------------------------------------
    // Instance variables
    //---------------------------------------------------------------------
    private ISurveyContentDAO surveyDAO;
    private ISurveySessionDAO surveySessionDAO;
    private ISurveyUsrRespDAO surveyUsrRespDAO;
    private IQuestionTypeDAO questionTypeDAO;
    private IUserManagementService userManagementService;
    private ILamsToolService toolService;

    private static Logger log = Logger.getLogger(SurveyServicePOJO.class);

    //---------------------------------------------------------------------
    // Class level constants
    //---------------------------------------------------------------------


    //---------------------------------------------------------------------
    // Property Injection methods
    //---------------------------------------------------------------------
    /**
     * @param surveyDAO The surveyDAO to set.
     */
    public void setSurveyDAO(ISurveyContentDAO surveyDAO)
    {
        this.surveyDAO = surveyDAO;
    }

    /**
     * @param surveySessionDAO The surveySessionDAO to set.
     */
    public void setSurveySessionDAO(ISurveySessionDAO surveySessionDAO)
    {
        this.surveySessionDAO = surveySessionDAO;
    }

    /**
     * @param surveyUsrRespDAO The surveyUsrRespDAO to set.
     */
    public void setSurveyUsrRespDAO(ISurveyUsrRespDAO surveyUsrRespDAO)
    {
        this.surveyUsrRespDAO = surveyUsrRespDAO;
    }

    /**
     * @param questionTypeDAO The questionTypeDAO to set.
     */
    public void setQuestionTypeDAO(IQuestionTypeDAO questionTypeDAO)
    {
        this.questionTypeDAO = questionTypeDAO;
    }
    /**
     * @param userManagementService The userManagementService to set.
     */
    public void setUserManagementService(IUserManagementService userManagementService)
    {
        this.userManagementService = userManagementService;
    }

    /**
     * @param toolService The toolService to set.
     */
    public void setToolService(ILamsToolService toolService)
    {
        this.toolService = toolService;
    }

    //---------------------------------------------------------------------
    // Interface implementation methods - ISurveyService
    //---------------------------------------------------------------------

    /**
     * Retrieve the survey object against the runtime task instance id. It
     * starts a new Hibernate session.
     * 
     * @param taskInstance
     *            the run time task instance for survey tool.
     * @return the Hibernate survey value object.
     * @throws SystemException
     *             unchecked exception that wrap the hibernate processing
     *             exceptions apart from the JDBCException, which is translated
     *             into DataAccessExcption in DAO layer.
     * @see com.webmcq.ld.tool.survey.ISurveyService#retrieveSurvey()
     */
    public SurveyContent retrieveSurveyBySession(long surveySessionId)
    {
        try
        {
            return surveyDAO.getSurveyBySession(new Long(surveySessionId));
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is loading survey: "
                                                         + e.getMessage(),
                                                 e);
        }
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.service.ISurveyService#retrieveSurveySession(long)
     */
    public SurveySession retrieveSurveySession(long toolSessionId)
    {
        try
        {
            return surveySessionDAO.getSurveySessionById(new Long(toolSessionId));
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is loading survey: "
                                                         + e.getMessage(),
                                                 e);
        }

    }
    /**
     * @see org.lamsfoundation.lams.tool.survey.service.ISurveyService#retrieveSurvey(long)
     */
    public SurveyContent retrieveSurvey(long toolContentId)
    {
        try
        {
            return surveyDAO.getSurveyById(new Long(toolContentId));
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is loading survey: "
                                                         + e.getMessage(),
                                                 e);
        }
    }
    /**
     * Implementation of count user method.
     * @see com.webmcq.ld.tool.survey.ISurveyService#countTotalNumberOfUserResponsed(com.webmcq.ld.tool.survey.entity.SurSurveyVO)
     */
    public int countTotalNumberOfUserResponsed(SurveyContent survey)
    {
        try
        {
            return surveyDAO.countUserResponsed(survey);
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured in [countTotalNumberOfUserResponsed]: "
                                                         + e.getMessage(),
                                                 e);
        }
    }

    /**
     * Implementation to get user data from UserServiceDelegate
     * @see com.webmcq.ld.tool.survey.ISurveyService#getCurrentUserData(java.lang.String)
     */
    public User getCurrentUserData(String username)
    {
        try
        {
            
            return userManagementService.getUserByLogin(username);
            //Below is a mock implementation and should be change when 
            //user management service package is done.
            /**User user = new User();
            user.setFirstName("Yang");
            user.setLastName("Fei");
            user.setLogin("sysadmin");
            user.setUserId(new Integer(1));
            return user;*/
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Unable to find current user information"
                                                         + " Root Cause: ["
                                                         + e.getMessage() + "]",
                                                 e);
        }

    }

    /**
     * Retrieve the learning session value object for current running session. 
     * TODO change mock implementation to real service once it is available.
     * @see com.webmcq.ld.tool.survey.ISurveyService#getCurrentLearningSession(long)
     */
    public Lesson getCurrentLesson(long lessonId)
    {
        try
        {
            //this is a mock implementation to make the project compile and 
            //work. When the Lesson service is ready, we need to switch to 
            //real service implmenation.
            return new Lesson();
            //return lsDAO.find(lsessionId);
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is loading"
                                                         + " learning session:"
                                                         + e.getMessage(),
                                                 e);
        }

    }

    /**
     * Persistent user response into database.
     * @see com.webmcq.ld.tool.survey.ISurveyService#saveUserResponses(java.util.List,
     *      long, long)
     */
    public void saveUserResponses(List responses, long toolSessionId, User user)
    {
        try
        {
            SurveySession curSession = surveySessionDAO.getSurveySessionById(new Long(toolSessionId));

            curSession.setSessionStatus(SurveySession.INCOMPLETE);
            //remove the question user no longer exist 
            curSession.removeQueUsersBy(responses);
            //update the existing question user.
            curSession.updateQueUsersBy(responses);
            //add new question users
            curSession.addNewQueUsersBy(responses);
            //persist the updates
            surveySessionDAO.UpdateSurveySession(curSession);

        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is saving"
                                                         + " user responses: "
                                                         + e.getMessage(),
                                                 e);
        }
    }

    /**
     * Return the number of potential learner who should participate the survey.
     * @param surveyContentId the current survey content
     * @see org.lamsfoundation.lams.tool.survey.service.ISurveyService#getSurveyClassSize(java.lang.Long)
     */
    public int getSurveyClassSize(Long surveyContentId)
    {
        //pre-condition validation
        if (surveyContentId == null)
            throw new SurveyApplicationException("We can't caculate number"
                    + "of potential survey learner with null survey content id.");
/**   	
        try
        {
            return toolService.getAllPotentialLearners(surveyContentId.longValue())
                              .size();
        }
        catch (LamsToolServiceException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is caculating"
                                                         + " potential survey learners: "
                                                         + e.getMessage(),
                                                 e);
        }
*/
        //TODO need to change to above implementation once it is done.
        return 10;
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.service.ISurveyService#saveSurveyContent(org.lamsfoundation.lams.tool.survey.SurveyContent)
     */
    public void saveSurveyContent(SurveyContent survey)
    {
        try
        {
            surveyDAO.SaveSurvey(survey);
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is saving"
                                                 + " the survey content: "
                                                 + e.getMessage(),e);
        }
        
    }
    
    /**
     * @see org.lamsfoundation.lams.tool.survey.service.ISurveyService#updateSurvey(org.lamsfoundation.lams.tool.survey.SurveyContent)
     */
    public void updateSurvey(SurveyContent survey)
    {
        try
        {
            surveyDAO.UpdateSurvey(survey);
        }
        catch(DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is updating"
                                                 + " the survey content: "
                                                 + e.getMessage(),e);
        }
    }
    
    /**
     * @see org.lamsfoundation.lams.tool.survey.service.ISurveyService#getQuestionTypes()
     */
    public List getQuestionTypes()
    {
        try
        {
            return questionTypeDAO.getAllQuestionTypes();
        }
        catch(DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is loading"
                                                 + " available question types: "
                                                 + e.getMessage(),e);
        }
    }
    


    //---------------------------------------------------------------------
    // Interface implementation methods - ToolContentManager
    //---------------------------------------------------------------------
    /**
     * <p>Make a copy of tool content for runtime modification.</p>
     * <p>Pre-condition: Lams core caculated the destination tool content id.</p>
     * @param fromContentId the original tool content id.
     * @param toContentId the destination tool content id.
     * @see org.lamsfoundation.lams.tool.ToolContentManager#copyToolContent(java.lang.Long, java.lang.Long)
     */
    public void copyToolContent(Long fromContentId, Long toContentId)
    {
        //pre-condition validation
        if (fromContentId == null || toContentId == null)
            throw new SurveyApplicationException("Fail to create a survey session"
                    + " based on null toolSessionId or toolContentId");
        try
        {
            SurveyContent fromContent = surveyDAO.getSurveyById(fromContentId);

            SurveyContent toContent = SurveyContent.newInstance(fromContent,toContentId);

            surveyDAO.SaveSurvey(toContent);
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is creating"
                                                  + " runtime copy of tool content: "
                                                  + e.getMessage(),e);
        }
    }

    /**
     * @see org.lamsfoundation.lams.tool.ToolContentManager#removeToolContent(java.lang.Long)
     */
    public void removeToolContent(Long toolContentId)
    {
        SurveyContent scontent = surveyDAO.getSurveyById(toolContentId);

        surveyDAO.removeAllSurveySession(scontent);
        surveyDAO.removeSurvey(toolContentId);        
    }
    //---------------------------------------------------------------------
    // Interface implementation methods - ToolSessionManager
    //---------------------------------------------------------------------

    /**
     * <p>Create a new survey session based on the survey content. As this happens
     * before the learner participate the survey, the session state has to be
     * set to <code>NOT_ATTEMPTED</code>.</p>
     * 
     * <p>Pre-condition:tool session id and tool content id are not null</p>
     * 
     * @param toolSessionId lams caculated tool session id
     * @param toolContentId lams caculated tool content id
     * 
     * @see org.lamsfoundation.lams.tool.ToolSessionManager#createToolSession(java.lang.Long, java.lang.Long)
     */
    public void createToolSession(Long toolSessionId, Long toolContentId)
    {
        //pre-condition validation
        if (toolSessionId == null || toolContentId == null)
            throw new SurveyApplicationException("Fail to create a survey session"
                    + " based on null toolSessionId or toolContentId");

        log.debug("Start to create survey session based on toolSessionId["
                + toolSessionId.longValue() + "] and toolContentId["
                + toolContentId.longValue() + "]");
        try
        {
            SurveyContent surveyContent = surveyDAO.getSurveyById(toolContentId);

            SurveySession surveySession = new SurveySession(toolSessionId,
                                                            new Date(System.currentTimeMillis()),
                                                            SurveySession.NOT_ATTEMPTED,
                                                            surveyContent,
                                                            new TreeSet());
            surveySessionDAO.CreateSurveySession(surveySession);
            log.debug("Survey session created");
        }
        catch (DataAccessException e)
        {
            throw new SurveyApplicationException("Exception occured when lams is creating"
                                                         + " a survey Session: "
                                                         + e.getMessage(),e);
        }
    }

    /**
     * Call controller service to complete the survey session
     * TODO change mock implementation to real service once it is available.
     * @see org.lamsfoundation.lams.tool.ToolSessionManager#leaveToolSession(java.lang.Long)
     */
    public ProgressOutputData leaveToolSession(Long toolSessionId)
    {
        throw new UnsupportedOperationException("not yet implemented");
    }

    /**
     * @see org.lamsfoundation.lams.tool.ToolSessionManager#exportToolSession(java.lang.Long)
     */
    public ToolSessionExportOutputData exportToolSession(Long toolSessionId)
    {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("not yet implemented");
    }

    /**
     * @see org.lamsfoundation.lams.tool.ToolSessionManager#exportToolSession(java.util.List)
     */
    public ToolSessionExportOutputData exportToolSession(List toolSessionIds)
    {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("not yet implemented");
    }

}
