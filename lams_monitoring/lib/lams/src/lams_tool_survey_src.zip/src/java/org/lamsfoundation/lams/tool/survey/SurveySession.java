package org.lamsfoundation.lams.tool.survey;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.lamsfoundation.lams.tool.ToolSession;


/** 
 *        @hibernate.class
 *         table="tool_lasr10_survey_session"
 *     
 */
public class SurveySession extends ToolSession implements Serializable,Nullable
{

    public final static String NOT_ATTEMPTED = "NOT_ATTEMPTED";
    
    public final static String INCOMPLETE = "INCOMPLETE";
    
    public static final String COMPLETED = "COMPLETED";
    
    /** identifier field */
    private Long surveySessionId;

    /** nullable persistent field */
    private Date sessionStartDate;

    /** nullable persistent field */
    private Date sessionEndDate;
    
    /** nullable persistent field */
    private String sessionStatus;
    
    /** persistent field */
    private SurveyContent surveyContent;

    /** persistent field */
    private Set surveyQueUsrs;



    /** full constructor */
    public SurveySession(Long surveySessionId,
                         Date sessionStartDate,
                         Date sessionEndDate,
                         String sessionStatus,
                         SurveyContent surveyContent,
                         Set surveyQueUsrs)
    {
        this.surveySessionId = surveySessionId;
        this.sessionStartDate = sessionStartDate;
        this.sessionEndDate = sessionEndDate;
        this.sessionStatus = sessionStatus;
        this.surveyContent = surveyContent;
        this.surveyQueUsrs = surveyQueUsrs;
    }

    /** default constructor */
    public SurveySession()
    {
    }

    /**
     * Construtor for initializing survey session.
     * @param sessionStartDate
     * @param sessionStatus
     * @param surveyContent
     * @param surveyQueUsrs
     */
    public SurveySession(Long surveySessionId,
                         Date sessionStartDate,
                         String sessionStatus,
                         SurveyContent surveyContent,
                         Set surveyQueUsrs)
    {
        this(surveySessionId,sessionStartDate,null,sessionStatus,surveyContent,surveyQueUsrs);
    }

    /** 
     *            @hibernate.id
     *             generator-class="assigned"
     *             type="java.lang.Long"
     *             column="survey_session_id"
     *         
     */
    public Long getSurveySessionId()
    {
        return this.surveySessionId;
    }

    public void setSurveySessionId(Long surveySessionId)
    {
        this.surveySessionId = surveySessionId;
    }

    /** 
     *            @hibernate.property
     *             column="session_start_date"
     *             length="10"
     *         
     */
    public Date getSessionStartDate()
    {
        return this.sessionStartDate;
    }

    public void setSessionStartDate(Date sessionStartDate)
    {
        this.sessionStartDate = sessionStartDate;
    }

    /** 
     *            @hibernate.property
     *             column="session_end_date"
     *             length="10"
     *         
     */
    public Date getSessionEndDate()
    {
        return this.sessionEndDate;
    }

    public void setSessionEndDate(Date sessionEndDate)
    {
        this.sessionEndDate = sessionEndDate;
    }


    /**
     * @hibernate.property column="session_status" length="128"
     * @return Returns the sessionStatus.
     */
    public String getSessionStatus()
    {
        return sessionStatus;
    }
    /**
     * @param sessionStatus The sessionStatus to set.
     */
    public void setSessionStatus(String sessionStatus)
    {
        this.sessionStatus = sessionStatus;
    }
    
    /** 
     *            @hibernate.many-to-one
     *             not-null="true"
     *            @hibernate.column name="survey_content_id"         
     *         
     */
    public SurveyContent getSurveyContent()
    {
        return this.surveyContent;
    }

    public void setSurveyContent(SurveyContent surveyContent)
    {
        this.surveyContent = surveyContent;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="all-delete-orphan"
     * @hibernate.collection-key column="survey_session_id"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyQueUsr"
     *         
     */
    public Set getSurveyQueUsrs()
    {
        if (this.surveyQueUsrs == null)
            setSurveyQueUsrs(new TreeSet());
        return this.surveyQueUsrs;
    }

    public void setSurveyQueUsrs(Set surveyQueUsrs)
    {
        this.surveyQueUsrs = surveyQueUsrs;
    }

    
    //---------------------------------------------------------------------
    // Domain Service Methods
    //---------------------------------------------------------------------
    /**
     * 
     * @param responses
     */
    public void removeQueUsersBy(List responses)
    {
        //make a copy of que user to avoid concurrent modification exception
        Set queUserSet = new TreeSet(this.getSurveyQueUsrs());

        for (Iterator i = queUserSet.iterator(); i.hasNext();)
        {
            SurveyQueUsr curUser = (SurveyQueUsr) i.next();
            //remove question user object if no new response has reference
            //to it.
            if (!curUser.checkUpQueUsrHas(responses))
                this.getSurveyQueUsrs().remove(curUser);
        }
    }

    /**
     * 
     * @param responses
     */
    public void updateQueUsersBy(List responses)
    {
        
        for (Iterator i = this.getSurveyQueUsrs().iterator(); i.hasNext();)
        {
            SurveyQueUsr curUser = (SurveyQueUsr) i.next();
            if (curUser.checkUpQueUsrHas(responses))
                curUser.updateQueUsr(responses);
        }
    }
    
    /**
     * @param responses
     */
    public void addNewQueUsersBy(List responses)
    {
        //make a defensive a copy to avoid mutation from outside.
        ArrayList resps = new ArrayList(responses);
        for(Iterator i = resps.iterator();i.hasNext();)
        {
            SurveyUsrResp response = (SurveyUsrResp)i.next();
            SurveyQueUsr queUser = response.getSurveyQueUsr();
            if(!isQueUsrExist(queUser))
                this.getSurveyQueUsrs().add(queUser);
        }
    }


    /**
     * @param queUser
     * @return
     */
    private boolean isQueUsrExist(SurveyQueUsr queUser)
    {
        for(Iterator i = this.getSurveyQueUsrs().iterator();i.hasNext();)
        {
            SurveyQueUsr curUser = (SurveyQueUsr)i.next();
            if(curUser.getSurveyQueContent().equals(queUser.getSurveyQueContent()))
                return true;
        }
        return false;
    }

    public String toString()
    {
        return new ToStringBuilder(this).append("surveySessionId",getSurveySessionId())
                                        .append("session start date",getSessionStartDate())
                                        .append("session end date",getSessionEndDate())
                                        .append("session status",getSessionStatus())
                                        .append("survey content",getSurveyContent())
                                        .append("survey Question users",getSurveyQueUsrs())
                                        .toString();
    }

    public boolean equals(Object other)
    {
        if (!(other instanceof SurveySession))
            return false;
        SurveySession castOther = (SurveySession) other;
        return new EqualsBuilder().append(this.getSurveySessionId(),
                                          castOther.getSurveySessionId())
                                  .isEquals();
    }

    public int hashCode()
    {
        return new HashCodeBuilder().append(getSurveySessionId()).toHashCode();
    }

    /**
     * This object should not be null.
     * @see org.lamsfoundation.lams.tool.survey.Nullable#isNull()
     */
    public boolean isNull()
    {
        return false;
    }

}
