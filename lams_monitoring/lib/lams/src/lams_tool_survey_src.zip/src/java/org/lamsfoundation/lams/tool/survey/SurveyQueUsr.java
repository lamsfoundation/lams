package org.lamsfoundation.lams.tool.survey;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** 
 * @hibernate.class table="tool_lasr10_survey_que_usr"
 *     
 */
public class SurveyQueUsr implements Serializable, Comparable
{

    /** identifier field */
    private Long queUsrId;

    /** nullable persistent field */
    private Long userId;

    /** nullable persistent field */
    private String username;

    /** nullable persistent field */
    private String fullName;

    /** persistent field */
    private SurveyQueContent surveyQueContent;

    /** persistent field */
    private SurveySession surveySession;

    /** persistent field */
    private Set surveyUsrResps;

    /** full constructor */
    public SurveyQueUsr(Long userId,
                        String username,
                        String fullName,
                        SurveyQueContent surveyQueContent,
                        SurveySession surveySession,
                        Set surveyUsrResps)
    {
        this.userId = userId;
        this.username = username;
        this.fullName = fullName;
        this.surveyQueContent = surveyQueContent;
        this.surveySession = surveySession;
        this.surveyUsrResps = surveyUsrResps;
    }

    /** default constructor */
    public SurveyQueUsr()
    {
    }

    /** minimal constructor */
    public SurveyQueUsr(SurveyQueContent surveyQueContent,
                        SurveySession surveySession,
                        Set surveyUsrResps)
    {
        this.surveyQueContent = surveyQueContent;
        this.surveySession = surveySession;
        this.surveyUsrResps = surveyUsrResps;
    }

    /**
     * @param test_user_id
     * @param test_username
     * @param question
     * @param surSession
     */
    public SurveyQueUsr(Long user_id,
                        String username,
                        String fullName,
                        SurveyQueContent question,
                        SurveySession surSession)
    {
        this.userId = user_id;
        this.username = username;
        this.fullName = fullName;
        this.surveyQueContent = question;
        this.surveySession = surSession;
    }

    /**
     * Copy construtor; We copy all data except the hibernate id field.
     * @param queUsr the original survey question user object.
     * @return the survey question user object.
     */
    public SurveyQueUsr newInstance(SurveyQueUsr queUsr)
    {
        return new SurveyQueUsr(queUsr.getUserId(),
                                queUsr.getUsername(),
                                queUsr.getFullName(),
                                queUsr.getSurveyQueContent(),
                                queUsr.getSurveySession(),
                                queUsr.getSurveyUsrResps());
    }

    /** 
     * @hibernate.id generator-class="increment" type="java.lang.Long"
     * 				 column="que_usr_id"
     */
    public Long getQueUsrId()
    {
        return this.queUsrId;
    }

    public void setQueUsrId(Long queUsrId)
    {
        this.queUsrId = queUsrId;
    }

    /** 
     * @hibernate.property column="user_id" length="20"
     */
    public Long getUserId()
    {
        return this.userId;
    }

    public void setUserId(Long userId)
    {
        this.userId = userId;
    }

    /** 
     * @hibernate.property column="username" length="100"
     *         
     */
    public String getUsername()
    {
        return this.username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * @hibernate.property column="fullname" length="100"
     * @return Returns the fullName.
     */
    public String getFullName()
    {
        return fullName;
    }

    /**
     * @param fullName The fullName to set.
     */
    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    /** 
     * @hibernate.many-to-one not-null="true" 
     * @hibernate.column name="survey_que_content_id"         
     *         
     */
    public SurveyQueContent getSurveyQueContent()
    {
        return this.surveyQueContent;
    }

    public void setSurveyQueContent(SurveyQueContent surveyQueContent)
    {
        this.surveyQueContent = surveyQueContent;
    }

    /** 
     * @hibernate.many-to-one  not-null="true"
     * @hibernate.column name="survey_session_id"         
     *         
     */
    public SurveySession getSurveySession()
    {
        return this.surveySession;
    }

    public void setSurveySession(SurveySession surveySession)
    {
        this.surveySession = surveySession;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="all-delete-orphan"
     * @hibernate.collection-key column="que_usr_id"
     * @hibernate.collection-one-to-many class="org.lamsfoundation.lams.tool.survey.SurveyUsrResp"
     *         
     */
    public Set getSurveyUsrResps()
    {
        if (this.surveyUsrResps == null)
            setSurveyUsrResps(new TreeSet());
        return this.surveyUsrResps;
    }

    public void setSurveyUsrResps(Set surveyUsrResps)
    {
        this.surveyUsrResps = surveyUsrResps;
    }

    //---------------------------------------------------------------------
    // Convenient Service Methods
    //---------------------------------------------------------------------
    /**
     * Check up question responsed by current user against a list user responses.
     * Return <code>true</code> if 
     * @param responses
     * @return the validation result
     */
    public boolean checkUpQueUsrHas(List responses)
    {
        if (responses == null)
            throw new IllegalArgumentException("Invalid responses from "
                    + this.getFullName() + ": Can't validate null responses"
                    + "against current survey questions");

        //make defensive copy to avoid list mutation outside this class.
        ArrayList resps = new ArrayList(responses);

        for (Iterator i = resps.iterator(); i.hasNext();)
        {
            SurveyUsrResp resp = (SurveyUsrResp) i.next();
            if (doesQueUserHas(resp))
                return true;
        }
        return false;
    }

    /**
     * Update the user responses of this question user object against a list of
     * new user responses.
     * @param responses
     */
    public void updateQueUsr(List responses)
    {
        if (responses == null)
            throw new IllegalArgumentException("Invalid responses from "
                    + this.getFullName() + ": Can't update null responses"
                    + "against current survey questions");

        //make defensive copy to avoid list mutation outside this class.
        ArrayList resps = new ArrayList(responses);
        //clean up all the existing reponses
        removeResponseBy(resps);
        addNewResponsesBy(resps);
        updateExistingResp(resps);
    }

    /**
     * @param resps
     * @param responseList
     */
    public void addNewResponsesBy(ArrayList resps)
    {
        ArrayList responseList = new ArrayList(this.getSurveyUsrResps());
        //add all associated new responses into the current question user.
        for (Iterator i = resps.iterator(); i.hasNext();)
        {
            SurveyUsrResp resp = (SurveyUsrResp) i.next();
            if (!resp.doesRespExistIn(responseList)&&doesQueUserHas(resp))
                addUserResponse(resp);
        }
    }

    /**
     * @param responses
     * @param responseSet
     */
    public void removeResponseBy(ArrayList responses)
    {
        Set responseSet = new TreeSet(this.getSurveyUsrResps());
        //remove responses no longer exist.
        for(Iterator i = responseSet.iterator();i.hasNext();)
        {
            SurveyUsrResp resp = (SurveyUsrResp) i.next();
            if(!resp.doesRespExistIn(responses))
                this.getSurveyUsrResps().remove(resp);
        }
    }

    /**
     * @param responses
     * @param responseSet
     */
    public void updateExistingResp(ArrayList responses)
    {
        //update existing responses
        for(Iterator i = this.getSurveyUsrResps().iterator();i.hasNext();)
        {
            SurveyUsrResp resp = (SurveyUsrResp) i.next();
            if(resp.doesRespExistIn(responses))
                resp.updateResponseBy(responses);                
        }
    }

    /**
     * @param resp
     */
    public void addUserResponse(SurveyUsrResp resp)
    {
        if (resp != null && !resp.isResponseValid())
            throw new IllegalArgumentException("Invalid response for update ");

        if (resp.getSurveyAnsContent().isNull())
            resp.addNewAnswerContent();

        this.getSurveyUsrResps().add(resp);
    }

    /**
     * @param answerEntry
     * @return
     */
    public boolean isChosenByUser(String answerEntry)
    {
        for(Iterator i = this.getSurveyUsrResps().iterator();i.hasNext();)
        {
            SurveyUsrResp res = (SurveyUsrResp)i.next();
            if(res.getAnswer().equals(answerEntry))
                return true;
        }
        return false;
    }
    public String toString()
    {
        return new ToStringBuilder(this).append("queUsrId", getQueUsrId())
        								.append("userId",getUserId())
        								.append("username",getUsername())
        								.append("full name",getFullName())
        								.append("survey que content",getSurveyQueContent())
        								.append("survey session",getSurveySession())
        								.append("survey user responses",getSurveyUsrResps())
                                        .toString();
    }

    public boolean equals(Object other)
    {
        if (!(other instanceof SurveyQueUsr))
            return false;
        SurveyQueUsr castOther = (SurveyQueUsr) other;
        return new EqualsBuilder().append(this.getQueUsrId(),castOther.getQueUsrId())
                                  .append(this.getUserId(),castOther.getUserId())
                                  .append(this.getSurveyQueContent(),castOther.getSurveyQueContent())
                                  .isEquals();
    }

    public int hashCode()
    {
        return new HashCodeBuilder().append(getQueUsrId())
                                    .append(getUserId())
                                    .toHashCode();
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o)
    {
        SurveyQueUsr qUser = (SurveyQueUsr) o;
        if (this.surveyQueContent == null
                && qUser.getSurveyQueContent() == null)
            return String.CASE_INSENSITIVE_ORDER.compare(username,
                                                         qUser.username);
        if (this.surveyQueContent == null)
            return 1;
        if (qUser.getSurveyQueContent() == null)
            return -1;
              
        return this.getSurveyQueContent().compareTo(qUser.getSurveyQueContent());
    }

    /**
     * The helper function to validate the availability of a user response for
     * this question user.
     * The condition to return true is:<br>
     * <li>the requested response has a reference to a question user object 
     * and reference id is the same as current question user object.</li>
     * 
     * @param response the user response
     * @return the validation result
     */
    public boolean doesQueUserHas(SurveyUsrResp response)
    {
        if (response.getSurveyQueUsr() == null)
            throw new IllegalArgumentException("Invalid response :"
                    + " Can't validate the availability"
                    + " of a response without the reference to a user");
        
        if(response.getSurveyQueUsr().getQueUsrId()==null||this.getQueUsrId()==null)
            return false;
        
        if (this.getQueUsrId().equals(response.getSurveyQueUsr().getQueUsrId()))
            return true;
        return false;
    }

    /**
     * Get a list of user response Strings that are correspondent to the 
     * authored defined candidate answers. Currently, we include the free
     * text answer to this category as well. 
     * 
     * @return the list of String user responses
     */
    public List getPredefinedResponse()
    {
        LinkedList responses = new LinkedList();
        
        for(Iterator i = this.getSurveyUsrResps().iterator();i.hasNext();)
        {
            SurveyUsrResp res = (SurveyUsrResp)i.next();
            if(res.isPredefinedResponse())
            {
                responses.add(res.getAnswer());
            }
        }
        return responses;
    }

    /**
     * Get the answer that the author doesn't know about. 
     * @return the answer if there is. Otherwise return empty String
     */
    public String getOtherResponse()
    {
        for(Iterator i = this.getSurveyUsrResps().iterator();i.hasNext();)
        {
            SurveyUsrResp res = (SurveyUsrResp)i.next();
            if(!res.isPredefinedResponse())
                return res.getAnswer();
        }
        
        return "";
    }
    
    /**
     * Retrieve the answer string for text entry from user response value 
     * object.
     * 
     * @return the answer entry if we can get the answer, otherwise return 
     * 		   empty String.
     */
    public String getTextEntry()
    {
        for(Iterator i = this.getSurveyUsrResps().iterator();i.hasNext();)
        {
            SurveyUsrResp res = (SurveyUsrResp)i.next();
            //find answer, don't want to return empty String
            if(res.getAnswer()!=null&&!res.getAnswer().equals(""))
                return res.getAnswer();
        }
        return "";
    }
}
