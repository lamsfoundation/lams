/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2004 
 * Created on 2004-12-6
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey.dao;

import org.lamsfoundation.lams.tool.survey.SurveyUsrResp;


/**
 * 
 * @author Jacky Fang 2004-12-6
 * 
 */
public interface ISurveyUsrRespDAO
{
    public void saveUserResponse(SurveyUsrResp resp);
    
    public void updateUserResponse(SurveyUsrResp resp);
}
