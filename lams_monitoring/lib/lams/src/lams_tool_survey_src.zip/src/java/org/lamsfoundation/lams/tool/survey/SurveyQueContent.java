package org.lamsfoundation.lams.tool.survey;


import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieItemLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.lamsfoundation.lams.usermanagement.User;

/** 
 * @hibernate.class table="tool_lasr10_survey_que_content"
 *     
 */
public class SurveyQueContent implements Serializable, Comparable, Nullable
{

    /** identifier field */
    private Long surveyQueContentId;

    /** nullable persistent field */
    private String question;

    /** nullable persistent field */
    private int displayOrder;

    /** nullable persistent field */
    private boolean isOptional;

    /** nullable persistent field */
    private boolean isTextBoxEnabled;

    /** persistent field */
    private SurveyContent surveyContent;

    /** nullable persistent field */
    private SurveyQueType surveyQueType;

    /** persistent field */
    private Set surveyUsrResps;

    /** persistent field */
    private Set surveyAnsContents;

    /** persistent field */
    private Set surveyQueUsrs;

    /** persistent field */
    private Set subQuestions;

    /** persistent field */
    private SurveyQueContent parentQuestion;

    /** Struts form convenient field */
    private String[] userResponses = {};

    /** Struts form convenient field */
    private String otherResponse;

    private Set answerIndex = new TreeSet();

    private int maxAnswerDispalyOrder;

    private int maxSubQuestionDisplayOrder;

    //---------------------------------------------------------------------
    // Constructors
    //---------------------------------------------------------------------
    /** full constructor 
     * @param subQuestions TODO
     * @param parentQuestion TODO*/
    public SurveyQueContent(String question,
                            int displayOrder,
                            boolean isOptional,
                            boolean isTextBoxEnabled,
                            SurveyContent surveyContent,
                            SurveyQueType surveyQueType,
                            Set surveyUsrResps,
                            Set surveyAnsContents,
                            Set surveyQueUsrs,
                            Set subQuestions,
                            SurveyQueContent parentQuestion)
    {
        this.question = question;
        this.displayOrder = displayOrder;
        this.isOptional = isOptional;
        this.isTextBoxEnabled = isTextBoxEnabled;
        this.surveyContent = surveyContent;
        this.surveyQueType = surveyQueType;
        this.surveyUsrResps = surveyUsrResps;
        this.surveyAnsContents = surveyAnsContents;
        this.surveyQueUsrs = surveyQueUsrs;
        this.subQuestions = subQuestions;
        this.parentQuestion = parentQuestion;
    }

    /** default constructor */
    public SurveyQueContent()
    {
    }

    /**
     * Copy constructor
     * @param queContent the original survey question content
     * @return the new survey question content object
     */
    public static SurveyQueContent newInstance(SurveyQueContent queContent,
                                               SurveyContent newSurveyContent,
                                               SurveyQueContent parentQuestion)
    {
        SurveyQueContent newQueContent = new SurveyQueContent(queContent.getQuestion(),
                                                              queContent.getDisplayOrder(),
                                                              queContent.getIsOptional(),
                                                              queContent.getIsTextBoxEnabled(),
                                                              newSurveyContent,
                                                              queContent.getSurveyQueType(),
                                                              new TreeSet(),
                                                              new TreeSet(),
                                                              new TreeSet(),
                                                              new TreeSet(),
                                                              parentQuestion);
        newQueContent.setSurveyAnsContents(queContent.deepCopyAnsContent(newQueContent));
        newQueContent.setSubQuestions(queContent.deepCopySubQueContent(newQueContent));
        return newQueContent;
    }

    //---------------------------------------------------------------------
    // Hibernate Access Methods
    //---------------------------------------------------------------------

    /** 
     * @hibernate.id generator-class="increment" type="java.lang.Long"
     *               column="survey_que_content_id"
     *         
     */
    public Long getSurveyQueContentId()
    {
        return this.surveyQueContentId;
    }

    public void setSurveyQueContentId(Long surveyQueContentId)
    {
        this.surveyQueContentId = surveyQueContentId;
    }

    /** 
     * @hibernate.property column="question" length="65535"
     */
    public String getQuestion()
    {
        return this.question;
    }

    public void setQuestion(String question)
    {
        this.question = question;
    }

    /** 
     * @hibernate.property column="display_order" length="11"
     *         
     */
    public int getDisplayOrder()
    {
        return this.displayOrder;
    }

    public void setDisplayOrder(int displayOrder)
    {
        this.displayOrder = displayOrder;
    }

    /** 
     * @hibernate.property column="isOptional" length="1"
     *         
     */
    public boolean getIsOptional()
    {
        return this.isOptional;
    }

    public void setIsOptional(boolean isOptional)
    {
        this.isOptional = isOptional;
    }

    /** 
     * @hibernate.property column="isTextBoxEnabled" length="1"
     *         
     */
    public boolean getIsTextBoxEnabled()
    {
        return this.isTextBoxEnabled;
    }

    public void setIsTextBoxEnabled(boolean isTextBoxEnabled)
    {
        this.isTextBoxEnabled = isTextBoxEnabled;
    }

    /** 
     * @hibernate.many-to-one not-null="true"
     * @hibernate.column name="survey_content_sid"         
     *         
     */
    public SurveyContent getSurveyContent()
    {
        return this.surveyContent;
    }

    public void setSurveyContent(SurveyContent surveyContent)
    {
        this.surveyContent = surveyContent;
    }

    /** 
     * @hibernate.many-to-one
     * @hibernate.column name="question_type_id"         
     *         
     */
    public SurveyQueType getSurveyQueType()
    {
        return this.surveyQueType;
    }

    public void setSurveyQueType(SurveyQueType surveyQueType)
    {
        this.surveyQueType = surveyQueType;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="none" sort="natural"
     * @hibernate.collection-key column="survey_que_content_id"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyUsrResp"
     *         
     */
    public Set getSurveyUsrResps()
    {
        if (this.surveyUsrResps == null)
            setSurveyUsrResps(new TreeSet());
        return this.surveyUsrResps;
    }

    public void setSurveyUsrResps(Set surveyUsrResps)
    {
        this.surveyUsrResps = surveyUsrResps;
    }

    /**
     * @return Returns the userResponse.
     */
    public String[] getUserResponses()
    {
        return userResponses;
    }

    /**
     * @param userResponse The userResponse to set.
     */
    public void setUserResponses(String[] userResponse)
    {
        this.userResponses = userResponse;
    }

    /**
     * @return Returns the otherResponse.
     */
    public String getOtherResponse()
    {
        return otherResponse == null ? null : otherResponse.trim();
    }

    /**
     * @param otherResponse The otherResponse to set.
     */
    public void setOtherResponse(String otherResponse)
    {
        this.otherResponse = otherResponse;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="all-delete-orphan"
     *                sort="natural"
     * @hibernate.collection-key column="survey_que_content_id"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyAnsContent"
     *         
     */
    public Set getSurveyAnsContents()
    {
        if (this.surveyAnsContents == null)
            setSurveyAnsContents(new TreeSet());
        return this.surveyAnsContents;
    }

    public void setSurveyAnsContents(Set surveyAnsContents)
    {
        this.surveyAnsContents = surveyAnsContents;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="none"
     * @hibernate.collection-key column="survey_que_content_id"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyQueUsr"
     *         
     */
    public Set getSurveyQueUsrs()
    {
        if (this.surveyQueUsrs == null)
            setSurveyQueUsrs(new TreeSet());
        return this.surveyQueUsrs;
    }

    public void setSurveyQueUsrs(Set surveyQueUsrs)
    {
        this.surveyQueUsrs = surveyQueUsrs;
    }

    /**
     * @hibernate.many-to-one not-null="false"
     * @hibernate.column name="parent_que_content_id"   
     * @return Returns the parentQuestion.
     */
    public SurveyQueContent getParentQuestion()
    {
        return parentQuestion;
    }

    /**
     * @param parentQuestion The parentQuestion to set.
     */
    public void setParentQuestion(SurveyQueContent parentQuestion)
    {
        this.parentQuestion = parentQuestion;
    }

    /**
     * @hibernate.set lazy="false" inverse="true" cascade="all-delete-orphan"
     * 				  sort="natural"
     * @hibernate.collection-key column="parent_que_content_id"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyQueContent"
     * 
     * @return Returns the subQuestions.
     */
    public Set getSubQuestions()
    {
        if (this.subQuestions == null)
            setSubQuestions(new TreeSet());
        return subQuestions;
    }

    /**
     * @param subQuestions The subQuestions to set.
     */
    public void setSubQuestions(Set subQuestions)
    {
        this.subQuestions = subQuestions;
    }

    //---------------------------------------------------------------------
    // Domain Service Methods
    //---------------------------------------------------------------------

    /**
     * Retrieve a particular candidate answer according to the answer id.
     * @param answerId
     * @return the Answer content value object.
     */
    public SurveyAnsContent getSurveyAnsById(long answerId)
    {
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            //validate pre-condition.
            answer.checkForID();
            if (answer.getSurveyAnsContentId().longValue() == answerId)
                return answer;
        }
        //we can't find it, return null answer content
        return new NullSurveyAnsContent();
    }

    public SurveyAnsContent getSurveyAnsByDisplayOrder(int order)
    {
        if (order < 0)
            throw new SurveyApplicationException("Can't get answer with "
                    + "negative display order");
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            if (answer.getDisplayOrder() == order)
                return answer;
        }
        return new NullSurveyAnsContent();

    }

    /**
     * Populate the Struts convenient attribut <code>userResponses</code> 
     * using the hibernate loaded response set.
     * 
     */
    public void setUpResponses(String username)
    {
        LinkedList response = new LinkedList();
        for (Iterator i = this.getSurveyQueUsrs().iterator(); i.hasNext();)
        {
            SurveyQueUsr qUser = (SurveyQueUsr) i.next();

            if ((qUser.getUsername().trim()).equals(username))
                response.addAll(qUser.getPredefinedResponse());
        }
        this.setUserResponses((String[]) response.toArray(new String[response.size()]));
    }

    /**
     * Translate the userResponses string array into an arraylist of new
     * UserResponseVO objects
     * @param user TODO
     * 
     * @return
     */
    public ArrayList getUserResponsesAsList(User user,SurveySession session)
    {
        //validate pre-condition of this method
        if (!isResponseAvailable() && getIsOptional())
            throw new SurveyApplicationException("Can't create user response object for "
                    + "compulsory question without response information");

        ArrayList responses = new ArrayList();
        for (int i = 0; i < userResponses.length; i++)
        {
            if (!userResponses[i].trim().equals(""))
                responses.add(createNewRespForSession(user, session, userResponses[i].trim()));
        }
        if (otherResponse != null && !otherResponse.trim().equals(""))
            responses.add(createNewRespForSession(user, session, otherResponse.trim()));
        return responses;
    }

    /**
     * @param user
     * @param session
     * @param responseEntry
     * @return
     */
    private SurveyUsrResp createNewRespForSession(User user, SurveySession session, String responseEntry)
    {
        SurveyQueUsr queUser = getSurveyQueUserByUserId(user,session);
        SurveyAnsContent answer = getSurveyAnswerByAnswerEntry(responseEntry);
        SurveyUsrResp resp= new SurveyUsrResp(responseEntry,
                                              new Date(System.currentTimeMillis()),
                                              this);
        resp.setSurveyAnsContent(answer);
        answer.getSurveyUsrResps().add(resp);
        
        resp.setSurveyQueUsr(queUser);
        queUser.addUserResponse(resp);
        return resp;
    }

    /**
     * @param string
     * @return
     */
    private SurveyAnsContent getSurveyAnswerByAnswerEntry(String answerEntry)
    {
        for(Iterator i = this.getSurveyAnsContents().iterator();i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent)i.next();
            if(answer.getAnswerEntry().equals(answerEntry))
                return answer;
        }
        return new SurveyAnsContent(answerEntry,
                                    SurveyConstants.NOT_SHOWN_CANDIDATE_ANSWER_ORDER,
                                    new TreeSet(),
                                    this);
    }

    /**
     * @return
     */
    private SurveyQueUsr getSurveyQueUserByUserId(User user,SurveySession session)
    {
        for(Iterator i=getSurveyQueUsrs().iterator();i.hasNext();)
        {
            SurveyQueUsr queUser= (SurveyQueUsr)i.next();
            if(queUser.getUserId().intValue()==user.getUserId().intValue())
                return queUser;
        }
        return new SurveyQueUsr(new Long(user.getUserId().intValue()),
                                user.getLogin(),
                                user.getFullName(),
                                this,session);
    }

    /**
     * @param username 
     * 
     */
    public void setUpOtherResponse(String username)
    {
        for (Iterator i = this.getSurveyQueUsrs().iterator(); i.hasNext();)
        {
            SurveyQueUsr qUser = (SurveyQueUsr) i.next();

            if ((qUser.getUsername().trim()).equals(username))
                this.setOtherResponse(qUser.getOtherResponse());
        }

    }

    /**
     * Convenient method to check out the response for other field.
     * @return true if other response field is not null and is not equals to
     * 			empty String
     */
    public boolean isOtherResponseAvailable()
    {
        if (this.otherResponse != null && !this.otherResponse.equals(""))
            return true;
        return false;
    }

    /**
     * @return Returns the answerIndex.
     */
    public Set getAnswerIndex()
    {
        return answerIndex;
    }

    /**
     * @param answerIndex
     *            The answerIndex to set.
     */
    public void setAnswerIndex(String answerIndex)
    {
        this.answerIndex.add(answerIndex);
    }

    /**
     * @return
     */
    public String getXLSCandidateAnswerString()
    {
        StringBuffer sb = new StringBuffer();

        sb.append("Question:\t" + this.getQuestion() + "\n")
          .append("Possible Answers:\n");

        int index = 1;
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            if (answer.getDisplayOrder() != -1)
            {
                sb.append("a" + index + "\t" + answer.getAnswerEntry() + "\n");
                this.setAnswerIndex("a" + index);
                index++;
            }
        }

        if ((this.getSurveyQueType().getName().trim()).equals(SurveyConstants.TEXT_ENTRY)
                || this.getIsTextBoxEnabled())
        {
            sb.append("a" + index + "\t" + SurveyConstants.OPEN_RESPONSE + "\n");
            this.setAnswerIndex("a" + index);
        }

        return sb.toString();
    }

    /**
     * Build the String for exporting Question data
     * @return
     */
    public String getXLSQuestionUserString()
    {
        StringBuffer sb = new StringBuffer();

        sb.append("Student\t");
        for (Iterator i = this.getAnswerIndex().iterator(); i.hasNext();)
        {
            sb.append((String) i.next() + " \t");
        }

        sb.append(" \n");
        for (Iterator i = this.getSurveyQueUsrs().iterator(); i.hasNext();)
        {
            SurveyQueUsr qUser = (SurveyQueUsr) i.next();
            sb.append(qUser.getUsername() + " \t");
            for (Iterator j = this.getSurveyAnsContents().iterator(); j.hasNext();)
            {
                SurveyAnsContent answer = (SurveyAnsContent) j.next();
                //predefined candidate answers
                if (answer.getDisplayOrder() != -1)
                {
                    if (qUser.isChosenByUser(answer.getAnswerEntry()))
                        sb.append("x \t");
                    else
                        sb.append(" \t");
                }
                //other open response
                if (answer.getDisplayOrder() == -1)
                {
                    if (qUser.isChosenByUser(answer.getAnswerEntry()))
                        sb.append(answer.getAnswerEntry());
                }

            }
            sb.append("\n");
            if ((this.getSurveyQueType().getName().trim()).equals(SurveyConstants.TEXT_ENTRY))
                sb.append(qUser.getTextEntry() + " \n");

        }
        sb.append("Totals\t");
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            //predefined candidate answers
            if (answer.getDisplayOrder() != -1)
            {
                sb.append(answer.getNumberOfResponse() + " \t");
            }
        }
        if ((this.getSurveyQueType().getDescription().trim()).equals(SurveyConstants.TEXT_ENTRY)
                || this.getIsTextBoxEnabled())
            sb.append(this.getNumberOfOpenRes() + " \n");

        return sb.toString();
    }

    /**
     * @return Returns the numberOfOpenRes.
     */
    public int getNumberOfOpenRes()
    {
        int numOfOpRes = 0;

        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent curCAnswer = (SurveyAnsContent) i.next();
            if (curCAnswer.getDisplayOrder() == -1)
                numOfOpRes += curCAnswer.getNumberOfResponse();
        }
        return numOfOpRes;
    }

    /**
     * @return Returns the totalNumOfRes.
     */
    public int getTotalNumOfRes()
    {
        return this.getSurveyUsrResps().size();
    }

    /**
     * @return
     */
    public List getSortedCanAnswerList()
    {
        return new LinkedList(getSurveyAnsContents());
    }

    /**
     * This method initialize the candidate answer set with one empty
     * candidate answer. It is useful when the author wants to create question
     * with at least one candidate answer.
     */
    public void initializeAnswerSet()
    {
        this.getSurveyAnsContents().add(new SurveyAnsContent("",
                                                             1,
                                                             new TreeSet(),
                                                             this));
    }

    /**
     * @return
     */
    public JFreeChart createPieChart()
    {

        DefaultPieDataset data = new DefaultPieDataset();
        NumberFormat formatter = NumberFormat.getPercentInstance();
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            if (answer.getDisplayOrder() != -1)
            {
                double percent = Math.round((double) answer.getNumberOfResponse()
                        / (double) this.getTotalNumOfRes() * 100);

                data.setValue("a" + answer.getDisplayOrder(), percent / 100);
            }

        }
        if (this.getIsTextBoxEnabled())
        {
            double percent = Math.round((double) this.getNumberOfOpenRes()
                    / (double) this.getTotalNumOfRes() * 100);
            data.setValue("Open Response", percent / 100);
        }
        JFreeChart chart = ChartFactory.createPieChart3D("Question "
                + this.displayOrder + " Pie Chart", data, true, false, false);
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelGenerator(new StandardPieItemLabelGenerator("{0} ({1})",
                                                                 formatter,
                                                                 formatter));

        return chart;

    }

    /**
     * @return
     */
    public JFreeChart createColumnChart()
    {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            if (answer.getDisplayOrder() != -1)
            {

                double percent = Math.round((double) answer.getNumberOfResponse()
                        / (double) this.getTotalNumOfRes() * 100);

                dataset.setValue(percent, "a" + answer.getDisplayOrder(), "a"
                        + answer.getDisplayOrder());
            }
        }

        if (this.getIsTextBoxEnabled())
        {
            double percent = Math.round((double) this.getNumberOfOpenRes()
                    / (double) this.getTotalNumOfRes() * 100);
            dataset.setValue(percent, "Open Response", "Open Response");
        }
        JFreeChart chart = ChartFactory.createBarChart3D("Question "
                                                                 + this.displayOrder
                                                                 + " Column Chart",
                                                         "Candidate Answer",
                                                         "Percentage",
                                                         dataset,
                                                         PlotOrientation.VERTICAL,
                                                         true,
                                                         true,
                                                         false);
        return chart;
    }



    /**
     * @return Returns the maxAnswerDispalyOrder.
     */
    public int getMaxAnswerDispalyOrder()
    {
        int index = 0;
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            if (answer.getDisplayOrder() > 0)
                index++;
        }
        return maxAnswerDispalyOrder = index;
    }

    /**
     * @return Returns the maxSubQeustionDisplayOrder.
     */
    public int getMaxSubQuestionDisplayOrder()
    {
        int index = 0;
        for (Iterator i = this.getSubQuestions().iterator(); i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent) i.next();
            index++;
        }
        return maxSubQuestionDisplayOrder = index;
    }


    /**
     * @param toBeRemovedAnswerList
     */
    public void removeAnsFromQuestion(List toBeRemovedAnswerList)
    {
        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            for (Iterator j = toBeRemovedAnswerList.iterator(); j.hasNext();)
            {
                SurveyAnsContent a = (SurveyAnsContent) j.next();
                if (a.equals(answer))
                    i.remove();
            }
        }

    }

    /**
     * @param toBeRemovedQuestionsSet
     */
    public void removeSubQuestion(Set toBeRemovedQuestionsSet)
    {

        for (Iterator j = toBeRemovedQuestionsSet.iterator(); j.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) j.next();
            this.getSubQuestions().remove(q);
        }

    }

    /**
     * @param displayOrder2
     * @return
     */
    public SurveyQueContent getSubQuestionByOrder(int displayOrder)
    {
        for (Iterator i = this.getSubQuestions().iterator(); i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent) i.next();
            if (question.getDisplayOrder() == displayOrder)
                return question;
        }
        throw new SurveyApplicationException("The requested sub-question does not exist!");
    }

    /**
     * This method add an empty sub question into sub question set.
     */
    public void addEmptySubQuestion(SurveyQueType queType)
    {
        SurveyQueContent question = new SurveyQueContent("",
                                                         this.getMaxSubQuestionDisplayOrder() + 1,
                                                         true,
                                                         false,
                                                         this.getSurveyContent(),
                                                         queType,
                                                         new TreeSet(),//surveyUsrResps
                                                         new TreeSet(),//answer set
                                                         new TreeSet(),//surveyQueUsrs
                                                         new TreeSet(),//subQuestions
                                                         this);
        this.getSubQuestions().add(question);
    }

    /**
     * Returns all candidate answer entry strings as a Linked list.
     * @return a list of answer entry.
     */
    public List getAnswerEntryList()
    {
        List answerEntryList = new LinkedList();
        for(Iterator i = getSurveyAnsContents().iterator();i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent)i.next();
            answerEntryList.add(answer.getAnswerEntry());
        }
        return answerEntryList;
    }
    
    /**
     * Overidden equals method.
     */
    public boolean equals(Object other)
    {
        if (other == this)
            return true;
        if (!(other instanceof SurveyQueContent))
            return false;

        SurveyQueContent question = (SurveyQueContent) other;

        if (this.getSurveyQueContentId() != null
                && question.getSurveyQueContentId() != null)
            return this.getSurveyQueContentId().longValue() == question.getSurveyQueContentId()
                                                                       .longValue();

        if (this.getParentQuestion() != null
                && question.getParentQuestion() == null)
            return false;

        if (this.getParentQuestion() == null
                && question.getParentQuestion() != null)
            return false;

        return this.getDisplayOrder() == question.getDisplayOrder()
                && this.getParentQuestion().getDisplayOrder() == question.getParentQuestion()
                                                                         .getDisplayOrder();

    }

    public int hashCode()
    {
        int result = 17;
        if (this.getSurveyQueContentId() != null)
            result = 37 * result + this.getSurveyQueContentId().intValue();
        result = 37 * result + displayOrder;
        if (this.getParentQuestion() != null)
            result = 37 * result + this.getParentQuestion().getDisplayOrder();
        return result;
    }
    
    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o)
    {
        SurveyQueContent queContent = (SurveyQueContent) o;
        //compare the display order if they are in the same level
        if (this.getParentQuestion() == null
                && queContent.getParentQuestion() == null)
            return displayOrder - queContent.displayOrder;
        if (this.getParentQuestion() != null
                && queContent.getParentQuestion() != null)
            return displayOrder - queContent.displayOrder;
        //compare the display order with parent if it is available.
        if (this.getParentQuestion() != null)
        {
            //return -1 if it is comparing with its parent
            if (this.getParentQuestion().getDisplayOrder() == queContent.displayOrder)
                return 1;
            else
                return this.getParentQuestion().getDisplayOrder()
                        - queContent.displayOrder;
        }
        if (queContent.getParentQuestion() != null)
        {
            //return 1 if it is comparing with its children
            if (displayOrder == queContent.getParentQuestion()
                                          .getDisplayOrder())
                return -1;
            else
                return displayOrder
                        - queContent.getParentQuestion().getDisplayOrder();
        }

        return (int) (surveyQueContentId.longValue() - queContent.surveyQueContentId.longValue());
    }

    public String toString()
    {
        return new ToStringBuilder(this).append("surveyQueContentId",
                                                getSurveyQueContentId())
                                        .append("question content",
                                                getQuestion())
                                        .append("display order",
                                                getDisplayOrder())
                                        .append("optional", getIsOptional())
                                        .append("text box enabled",
                                                getIsTextBoxEnabled())
                                        .append("Question type",
                                                getSurveyQueType())
                                        .append("user responses",
                                                getSurveyUsrResps())
                                        .append("sub questions",
                                                getSubQuestions())
                                        .append("parent question",
                                                getParentQuestion())
                                        .append("answer contents",
                                                getSurveyAnsContents())
                                        .append("question users",
                                                getSurveyQueUsrs())
                                        .append("User responses",
                                                getUserResponses())
                                        .append("other responses",
                                                getOtherResponse())
                                        .append("answer index",
                                                getAnswerIndex())
                                        .toString();
    }
    /**
     * Return boolean to indicate whether this is a null value object or not.
     * @see org.lamsfoundation.lams.tool.survey.Nullable#isNull()
     */
    public boolean isNull()
    {
        return false;
    }
    /**
     * Validate whether there is a response available for current question.
     * This method only validate struts convient field at the moment.
     * @return whether the resonse is available or not.
     */
    private boolean isResponseAvailable()
    {
        if (this.getUserResponses().length == 0
                && this.getOtherResponse() == null)
            return false;
        return this.getUserResponses().length != 0
                || !this.getOtherResponse().equals("");

    }

    /**
     * @param newQueContent
     * @return
     */
    private Set deepCopyAnsContent(SurveyQueContent newQueContent)
    {
        Set newAnswerContent = new TreeSet();

        for (Iterator i = this.getSurveyAnsContents().iterator(); i.hasNext();)
        {
            SurveyAnsContent ansContent = (SurveyAnsContent) i.next();
            newAnswerContent.add(SurveyAnsContent.newInstance(ansContent,
                                                              newQueContent));
        }

        return newAnswerContent;
    }

    /**
     * Create new Instances for all the sub questions that belong to a specified
     * parent question.
     * @param parentQueContent the parent question for all these sub questions
     * @return a set of new sub questions.
     */
    private Set deepCopySubQueContent(SurveyQueContent parentQueContent)
    {
        Set subQueContents = new TreeSet();
        for (Iterator i = this.getSubQuestions().iterator(); i.hasNext();)
        {
            SurveyQueContent queContent = (SurveyQueContent) i.next();
            subQueContents.add(SurveyQueContent.newInstance(queContent,
                                                            parentQueContent.getSurveyContent(),
                                                            parentQueContent));
        }
        return subQueContents;
    }

    /**
     * Update a candidate answer entry according to the given display order.
     * @param scale the candidate answer entry.
     * @param displayOrder the display order of the answer entry.
     */
    public void updateCandidatAnswer(String scale, int displayOrder)
    {
        for(Iterator i=getSurveyAnsContents().iterator();i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent)i.next();
            if(answer.getDisplayOrder()==displayOrder)
                answer.setAnswerEntry(scale);
        }
        
    }

}
