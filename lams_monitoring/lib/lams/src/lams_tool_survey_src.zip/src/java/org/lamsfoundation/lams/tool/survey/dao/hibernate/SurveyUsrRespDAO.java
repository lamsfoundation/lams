/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2004 
 * Created on 2004-12-6
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey.dao.hibernate;

import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import org.lamsfoundation.lams.tool.survey.SurveyUsrResp;
import org.lamsfoundation.lams.tool.survey.dao.ISurveyUsrRespDAO;




/**
 * 
 * @author Jacky Fang 2004-12-6
 * 
 */
public class SurveyUsrRespDAO extends HibernateDaoSupport implements ISurveyUsrRespDAO
{


    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveyUsrRespDAO#saveUserResponse(com.lamsinternational.tool.survey.domain.SurveyUsrResp)
     */
    public void saveUserResponse(SurveyUsrResp resp)
    {
        this.getHibernateTemplate().save(resp);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.ISurveyUsrRespDAO#updateUserResponse(org.lamsfoundation.lams.tool.survey.SurveyUsrResp)
     */
    public void updateUserResponse(SurveyUsrResp resp)
    {
        this.getHibernateTemplate().update(resp);        
    }

}
