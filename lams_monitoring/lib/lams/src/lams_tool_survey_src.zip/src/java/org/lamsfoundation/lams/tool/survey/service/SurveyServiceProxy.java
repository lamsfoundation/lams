package org.lamsfoundation.lams.tool.survey.service;

import javax.servlet.ServletContext;

import org.lamsfoundation.lams.tool.ToolContentManager;
import org.lamsfoundation.lams.tool.ToolSessionManager;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;




/**
 * <p>This class act as the proxy between web layer and service layer. It is
 * designed to decouple the presentation logic and business logic completely.
 * In this way, the presentation tier will no longer be aware of the changes in
 * service layer. Therefore we can feel free to switch the business logic
 * implementation.</p>
 *
 */
public class SurveyServiceProxy
{

    /*#com.webmcq.ld.tool.survey.ISurveyService Dependency_Link*/
    /**
     * Return the survey domain service object. It will delegate to the Spring
     * helper method to retrieve the proper bean from Spring bean factory.
     * @param servletContext the servletContext for current application
     * @return survey service object.
     */
    public static final ISurveyService getSurveyService(ServletContext servletContext)
    {
        return (ISurveyService)getSurveyDomainService(servletContext);
    }

    /**
     * Return the survey version of tool session manager implementation. 
     * It will delegate to the Spring helper method to retrieve the proper 
     * bean from Spring bean factory.
     * @param servletContext the servletContext for current application
     * @return survey service object.
     */
    public static final ToolSessionManager getSurveySessionManager(ServletContext servletContext)
    {
        return (ToolSessionManager)getSurveyDomainService(servletContext);
    }
    
    /**
     * Return the survey version of tool content manager implementation. 
     * It will delegate to the Spring helper method to retrieve the proper 
     * bean from Spring bean factory.
     * @param servletContext the servletContext for current application
     * @return survey service object.
     */
    public static final ToolContentManager getSurveyContentManager(ServletContext servletContext)
    {
        return (ToolContentManager)getSurveyDomainService(servletContext);
    }
    
    
    /**
     * Retrieve the proper Spring bean from bean factory. 
     * @param servletContext the servletContext for current application
     * @return the Spring service bean.
     */
    private static Object getSurveyDomainService(ServletContext servletContext)
    {
        WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
        return wac.getBean("surveyService");
    }

    
}