package org.lamsfoundation.lams.tool.survey.web;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.actions.LookupDispatchAction;
import org.apache.struts.util.MessageResources;

import org.lamsfoundation.lams.tool.ToolAccessMode;
import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveyContent;
import org.lamsfoundation.lams.tool.survey.SurveyQueContent;
import org.lamsfoundation.lams.tool.survey.SurveyQueType;
import org.lamsfoundation.lams.tool.survey.service.ISurveyService;
import org.lamsfoundation.lams.tool.survey.service.SurveyServiceProxy;
import org.lamsfoundation.lams.util.WebUtil;

/**
 * MyEclipse Struts Creation date: 01-18-2005
 * 
 * ----------------XDoclet Tags--------------------
 * 
 * @struts:action path="/tool/survey/authoring" name="AuthoringForm"
 *                input=".authoring" parameter="method" validate="true"
 *                scope="session"
 * 
 * @struts.action-exception key="error.system.survey" scope="request"
 *                          type="org.lamsfoundation.lams.tool.survey.SurveyApplicationException"
 *                          path=".systemError"
 *                          handler="org.lamsfoundation.lams.util.CustomStrutsExceptionHandler"
 * 
 * @struts:action-forward name="loadSurvey" path=".authoring"
 * @struts:action-forward name="saveSurvey" path=".success"
 * @struts:action-forward name="removeQuestion" path=".authoring"
 * @struts:action-forward name="compositeChoiceQuestion" path=".compositeChoice"
 * @struts:action-forward name="textEntryQuestion" path=".textEntry"
 * @struts:action-forward name="simpleChoiceQuestion" path=".simpleChoice"
 * @struts:action-forward name="questionType" path=".questionType"
 * @struts:action-forward name="scale" path=".scales"
 * ----------------XDoclet Tags--------------------
 */
public class AuthoringAction extends LookupDispatchAction
{

    //---------------------------------------------------------------------
    // Instance variables
    //---------------------------------------------------------------------
    private static Logger log = Logger.getLogger(AuthoringAction.class);

    //---------------------------------------------------------------------
    // Class level constants - Struts forward
    //---------------------------------------------------------------------
    private static final String LOAD_SURVEY = "loadSurvey";
    private static final String REMOVE_QUESTION = "removeQuestion";
    private static final String EDIT_COMPCHOICE_QUESTION = "compositeChoiceQuestion";
    private static final String EDIT_SIMPLECHOICE_QUESTION = "simpleChoiceQuestion";
    private static final String EDIT_TEXTENTRY_QUESTION = "textEntryQuestion";
    private static final String QUESTION_TYPE = "questionType";
    private static final String SCALE = "scale";

    //---------------------------------------------------------------------
    // Class level constants - session attributes
    //---------------------------------------------------------------------
    private static final boolean MODE_OPTIONAL = false;
    //http session contant keys
    private static final String ATTR_QUESTION_TYPE = "questionType";
    private static final String ATTR_QUESTION_TYPES = "questionTypes";
    private static final String ATTR_HAS_PARENT = "hasParent";
    //http request parameter keys
    private static final String PARAM_QUESTION_ID = "questionId";
    private static final String PARAM_QUESTION_TYPE = "questionType";
    private static final String PARAM_IS_SUB_QUE = "isSubQuestion";
    private static final String PARAM_ORDER = "order";
    private static final String PARAM_ACTION = "action";


    //---------------------------------------------------------------------
    // Public constants
    //---------------------------------------------------------------------
    public static final String MOVE_UP = "up";
    public static final String MOVE_DOWN = "down";
    public static final String REMOVE = "delete";
    public static final String ADD_NEW = "add";
    public static final int NEW_QUESTION_ID = 0;


    //---------------------------------------------------------------------
    // Struts dispatch actions
    //---------------------------------------------------------------------
    /**
     * Method execute
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward loadSurvey(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        //get parameters for the request
        ToolAccessMode mode = WebUtil.readToolAccessModeParam(request,
                                                              WebUtil.PARAM_MODE,
                                                              MODE_OPTIONAL);
        long surveyContentId = WebUtil.readLongParam(request,
                                                     WebUtil.PARAM_CONTENT_ID);

        //create service facade.
        ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());

        //loading survey content
        log.debug("loading survey [" + surveyContentId + "].....");
        SurveyContent survey = surveyService.retrieveSurvey(surveyContentId);
        //TODO toString method has StackOverflow error, need to be changed
        // later.
        //log.debug("survey content loaded: " + survey.toString());

        //populate form bean for display.
        authoringForm.buildAuthoringForm(survey);

        request.getSession().setAttribute(WebUtil.ATTR_MODE, mode);

        return mapping.findForward(LOAD_SURVEY);
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward getQuestionType(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        //set up the question types for next page.
        setUpQuestionTypes(request);

        return mapping.findForward(QUESTION_TYPE);
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward loadQuestion(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        //get the parameters from http request.
        int questionId = WebUtil.readIntParam(request, PARAM_QUESTION_ID);
        String questionType = WebUtil.readStrParam(request, PARAM_QUESTION_TYPE);

        SurveyQueType queType = getQuestionType(request, questionType.trim());

        setUpAuthoringFormForQuestion(request,
                                      authoringForm,
                                      questionId,
                                      queType);

        //setup Scales form attributes if the coming request is for compoiste
        // choice type
        if (queType.getName().equals(SurveyQueType.COMPOSITE_CHOICE))
            this.setUpScales(request, authoringForm);

        return findForwardByQuestionType(mapping, questionType.trim());
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward editSurveyQuestions(ActionMapping mapping,
                                             ActionForm form,
                                             HttpServletRequest request,
                                             HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        //create service facade.
        ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());

        int questionDisplayOrder = WebUtil.readIntParam(request, PARAM_ORDER);
        String action = WebUtil.readStrParam(request, PARAM_ACTION);
        boolean isSubQuestion = WebUtil.readBooleanParam(request,
                                                         PARAM_IS_SUB_QUE);

        if (!isSubQuestion)
        {
            authoringForm.resetSurveyQuestions(questionDisplayOrder, action);
            return mapping.findForward(LOAD_SURVEY);
        }
        else
        {
            authoringForm.resetSubQuestions(questionDisplayOrder, action);
            return mapping.findForward(EDIT_COMPCHOICE_QUESTION);
        }

    }

    public ActionForward addSubQuestion(ActionMapping mapping,
                                        ActionForm form,
                                        HttpServletRequest request,
                                        HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        authoringForm.setUpSubQuestion(getQuestionType(request,
                                                       SurveyQueType.SIMPLE_CHOICE),
                                       request,
                                       true);

        return mapping.findForward(EDIT_COMPCHOICE_QUESTION);

    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward cancelEditQuestion(ActionMapping mapping,
                                            ActionForm form,
                                            HttpServletRequest request,
                                            HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        return mapping.findForward(LOAD_SURVEY);
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward submitQuestion(ActionMapping mapping,
                                        ActionForm form,
                                        HttpServletRequest request,
                                        HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        authoringForm.submitQuestionToSurvey();

        return mapping.findForward(LOAD_SURVEY);
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward editCandidateAnswers(ActionMapping mapping,
                                              ActionForm form,
                                              HttpServletRequest request,
                                              HttpServletResponse response)
    {
        AuthoringForm authoringForm = (AuthoringForm) form;
        //get request parameters
        String questionType = WebUtil.readStrParam(request, PARAM_QUESTION_TYPE);

        int answerDisplayOrder = WebUtil.readIntParam(request, PARAM_ORDER);
        String action = WebUtil.readStrParam(request, PARAM_ACTION);

        authoringForm.resetAnswerList(answerDisplayOrder, action);

        return findForwardByQuestionType(mapping, questionType.trim());
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward addCandidateAnswer(ActionMapping mapping,
                                            ActionForm form,
                                            HttpServletRequest request,
                                            HttpServletResponse response)
    {
        AuthoringForm authoringForm = (AuthoringForm) form;
        //get request parameters
        SurveyQueType questionType = (SurveyQueType) request.getSession()
                                                            .getAttribute(ATTR_QUESTION_TYPE);

        authoringForm.addEmptyAnswerToList();

        return findForwardByQuestionType(mapping, questionType.getName().trim());
    }

    public ActionForward commitChange(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response)
    {
        AuthoringForm authoringForm = (AuthoringForm) form;
        //get request parameters
        SurveyQueType questionType = (SurveyQueType) request.getSession()
                                                            .getAttribute(ATTR_QUESTION_TYPE);
        return findForwardByQuestionType(mapping, questionType.getName().trim());
    }
    

    public ActionForward loadScale(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response)
    {
        return mapping.findForward(SCALE);
    }
    
    public ActionForward addScale(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response)
    {
        AuthoringForm authoringForm = (AuthoringForm) form;

        authoringForm.addEmptyScale();

        return mapping.findForward(SCALE);
    }

    /**
     * Submit the scales to the composite choice question we are editing.
     * As we will close the pop up windows after the submission, we set the 
     * forward to <code>null</code>
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return null forward.
     */
    public ActionForward submitScale(ActionMapping mapping,
                                     ActionForm form,
                                     HttpServletRequest request,
                                     HttpServletResponse response)
    {
        AuthoringForm authoringForm = (AuthoringForm) form;
        
        if (isCancelled(request))
            return mapping.findForward(EDIT_COMPCHOICE_QUESTION);

        authoringForm.submitScaleIntoQuestion();

        return null;
    }

    /**
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     */
    public ActionForward submitSurvey(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response)
    {

        AuthoringForm authoringForm = (AuthoringForm) form;

        //get parameters for the request
        ToolAccessMode mode = (ToolAccessMode) request.getSession()
                                                      .getAttribute(WebUtil.ATTR_MODE);
        //this parameter suppose to be setup by filter
        //long surveyContentId =
        // WebUtil.readLongParam(request,WebUtil.PARAM_CONTENT_ID);
        long surveyContentId = 1;

        //create service facade.
        ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());

        SurveyContent surveyContent = authoringForm.buildSurvey(surveyContentId);

        if (authoringForm.isSurveyNew())
            surveyService.saveSurveyContent(surveyContent);
        else
            surveyService.updateSurvey(surveyContent);

        createActionMessage(request, "message.authoring.success");

        return mapping.findForward(LOAD_SURVEY);
    }

    /**
     * @see org.apache.struts.actions.LookupDispatchAction#getKeyMethodMap()
     */
    protected Map getKeyMethodMap()
    {
        Map map = new HashMap();
        //keys for survey operation
        map.put("request.authoring.load", "loadSurvey");
        map.put("button.authoring.submit", "submitSurvey");
        //keys for question editing
        map.put("button.authoring.question.add", "getQuestionType");
        map.put("request.authoring.loadQuestion", "loadQuestion");
        map.put("request.authoring.question.edit", "editSurveyQuestions");
        map.put("button.authoring.question.submit", "submitQuestion");
        map.put("button.authoring.question.cancel", "cancelEditQuestion");
        map.put("button.authoring.subquestion.add", "addSubQuestion");
        //keys for candidateAnswer editing
        map.put("button.authoring.commit","commitChange");
        map.put("request.authoring.editAnswer", "editCandidateAnswers");
        map.put("button.authoring.answer.add", "addCandidateAnswer");
        //keys for scales
        map.put("button.authoring.scale.load","loadScale");
        map.put("button.authoring.scale.add", "addScale");
        map.put("button.authoring.scale.submit","submitScale");
        return (map);
    }

    /**
     * @param mapping
     * @return
     */
    private ActionForward findForwardByQuestionType(ActionMapping mapping,
                                                    String questionType)
    {
        if (questionType.equals(SurveyQueType.SIMPLE_CHOICE))
            return mapping.findForward(EDIT_SIMPLECHOICE_QUESTION);
        else if (questionType.equals(SurveyQueType.CHOICE_MULTIPLE))
            return mapping.findForward(EDIT_SIMPLECHOICE_QUESTION);
        else if (questionType.equals(SurveyQueType.TEXT_ENTRY))
            return mapping.findForward(EDIT_TEXTENTRY_QUESTION);
        else if (questionType.equals(SurveyQueType.COMPOSITE_CHOICE))
            return mapping.findForward(EDIT_COMPCHOICE_QUESTION);

        throw new SurveyApplicationException("Invalid question type ["
                + questionType + "].");
    }

    /**
     * @param request
     * @param authoringForm
     * @param questionId
     * @param queType
     */
    private void setUpAuthoringFormForQuestion(HttpServletRequest request,
                                               AuthoringForm authoringForm,
                                               int questionId,
                                               SurveyQueType queType)
    {
        boolean hasParent = WebUtil.readBooleanAttr(request, ATTR_HAS_PARENT);

        if (!hasParent)
            authoringForm.set("parentQuestion", null);

        SurveyQueContent question = authoringForm.getQuestionFromSurvey(questionId,
                                                                        queType);

        if (queType.getName().equals(SurveyQueType.COMPOSITE_CHOICE))
            setUpFormForCompositeQue(request, authoringForm, question);
        else
            setUpFormForSimpleQue(authoringForm, question);

        request.getSession().setAttribute(ATTR_QUESTION_TYPE, queType);
    }

    /**
     * @param authoringForm
     * @param question
     */
    private void setUpFormForSimpleQue(AuthoringForm authoringForm,
                                       SurveyQueContent question)
    {
        authoringForm.set("question", question);
        authoringForm.set("candidateAnswers", question.getSortedCanAnswerList());
    }
    /**
     * @param request
     * @param authoringForm
     */
    private void setUpScales(HttpServletRequest request,
                             AuthoringForm authoringForm)
    {
        List scales = authoringForm.getQuestionScales();

        if (scales.size() == 0)
            setUpScalesFromResources(request, authoringForm);
        else
            authoringForm.set("scales", scales);
    }
    /**
     * @param request
     * @param authoringForm
     * @param question
     */
    private void setUpFormForCompositeQue(HttpServletRequest request,
                                          AuthoringForm authoringForm,
                                          SurveyQueContent question)
    {
        authoringForm.set("parentQuestion", question);

        if (question.getQuestion().equals(""))
            authoringForm.setUpSubQuestion(getQuestionType(request,
                                                           SurveyQueType.SIMPLE_CHOICE),
                                           request,
                                           true);
        else
            authoringForm.setUpSubQuestion(getQuestionType(request,
                                                           SurveyQueType.SIMPLE_CHOICE),
                                           request,
                                           false);
    }

    /**
     * Retreive the question type object according to the name.
     * 
     * @param request
     * @param questionType
     * @return
     */
    private SurveyQueType getQuestionType(HttpServletRequest request,
                                          String questionType)
    {
        Set queTypeSet = setUpQuestionTypes(request);
        for (Iterator i = queTypeSet.iterator(); i.hasNext();)
        {
            SurveyQueType type = (SurveyQueType) i.next();
            if (type.getName().endsWith(questionType))
                return type;
        }
        throw new SurveyApplicationException("Invalid question type ["
                + questionType + "].");
    }

    /**
     * @param surveyService
     * @return
     */
    private Set setUpQuestionTypes(HttpServletRequest request)
    {
        Set questionTypes = (Set) request.getSession()
                                         .getAttribute(ATTR_QUESTION_TYPES);
        if (questionTypes == null)
        {
            //create service facade.
            ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());

            //sort the questions using tree set.
            questionTypes = new TreeSet(surveyService.getQuestionTypes());
            request.getSession().setAttribute(ATTR_QUESTION_TYPES, questionTypes);
        }
        return questionTypes;
    }

    /**
     * @param request
     * @param authoringForm
     */
    private void setUpScalesFromResources(HttpServletRequest request,
                                          AuthoringForm authoringForm)
    {
        MessageResources mr = getResources(request);
        authoringForm.set("scales",
                          new LinkedList(Arrays.asList(mr.getMessage("scales")
                                                         .split(":"))));
    }

    private void createActionMessage(HttpServletRequest request,
                                     String messageKey)
    {
        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE,
                     new ActionMessage(messageKey));
        saveMessages(request, messages);
    }

}
