package org.lamsfoundation.lams.tool.survey;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** 
 *        @hibernate.class
 *         table="tool_lasr10_survey_content"
 *     
 */
public class SurveyContent implements Serializable
{

    /** identifier field */
    private Long surveyContentId;

    /** nullable persistent field */
    private String title;

    /** nullable persistent field */
    private String instruction;

    /** nullable persistent field */
    private String description;

    /** nullable persistent field */
    private Date dateCreated;

    /** nullable persistent field */
    private long creatorUserId;

    /** nullable persistent field */
    private boolean showUser;

    /** nullable persistent field */
    private boolean defineLater;

    /** nullable persistent field */
    private boolean reusable;

    /** nullable persistent field */
    private String summary;

    /** persistent field */
    private Set surveyQueContents;

    /** persistent field */
    private Set surveySessions;

    private int totalNumberOfQuestions;

    /** full constructor */
    public SurveyContent(Long surveyContentId,
                         String title,
                         String instruction,
                         String description,
                         Date dateCreated,
                         long creatorUserId,
                         boolean showUser,
                         boolean defineLater,
                         boolean reusable,
                         String summary,
                         Set surveyQueContents,
                         Set surveySessions)
    {
        this.surveyContentId = surveyContentId;
        this.title = title;
        this.instruction = instruction;
        this.description = description;
        this.dateCreated = dateCreated;
        this.creatorUserId = creatorUserId;
        this.showUser = showUser;
        this.defineLater = defineLater;
        this.reusable = reusable;
        this.summary = summary;
        this.surveyQueContents = surveyQueContents;
        this.surveySessions = surveySessions;
    }

    /** default constructor */
    public SurveyContent()
    {
    }

    /**
     * Copy Construtor to create a new survey content instance. Note that we
     * don't copy the survey session data here because the survey session is
     * will be created after we copied tool content.
     * @param survey the original survey content.
     * @param newContentId the new survey content id.
     * @return the new survey content object.
     */
    public static SurveyContent newInstance(SurveyContent survey,
                                            Long newContentId)
    {
        SurveyContent newContent = new SurveyContent(newContentId,
                                                     survey.getTitle(),
                                                     survey.getInstruction(),
                                                     survey.getDescription(),
                                                     survey.getDateCreated(),
                                                     survey.getCreatorUserId(),
                                                     survey.isShowUser(),
                                                     survey.isDefineLater(),
                                                     survey.isReusable(),
                                                     survey.getSummary(),
                                                     new TreeSet(),
                                                     new TreeSet());
        newContent.setSurveyQueContents(survey.deepCopySurveyQueContent(newContent));
        return newContent;
    }

    /** 
     * @hibernate.id generator-class="assigned" type="java.lang.Long"
     *               column="survey_content_id"
     *         
     */
    public Long getSurveyContentId()
    {
        return this.surveyContentId;
    }

    public void setSurveyContentId(Long surveyContentId)
    {
        this.surveyContentId = surveyContentId;
    }

    /** 
     * @hibernate.property column="title" length="65535"
     *         
     */
    public String getTitle()
    {
        return this.title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    /** 
     * @hibernate.property column="instruction" length="65535"
     *         
     */
    public String getInstruction()
    {
        return this.instruction;
    }

    public void setInstruction(String instruction)
    {
        this.instruction = instruction;
    }

    /** 
     * @hibernate.property column="description" length="65535"
     *         
     */
    public String getDescription()
    {
        return this.description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    /** 
     * @hibernate.property column="dateCreated" length="150"
     *         
     */
    public Date getDateCreated()
    {
        return this.dateCreated;
    }

    public void setDateCreated(Date dateCreated)
    {
        this.dateCreated = dateCreated;
    }

    /** 
     * @hibernate.property column="creatorUserId" length="20"
     *         
     */
    public long getCreatorUserId()
    {
        return this.creatorUserId;
    }

    public void setCreatorUserId(long creatorUserId)
    {
        this.creatorUserId = creatorUserId;
    }

    /** 
     * @hibernate.property column="showUser" length="1"
     *         
     */
    public boolean isShowUser()
    {
        return this.showUser;
    }

    public void setShowUser(boolean showUser)
    {
        this.showUser = showUser;
    }

    /** 
     * @hibernate.property column="defineLater" length="1"
     *         
     */
    public boolean isDefineLater()
    {
        return this.defineLater;
    }

    public void setDefineLater(boolean defineLater)
    {
        this.defineLater = defineLater;
    }

    /** 
     * @hibernate.property column="reusable" length="1"
     *         
     */
    public boolean isReusable()
    {
        return this.reusable;
    }

    public void setReusable(boolean reusable)
    {
        this.reusable = reusable;
    }

    /** 
     * @hibernate.property column="summary" length="65535"
     *         
     */
    public String getSummary()
    {
        return this.summary;
    }

    public void setSummary(String summary)
    {
        this.summary = summary;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="all-delete-orphan"
     *                sort="natural"
     * @hibernate.collection-key column="survey_content_sid"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyQueContent"
     *         
     */
    public Set getSurveyQueContents()
    {
        if (this.surveyQueContents == null)
            setSurveyQueContents(new TreeSet());
        return this.surveyQueContents;
    }

    public void setSurveyQueContents(Set surveyQueContents)
    {
        this.surveyQueContents = surveyQueContents;
    }

    public Set deepCopySurveyQueContent(SurveyContent newSurveyContent)
    {
        Set newSurveyQueContent = new TreeSet();
        for (Iterator i = this.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent queContent = (SurveyQueContent) i.next();
            if (queContent.getParentQuestion() == null)
                newSurveyQueContent.add(SurveyQueContent.newInstance(queContent,
                                                                     newSurveyContent,
                                                                     null));
        }
        return newSurveyQueContent;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="all-delete-orphan"
     * @hibernate.collection-key column="survey_content_id"
     * @hibernate.collection-one-to-many class="org.lamsfoundation.lams.tool.survey.SurveySession"
     *         
     */
    public Set getSurveySessions()
    {
        if (this.surveySessions == null)
            setSurveySessions(new TreeSet());
        return this.surveySessions;
    }

    public void setSurveySessions(Set surveySessions)
    {
        this.surveySessions = surveySessions;
    }

    public String toString()
    {
        return new ToStringBuilder(this).append("surveyContentId",
                                                getSurveyContentId())
                                        .append("survey title", getTitle())
                                        .append("survey instruction",
                                                getInstruction())
                                        .append("date created",
                                                getDateCreated())
                                        .append("creator user id",
                                                getCreatorUserId())
                                        .append("show user", isShowUser())
                                        .append("define later", isDefineLater())
                                        .append("reusable", isReusable())
                                        .append("summary", getSummary())
                                        .append("survey questions",
                                                getSurveyQueContents())
                                        .append("survey sessions",
                                                getSurveySessions())
                                        .toString();
    }

    /**
     * Since the survey content id is assigned variable, we can use content id
     * to ensure two survey objects are equal.
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object other)
    {
        if (!(other instanceof SurveyContent))
            return false;
        SurveyContent castOther = (SurveyContent) other;
        return new EqualsBuilder().append(this.getSurveyContentId(),
                                          castOther.getSurveyContentId())
                                  .isEquals();
    }

    /**
     * Since the survey content id is assigned variable, we can use content id
     * to ensure two survey objects are equal.
     * @see java.lang.Object#hashCode()
     */
    public int hashCode()
    {
        return new HashCodeBuilder().append(getSurveyContentId()).toHashCode();
    }

    /**
     * 
     */
    public void setUpStrutsQuestionResponse(String username)
    {
        for (Iterator i = this.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();
            q.setUpResponses(username);
            if (q.getIsTextBoxEnabled())
                q.setUpOtherResponse(username);
        }
    }

    /**
     * @return
     */
    public int questionNumCounter()
    {
        int index = 0;
        for (Iterator i = this.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent) i.next();
            if (question.getParentQuestion() == null)
                index++;
        }
        return index;
    }

    /**
     * @return Returns the totalNumberOfQuestions.
     */
    public int getTotalNumberOfQuestions()
    {
        return totalNumberOfQuestions = questionNumCounter();
    }

    /**
     * @param question
     */
    public void updateSurveyQueContent(SurveyQueContent question)
    {
        //validate pre-condition
        if (question.getSurveyQueContentId() == null)
            throw new SurveyApplicationException("Fail to update question"
                    + "without id");

        try
        {
            for (Iterator i = this.surveyQueContents.iterator(); i.hasNext();)
            {
                SurveyQueContent queContent = (SurveyQueContent) i.next();
                if (queContent.getSurveyQueContentId() != null
                        && queContent.getSurveyQueContentId() == question.getSurveyQueContentId())
                    BeanUtils.copyProperties(queContent, question);
            }
        }
        catch (IllegalAccessException e)
        {
            throw new SurveyApplicationException("Error ocurred in"
                    + "updateSurveyQueContent:" + e.getMessage());
        }
        catch (InvocationTargetException e)
        {
            throw new SurveyApplicationException("Error ocurred in"
                    + "updateSurveyQueContent:" + e.getMessage());
        }
    }

    /**
     * @param questionDisplayOrder
     * @param b
     * @return
     */
    public SurveyQueContent getQuestionByDisplayOrder(int questionDisplayOrder,
                                                      boolean hasParent)
    {
        for (Iterator i = this.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent) i.next();
            if (!hasParent)
            {
                if (question.getParentQuestion() == null
                        && question.getDisplayOrder() == questionDisplayOrder)
                    return question;
            }
            else
            {
                if (question.getParentQuestion() != null
                        && question.getDisplayOrder() == questionDisplayOrder)
                    return question;
            }
        }
        throw new SurveyApplicationException("No such question with "
                + "display order [" + questionDisplayOrder + "]");
    }

    /**
     * @param toBeRemovedQuestionsSet
     */
    public void removeSubQuestions(Set toBeRemovedQuestionsSet)
    {
        for (Iterator i = this.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent) i.next();
            
            for(Iterator j= toBeRemovedQuestionsSet.iterator();j.hasNext();)
            {
                SurveyQueContent q = (SurveyQueContent)j.next();
                if(question.equals(q))
                    i.remove();
            }
        }
    }

    /**
     * @param this
     * @return
     */
    public List getSurveyQuestionAsSortedList()
    {
        //sort the questions
        List questions = new LinkedList(getSurveyQueContents());
        Collections.sort(questions);
        return questions;
    }
}
