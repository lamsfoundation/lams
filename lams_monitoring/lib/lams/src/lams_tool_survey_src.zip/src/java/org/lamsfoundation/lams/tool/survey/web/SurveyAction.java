package org.lamsfoundation.lams.tool.survey.web;

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;


import org.lamsfoundation.lams.tool.ProgressOutputData;
import org.lamsfoundation.lams.tool.ToolAccessMode;
import org.lamsfoundation.lams.tool.ToolSessionManager;
import org.lamsfoundation.lams.tool.survey.NullSurveySession;
import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveySession;
import org.lamsfoundation.lams.tool.survey.service.ISurveyService;
import org.lamsfoundation.lams.tool.survey.service.SurveyServiceProxy;
import org.lamsfoundation.lams.usermanagement.User;
import org.lamsfoundation.lams.util.WebUtil;


/**
 * <p>Action class that controls the logic of survey behavior. Currently, it loads
 * a questionnaire, submit the questionnaire data and complete the survey 
 * session.</p>
 * 
 * <p>Note that Struts action class only has the responsibility to navigate 
 * page flow. All database operation should go to service layer and data 
 * transformation from domain model to struts form bean should go to form 
 * bean class. This ensure clean and maintainable code.
 * </p>
 * 
 * <code>SystemException</code> is thrown whenever an known error condition is
 * identified. No system exception error handling code should appear in the 
 * Struts action class as all of them are handled in 
 * <code>CustomStrutsExceptionHandler<code>.
 * 
 * 
 * ----------------XDoclet Tags--------------------
 * 
 * @struts:action path="/tool/survey/survey" name="QuestionnaireForm"
 *                input=".questionnaire" parameter="method" scope="session"
 *                validate="true"
 * @struts.action-exception key="error.system.survey" scope="request"
 *                          type="org.lamsfoundation.lams.tool.survey.SurveyApplicationException"
 *                          path=".systemError"
 * 							handler="org.lamsfoundation.lams.util.CustomStrutsExceptionHandler"
 * @struts:action-forward name="submit" path=".summary"
 * @struts:action-forward name="view" path=".summary"
 * @struts:action-forward name="load" path=".questionnaire"
 * ----------------XDoclet Tags--------------------
 */
public class SurveyAction extends DispatchAction
{

    //---------------------------------------------------------------------
    // Instance variables
    //---------------------------------------------------------------------
    private static Logger log = Logger.getLogger(SurveyAction.class);

    //---------------------------------------------------------------------
    // Class level constants - Struts forward
    //---------------------------------------------------------------------
    private static final String LOAD_QUESTIONNAIRE = "load";
    private static final String SUBMIT_QUESTIONNAIRE = "submit";
    private static final String VIEW_INDIVIDUAL_SUMMARY = "view";

    //---------------------------------------------------------------------
    // Class level constants - session attributes
    //---------------------------------------------------------------------
    private static final boolean MODE_OPTIONAL = false;
    public static final String ATTR_USERDATA = "survey_user";
    //---------------------------------------------------------------------
    // Struts dispatch actions
    //---------------------------------------------------------------------
    /** 
     * Struts dispatch method. This method loads the survey from database 
     * and switch to proper view according to the mode. 
     * 
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     * @throws SystemException the known runtime exception 
     * 
     */
    public ActionForward loadQuestionnaire(ActionMapping mapping,
                                           ActionForm form,
                                           HttpServletRequest request,
                                           HttpServletResponse response) throws IOException,
                                                                        ServletException
    {
        QuestionnaireForm questionnaireForm = (QuestionnaireForm) form;

        ToolAccessMode mode = WebUtil.readToolAccessModeParam(request, WebUtil.PARAM_MODE,MODE_OPTIONAL);
        
        ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());
        //get user data
        User user = getUserData(request, surveyService);

        //create a new survey session
        SurveySession surveySession = new NullSurveySession();
        
        if (questionnaireForm != null)
        {
            //It is ensured to be not null by dyna validator.
            long toolSessionId = ((Long) questionnaireForm.get("sessionId")).longValue();
            surveySession = surveyService.retrieveSurveySession(toolSessionId);
            questionnaireForm.buildQuestionnaireForm(user.getLogin(),
                                                     surveySession);
        }
        else
        {
            log.error("Fail to pre-load the questionnaire form.");
            throw new SurveyApplicationException("Fail to pre-load the questionnaire form.");
        }

        request.getSession().setAttribute("QuestionnaireForm",
                                          questionnaireForm);

        //we validate mode and switch it inividual page if mode is viewonly.
        if (!shouldWeStartSurvey(mode, request, surveySession.getSessionStatus()))
        {
            //set the mode into http session 
            request.getSession().setAttribute(WebUtil.ATTR_MODE, mode);
            request.getSession().setAttribute(WebUtil.ATTR_SESSION_STATUS, getSessionStatus(request));
            //setup session attribute to display name.
            request.getSession()
                   .setAttribute(WebUtil.ATTR_USERNAME, user.getFullName());

            return (mapping.findForward(VIEW_INDIVIDUAL_SUMMARY));
        }
        //set the mode into http session 
        request.getSession().setAttribute(WebUtil.ATTR_MODE, mode);
        request.getSession().setAttribute(WebUtil.ATTR_SESSION_STATUS, getSessionStatus(request));

        return (mapping.findForward(LOAD_QUESTIONNAIRE));
    }

    /**
     * Struts dispatch method. This method rip the data from the formbean
     * and save user response into the database. 
     * 
     * It validate the Struts transaction token to ensure no duplicate 
     * submission happened.
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward submitQuestionnaire(ActionMapping mapping,
                                             ActionForm form,
                                             HttpServletRequest request,
                                             HttpServletResponse response) throws IOException,
                                                                          ServletException
    {
        QuestionnaireForm questionnaireForm = (QuestionnaireForm) form;

        if (isCancelled(request))
        {
            questionnaireForm.resetSurveyQuestions();
           
            return (mapping.findForward(LOAD_QUESTIONNAIRE));
        }
        
        String username = WebUtil.getUsername(request);

        ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());

        //retrieve complete user data
        User user = getUserData(request, surveyService);
        
        //transform the form bean into domain model for persistency.
        List userResponses = questionnaireForm.buildUserResponses(request,user);
        
        //setup session attribute to display name.
        request.getSession().setAttribute(WebUtil.ATTR_USERNAME, user.getFullName());

        surveyService.saveUserResponses(userResponses,
                                        ((Long) questionnaireForm.get("sessionId")).longValue(),
                                        user);

        return (mapping.findForward(SUBMIT_QUESTIONNAIRE));
    }

    /**
     * This method implement the complete session logic. The user can either
     * cancel to re-do the survey or complete survey to move on to next 
     * task defined in the sequence.
     *
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward completeSession(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response) throws IOException,
                                                                      ServletException
    {
        ToolSessionManager surveySessionManager = SurveyServiceProxy.getSurveySessionManager(getServlet().getServletContext());
        QuestionnaireForm qForm = (QuestionnaireForm) form;

        if (isCancelled(request))
            return mapping.getInputForward();

        ProgressOutputData displayTaskData = surveySessionManager.leaveToolSession(((Long) qForm.get("sessionId")));
        return null;

    }

    //---------------------------------------------------------------------
    // Helper Methods
    //---------------------------------------------------------------------
    /**
     * <p>Helper method to validate view mode. We return true only if mode in 
     * following condition.</p>
     * 
     * <li>The access mode is Learner.</li>
     * @param mode the mode that defined in ToolAccessMode.
     * @param sessionState TODO
     * 
     * @see com.webmcq.ld.controller.ToolAccessMode
     * @return boolean to tell front controller to start survey or not.
     */
    private boolean shouldWeStartSurvey(ToolAccessMode mode, HttpServletRequest request, String sessionState)
    {
        if (mode == ToolAccessMode.LEARNER&&sessionState.equals(SurveySession.NOT_ATTEMPTED))
        {
            //put attribute in session for use in whole http session
            request.getSession().setAttribute(WebUtil.ATTR_MODE, mode);
            request.setAttribute(WebUtil.ATTR_UPDATE_PROGRESS_BAR, "true");
            return true;
        }
        return false;
    }

    /**
     * Helper method to retrieve the user data. We always load up from http
     * session first to optimize the performance. If no session cache available,
     * we load it from data source.
     * @param request A standard Servlet HttpServletRequest class.
     * @param surveyService the service facade of survey tool
     * @return the user data value object
     */
    private User getUserData(HttpServletRequest request,
                             ISurveyService surveyService)
    {
        //retrieve complete user data from http session
        User userCompleteData = (User) request.getSession()
                                              .getAttribute(ATTR_USERDATA);
        //if no session cache available, retrieve it from data source
        if (userCompleteData == null)
        {
            userCompleteData = surveyService.getCurrentUserData(WebUtil.getUsername(request));
            //create session cache
            request.getSession().setAttribute(ATTR_USERDATA, userCompleteData);
        }
        return userCompleteData;
    }
    
    /**
     * TODO need to be deleted once progress engine is done. This meant to be
     * handled by progress engine.
     * @param request
     */
    private String getSessionStatus(HttpServletRequest request)
    {
        //TODO need to be removed when progress engine is done.        
        String sessionStatus = (String)request.getSession().getAttribute(WebUtil.ATTR_SESSION_STATUS); 
        if(sessionStatus==null)
            sessionStatus = (String)WebUtil.readStrParam(request,WebUtil.PARAM_SESSION_STATUS);
        return sessionStatus;
    }
}
