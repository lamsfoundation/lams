/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2005 
 * Created on 2005-1-18
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey.web;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

import org.lamsfoundation.lams.tool.survey.SurveyAnsContent;
import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveyContent;
import org.lamsfoundation.lams.tool.survey.SurveyQueContent;
import org.lamsfoundation.lams.tool.survey.SurveyQueType;

/**
 * 
 * @author Jacky Fang 2005-1-18
 *  
 */
public class AuthoringForm extends DynaValidatorForm
{

    /**
     *  
     */
    public AuthoringForm()
    {
        super();
    }

    //---------------------------------------------------------------------
    // Inherited Methods
    //---------------------------------------------------------------------

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        //do nothing.
    }

    /**
     * Nothing needs to be validated in the form so far.
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {

        ActionErrors errors = new ActionErrors();

        return errors;
    }

    /**
     * @param survey
     */
    public void buildAuthoringForm(SurveyContent survey)
    {
        if (survey == null)
            throw new SurveyApplicationException("Can't build authoring"
                    + "without survey content.");
        this.set("survey", survey);
        this.set("questionList",new LinkedList(survey.getSurveyQueContents()));
    }

    /**
     * @return
     */
    public SurveyContent buildSurvey(long surveyContentId)
    {
        SurveyContent orgContent = (SurveyContent) this.get("survey");

        if (orgContent == null)
            throw new SurveyApplicationException("No survey content can be"
                    + "found from http session. ");
        //creat a new survey content object if the coming content id is
        //different from current one.
        if (orgContent.getSurveyContentId().longValue() != surveyContentId)
        {
            this.set("isSurveyNew", new Boolean(true));
            return SurveyContent.newInstance(orgContent,
                                             new Long(surveyContentId));
        }

        return orgContent;
    }

    /**
     * @param displayOrder
     * @return
     */
    public SurveyQueContent getQuestionFromSurvey(int displayOrder,
                                                  SurveyQueType queType)
    {
        //validate pre-condition of this method
        if (displayOrder < 0)
            throw new SurveyApplicationException("Invalid question id, "
                    + "it must be larger than 0 or equals 0 for new question.");

        //get survey data oject from form bean
        SurveyContent survey = (SurveyContent) this.get("survey");

        SurveyQueContent parentQuestion = (SurveyQueContent)this.get("parentQuestion");
        
        //If we are dealing with new question, we return a null value object.
        if (displayOrder == 0)
            return creatNewSurveyQueContent(survey, queType, parentQuestion);

        if(parentQuestion!=null)
            return parentQuestion.getSubQuestionByOrder(displayOrder);
                
        for (Iterator i = survey.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();

            if (q.getDisplayOrder()==displayOrder&&q.getParentQuestion()==null)
                return q;
        }
        throw new SurveyApplicationException("The requested question does not exist!");

    }

    /**
     * @param parentQuestion TODO
     * @return
     */
    private SurveyQueContent creatNewSurveyQueContent(SurveyContent survey,
                                                      SurveyQueType queType, 
                                                      SurveyQueContent parentQuestion)
    {
        //validate pre-condition.
        if (survey == null)
            throw new SurveyApplicationException("Can't create a new "
                    + "question for a Null survey");
        //initialize answer set

        SurveyQueContent question = new SurveyQueContent("",
                                                         parentQuestion!=null?parentQuestion.getMaxSubQuestionDisplayOrder()+1:survey.questionNumCounter() + 1,
                                                         true,
                                                         false,
                                                         survey,
                                                         queType,
                                                         new TreeSet(),//surveyUsrResps
                                                         new TreeSet(),//answer set
                                                         new TreeSet(),//surveyQueUsrs
                                                         new TreeSet(),//subQuestions
                                                         parentQuestion);
        //if it is not composite choice type, we initialize an empty candidate
        //answer. We don't do it for composite choice because we have defined the
        //default scales(candidate answers) in the resource file
        if(!queType.getName().equals(SurveyQueType.COMPOSITE_CHOICE))
            question.initializeAnswerSet();
        return question;
    }

    /**
     * @param answerDisplayOrder
     * @param action
     */
    public void resetAnswerList(int answerDisplayOrder, String action)
    {
        List orgAnswerList = (List) this.get("candidateAnswers");
        List toBeRemovedAnswerList = new ArrayList();

        for (Iterator i = orgAnswerList.iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();
            if (answer.getDisplayOrder() == (answerDisplayOrder - 1)
                    && action.equals(AuthoringAction.MOVE_UP))
            {
                answer.setDisplayOrder(answerDisplayOrder);
            }
            else if (answer.getDisplayOrder() == answerDisplayOrder)
            {
                if (action.equals(AuthoringAction.MOVE_UP))
                {
                    answer.setDisplayOrder(answerDisplayOrder - 1);
                }
                else if (action.equals(AuthoringAction.MOVE_DOWN))
                {
                    answer.setDisplayOrder(answerDisplayOrder + 1);
                }
                else if(action.equals(AuthoringAction.REMOVE))
                {
                    toBeRemovedAnswerList.add(answer);
                }
            }
            else if (answer.getDisplayOrder() == (answerDisplayOrder + 1)
                    && action.equals(AuthoringAction.MOVE_DOWN))
                answer.setDisplayOrder(answerDisplayOrder);

        }
        SurveyQueContent question = (SurveyQueContent) this.get("question");
        question.removeAnsFromQuestion(toBeRemovedAnswerList);
        resetAnswersDisplayOrder(answerDisplayOrder, action, orgAnswerList);
        //sort the answers
        List answers = new LinkedList(question.getSurveyAnsContents());
        Collections.sort(answers);
        this.set("candidateAnswers", answers);
        this.set("question", question);

    }

    /**
     * @param answerDisplayOrder
     * @param action
     * @param orgAnswerList
     */
    private void resetAnswersDisplayOrder(int answerDisplayOrder, String action, List orgAnswerList)
    {

        for (Iterator i = orgAnswerList.iterator(); i.hasNext();)
        {
            SurveyAnsContent answer = (SurveyAnsContent) i.next();

            if (action.equals(AuthoringAction.REMOVE)
                && answer.getDisplayOrder() > answerDisplayOrder)
                answer.setDisplayOrder(answer.getDisplayOrder() - 1);
        }
    }

    /**
     * 
     */
    public void submitQuestionToSurvey()
    {
        SurveyQueContent questionToSubmit = (SurveyQueContent) (this.get("parentQuestion")!=null?this.get("parentQuestion"):this.get("question"));
        
        //validate pre-condition
        if (questionToSubmit.getDisplayOrder() < 1)
            throw new SurveyApplicationException("Invalid question "
                    + "display order [" + questionToSubmit.getDisplayOrder() + "]");

        SurveyContent survey = (SurveyContent) this.get("survey");

        if (questionToSubmit.getSurveyQueContentId() == null)
            survey.getSurveyQueContents().add(questionToSubmit);
        else
            survey.updateSurveyQueContent(questionToSubmit);

        this.set("survey",survey);
        this.set("questionList",survey.getSurveyQuestionAsSortedList());
    }

    /**
     * @return Returns the isSurveyNew.
     */
    public boolean isSurveyNew()
    {
        return this.get("isSurveyNew") != null ? ((Boolean) this.get("isSurveyNew")).booleanValue()
                : false;
    }

    /**
     * 
     */
    public void addEmptyAnswerToList()
    {
        List answerList = (List) this.get("candidateAnswers");
        SurveyQueContent question = (SurveyQueContent) this.get("question");
        answerList.add(new SurveyAnsContent("",
                                            question.getMaxAnswerDispalyOrder() + 1,
                                            new TreeSet(),
                                            question));
        question.setSurveyAnsContents(new TreeSet(answerList));
        this.set("candidateAnswers", answerList);
        this.set("question", question);
    }

    /**
     * 
     * @param displayOrder
     * @param action
     */
    public void resetSurveyQuestions(int displayOrder, String action)
    {
        SurveyContent survey = (SurveyContent)this.get("survey");
        Set toBeRemovedQuestionsSet = new TreeSet();
        
        for(Iterator i = survey.getSurveyQueContents().iterator();i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent)i.next();
            if(shouldWeChangeBeforeQuestion(displayOrder, action, question))
            {
                question.setDisplayOrder(displayOrder);
            }
            else if(shouldWeChangeCurrentQuestion(displayOrder, question))
            {
                if (action.equals(AuthoringAction.MOVE_UP))
                {
                    question.setDisplayOrder(displayOrder - 1);
                }
                else if (action.equals(AuthoringAction.MOVE_DOWN))
                {
                    question.setDisplayOrder(displayOrder + 1);
                }
                else if(action.equals(AuthoringAction.REMOVE))
                {
                    //toBeRemovedQuestionsSet.add(question);
                    //remove sub-question if there is one available.
                    toBeRemovedQuestionsSet.addAll(question.getSubQuestions());
                    question.getSubQuestions().clear();
                    i.remove();
                }
            }
            else if(shouldWeChangeAfterQuestion(displayOrder, action, question))
            {
                question.setDisplayOrder(displayOrder);
            }
        }

        survey.removeSubQuestions(toBeRemovedQuestionsSet);
        
        resetQuestionDisplayOrder(displayOrder, action, survey);

        this.set("questionList", survey.getSurveyQuestionAsSortedList());
        this.set("survey",survey);
    }

    /**
     * 
     * @param displayOrder
     * @param action
     */
    public void resetSubQuestions(int displayOrder, String action)
    {
        SurveyContent survey = (SurveyContent)this.get("survey");
        SurveyQueContent parent = (SurveyQueContent)this.get("parentQuestion");
        Set toBeRemovedQuestionsSet = new TreeSet();
        
        for(Iterator i = parent.getSubQuestions().iterator();i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent)i.next();
            if(question.getDisplayOrder() == (displayOrder - 1)
                		&& action.equals(AuthoringAction.MOVE_UP))
            {
                question.setDisplayOrder(displayOrder);
            }
            else if(question.getDisplayOrder() == displayOrder)
            {
                if (action.equals(AuthoringAction.MOVE_UP))
                {
                    question.setDisplayOrder(displayOrder - 1);
                }
                else if (action.equals(AuthoringAction.MOVE_DOWN))
                {
                    question.setDisplayOrder(displayOrder + 1);
                }
                else if(action.equals(AuthoringAction.REMOVE))
                {
                    i.remove();
                    toBeRemovedQuestionsSet.add(question);
                }
            }
            else if(question.getDisplayOrder() == (displayOrder + 1)
        				&& action.equals(AuthoringAction.MOVE_DOWN))
            {
                question.setDisplayOrder(displayOrder);
            }
        }

        survey.removeSubQuestions(toBeRemovedQuestionsSet);
        //parent.removeSubQuestion(toBeRemovedQuestionsSet);
        if(action.equals(AuthoringAction.REMOVE))
            resetSubQuestionDisplayOrder(displayOrder,parent);
        //sort the questions
        List subQuestions = new LinkedList(parent.getSubQuestions());
        Collections.sort(subQuestions);
        this.set("subQuestionList", subQuestions);
        this.set("survey",survey);
    }
    

    public void resetSubQuestionDisplayOrder(int displayOrder, 
                                             SurveyQueContent parent)
    {
        for(Iterator i = parent.getSubQuestions().iterator();i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent)i.next();
            if (question.getDisplayOrder() > displayOrder)
                question.setDisplayOrder(question.getDisplayOrder() - 1);
        }
    }
    /**
     * @param displayOrder
     * @param action
     * @param survey
     */
    private void resetQuestionDisplayOrder(int displayOrder, String action, SurveyContent survey)
    {
        for(Iterator i = survey.getSurveyQueContents().iterator();i.hasNext();)
        {
            SurveyQueContent question = (SurveyQueContent)i.next();
            if (shouldWeAdjustOrderForRemove(displayOrder, action, question))
                question.setDisplayOrder(question.getDisplayOrder() - 1);
        }
    }

    /**
     * @param displayOrder
     * @param action
     * @param question
     * @return
     */
    private boolean shouldWeAdjustOrderForRemove(int displayOrder, String action, SurveyQueContent question)
    {
        return action.equals(AuthoringAction.REMOVE)
                && question.getDisplayOrder() > displayOrder
                && question.getParentQuestion()==null;
    }

    /**
     * @param displayOrder
     * @param question
     * @return
     */
    private boolean shouldWeChangeCurrentQuestion(int displayOrder, SurveyQueContent question)
    {
        return question.getDisplayOrder() == displayOrder
        		&& question.getParentQuestion()==null;
    }

    /**
     * @param displayOrder
     * @param action
     * @param question
     * @return
     */
    private boolean shouldWeChangeAfterQuestion(int displayOrder, String action, SurveyQueContent question)
    {
        return question.getDisplayOrder() == (displayOrder + 1)
    			&& action.equals(AuthoringAction.MOVE_DOWN)
    			&& question.getParentQuestion()==null;
    }

    /**
     * @param displayOrder
     * @param action
     * @param question
     * @return
     */
    private boolean shouldWeChangeBeforeQuestion(int displayOrder, String action, SurveyQueContent question)
    {
        return question.getDisplayOrder() == (displayOrder - 1)
                	&& action.equals(AuthoringAction.MOVE_UP)
                	&& question.getParentQuestion()==null;
    }

    /**
     * 
     */
    public void buildParentQuestionAssociation()
    {

        SurveyQueContent parent = (SurveyQueContent)this.get("parentQuestion");
        parent.getSubQuestions().add(this.get("question"));
        this.set("parentQuestion",parent);
        
    }

    /**
     * @param request
     * @param isNew TODO
     * @param this
     */
    public void setUpSubQuestion(SurveyQueType queType, HttpServletRequest request, boolean isNew)
    {
        SurveyQueContent parent = (SurveyQueContent)this.get("parentQuestion");
        if(isNew)
        	parent.addEmptySubQuestion(queType);
        //sort subQuestions
        LinkedList subQuestions = new LinkedList(parent.getSubQuestions());
        Collections.sort(subQuestions);
        set("subQuestionList",subQuestions);
    }
    /**
     * @return
     */
    public List getQuestionScales()
    {
        SurveyQueContent parent = (SurveyQueContent)this.get("parentQuestion");
        return parent.getAnswerEntryList();
    }

    /**
     * Add an empty String element to the scale list in the authoring form
     */
    public void addEmptyScale()
    {
        List scales = (List)get("scales");
        scales.add("");
        set("scales",scales);
    }

    /**
     * 
     */
    public void submitScaleIntoQuestion()
    {
        SurveyQueContent queContent = (SurveyQueContent)get("parentQuestion");

        List scales = (List)get("scales");
        
        for(int i=0;i<scales.size();i++)
        {
            String scale = (String)scales.get(i);
            if(!queContent.getSurveyAnsByDisplayOrder(i+1).isNull())
                queContent.updateCandidatAnswer(scale,i+1);
            else
                queContent.getSurveyAnsContents().add(new SurveyAnsContent(scale,
                                                                       i+1,
                                                                       new TreeSet(),
                                                                       queContent));
        }
        set("parentQuestion",queContent);
    }

}
