package org.lamsfoundation.lams.tool.survey;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;



/** 
 * @hibernate.class table="tool_lasr10_survey_usr_resp"
 *     
 */
public class SurveyUsrResp implements Serializable, Comparable
{

    /** identifier field */
    private Long responseId;

    /** nullable persistent field */
    private String answer;

    /** nullable persistent field */
    private Date attemptDate;

    /** persistent field */
    private SurveyQueContent surveyQueContent;

    /** nullable persistent field */
    private SurveyAnsContent surveyAnsContent;

    /** persistent field */
    private SurveyQueUsr surveyQueUsr;
    
    /** full constructor */
    public SurveyUsrResp(Long responseId,
                         String answer,
                         Date attemptDate,
                         SurveyQueContent surveyQueContent,
                         SurveyAnsContent surveyAnsContent,
                         SurveyQueUsr surveyQueUsr)
    {
        this.responseId = responseId;
        this.answer = answer;
        this.attemptDate = attemptDate;
        this.surveyQueContent = surveyQueContent;
        this.surveyAnsContent = surveyAnsContent;
        this.surveyQueUsr = surveyQueUsr;
    }

    /** default constructor */
    public SurveyUsrResp()
    {
    }

    /**
     * minimal constructor
     * @param string
     * @param date
     * @param question
     * @param surveyAnsById
     */
    public SurveyUsrResp(String answer,
                         Date attemptDate,
                         SurveyQueContent question,
                         SurveyAnsContent surveyAns)
    {
        this(null,answer,attemptDate,question,surveyAns,null);
    }

    /**
     * Copy construtor. Delegate to full construtor to achieve the object
     * creation.
     * @param response the original survey user response
     * @return the new survey user response cloned from original object
     */
    public static SurveyUsrResp newInstance(SurveyUsrResp response)
    {
        return new SurveyUsrResp(response.getResponseId(),
                                 response.getAnswer(),
                                 response.getAttemptDate(),
                                 response.getSurveyQueContent(),
                                 response.getSurveyAnsContent(),
                                 response.surveyQueUsr);
    }

    /**
     * @param string
     * @param date
     * @param question
     */
    public SurveyUsrResp(String answer,
                         Date attemptDate,
                         SurveyQueContent question)
    {

        this.answer = answer;
        this.attemptDate = attemptDate;
        this.surveyQueContent = question;
    }

    /** 
     * @hibernate.id generator-class="increment" type="java.lang.Long"
     *               column="response_id"     
     */
    public Long getResponseId()
    {
        return this.responseId;
    }

    public void setResponseId(Long responseId)
    {
        this.responseId = responseId;
    }

    /** 
     * @hibernate.property column="answer" length="65535"
     * 			       
     */
    public String getAnswer()
    {
        return this.answer;
    }

    public void setAnswer(String answer)
    {
        this.answer = answer;
    }

    /** 
     * @hibernate.property column="attempt_date" length="19"
     *         
     */
    public Date getAttemptDate()
    {
        return this.attemptDate;
    }

    public void setAttemptDate(Date attemptDate)
    {
        this.attemptDate = attemptDate;
    }

    /** 
     * @hibernate.many-to-one not-null="true"
     * @hibernate.column name="survey_que_content_id"         
     *         
     */
    public SurveyQueContent getSurveyQueContent()
    {
        return this.surveyQueContent;
    }

    public void setSurveyQueContent(SurveyQueContent surveyQueContent)
    {
        this.surveyQueContent = surveyQueContent;
    }

    /** 
     * @hibernate.many-to-one not-null="true" cascade="save-update"	
     * @hibernate.column name="survey_ans_content_id"         
     *         
     */
    public SurveyAnsContent getSurveyAnsContent()
    {
        return this.surveyAnsContent;
    }

    public void setSurveyAnsContent(SurveyAnsContent surveyAnsContent)
    {
        this.surveyAnsContent = surveyAnsContent;
    }

    /** 
     * @hibernate.many-to-one not-null="true" cascade="none"
     * @hibernate.column name="que_usr_id"         
     *         
     */
    public SurveyQueUsr getSurveyQueUsr()
    {
        return this.surveyQueUsr;
    }

    public void setSurveyQueUsr(SurveyQueUsr surveyQueUsr)
    {
        this.surveyQueUsr = surveyQueUsr;
    }

    /**
     * Update current object according to the new response object.
     * @param resp
     */
    public void updateResponse(SurveyUsrResp resp)
    {
        if(!resp.isResponseValid())
            throw new IllegalArgumentException("Invalid response for update ");
        
        this.setAnswer(resp.getAnswer());
        this.setAttemptDate(resp.getAttemptDate());
        this.setSurveyQueContent(resp.getSurveyQueContent());
        //create new answer content if necessary
        if (resp.getSurveyAnsContent().isNull())
            this.addNewAnswerContent();
        else 
            this.setSurveyAnsContent(resp.getSurveyAnsContent());
        this.setSurveyQueUsr(resp.getSurveyQueUsr());
        
    }

    /**
     * @param resp
     */
    public void addNewAnswerContent()
    {
        TreeSet resSet = new TreeSet();
        resSet.add(this);
        this.setSurveyAnsContent(new SurveyAnsContent(this.getAnswer(),
                                                      SurveyAnsContent.DISPLAY_ORDER_INVISIBLE,
                                                      resSet,
                                                      this.getSurveyQueContent()));
    }

    /**
     * The response is not valid if it doesn't have a reference to question 
     * object and question user object.
     * @param resp the response to be validated
     * @return the validation result.
     */
    public boolean isResponseValid()
    {
		return this.getSurveyQueUsr()!=null&&this.getSurveyQueContent()!=null
			   &&this.getSurveyAnsContent()!=null;
    }

    public String toString()
    {
        return new ToStringBuilder(this).append("responseId", getResponseId())
        								.append("answer",getAnswer())
        								.append("attempt date",getAttemptDate())
        								.append("survey question content",getSurveyQueContent())
        								.append("survey answer content",getSurveyAnsContent())
        								.append("survey question user",getSurveyQueUsr())
                                        .toString();
    }

    public boolean equals(Object other)
    {
        if (!(other instanceof SurveyUsrResp))
            return false;
        SurveyUsrResp castOther = (SurveyUsrResp) other;
        return new EqualsBuilder().append(this.getResponseId(),
                                          castOther.getResponseId())
                                  .append(this.getAnswer(),
                                          castOther.getAnswer())
                                  .isEquals();
    }

    public int hashCode()
    {
        return new HashCodeBuilder().append(getResponseId())
                                    .append(getAnswer())
                                    .toHashCode();
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o)
    {
        SurveyUsrResp response = (SurveyUsrResp) o;

        if (responseId == null)
            return -1;
        if (response.responseId == null)
            return 1;

        return (int) (responseId.longValue() - response.responseId.longValue());
    }

    /**
     * @param responses
     * @return
     */
    public boolean doesRespExistIn(List responses)
    {
        for(Iterator i = responses.iterator();i.hasNext();)
        {
            SurveyUsrResp resp = (SurveyUsrResp)i.next();
            //if(resp.getSurveyAnsContent().getSurveyAnsContentId().equals(this.getSurveyAnsContent().getSurveyAnsContentId()))
            if((resp.getAnswer().trim()).equals(this.getAnswer().trim())
                    &&resp.getSurveyQueUsr().getQueUsrId()==this.getSurveyQueUsr().getQueUsrId())
            return true;
        }
        return false;
    }

    /**
     * @param responses
     */
    public void updateResponseBy(List responses)
    {
        for(Iterator i = responses.iterator();i.hasNext();)
        {
            SurveyUsrResp resp = (SurveyUsrResp)i.next();
            //if(resp.getSurveyAnsContent().getSurveyAnsContentId().equals(this.getSurveyAnsContent().getSurveyAnsContentId()))
            if(resp.getSurveyQueUsr().getQueUsrId()==this.getSurveyQueUsr().getQueUsrId()
                   && resp.getSurveyAnsContent().getDisplayOrder()==this.getSurveyAnsContent().getDisplayOrder())
                this.updateResponse(resp);

        }
    }
    
    /**
     * Validate whether the current response is correspondent to an author 
     * defined answer.
     * 
     * @return boolean value
     */
    public boolean isPredefinedResponse()
    {
        //return true if it correspondent to an answer that is not predefined
        //by the author
        if (this.getSurveyAnsContent().getDisplayOrder() != SurveyConstants.NOT_SHOWN)
            return true;
        //always return true if it is a text entry question
        if (this.getSurveyQueContent().getSurveyQueType().getName().equals(SurveyConstants.TEXT_ENTRY))
            return true;

        return false;
    }
}