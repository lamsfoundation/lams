package org.lamsfoundation.lams.tool.survey;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** 
 * @hibernate.class table="tool_lasr10_survey_ans_content"
 *     
 */
public class SurveyAnsContent implements Serializable,Nullable,Comparable {

    /** identifier field */
    private Long surveyAnsContentId;

    /** nullable persistent field */
    private String answerEntry;

    /** nullable persistent field */
    private int displayOrder;

    /** nullable persistent field */
    private Set surveyUsrResps;

    /** persistent field */
    private SurveyQueContent surveyQueContent;
    
    /** none persistent field */
    private int numberOfResponse;
    //---------------------------------------------------------------------
    // Class level constants
    //---------------------------------------------------------------------
    public static final int DISPLAY_ORDER_INVISIBLE = -1;
    
    /** full constructor */
    public SurveyAnsContent(String answerEntry, int dispalyOrder, Set surveyUsrResps, SurveyQueContent surveyQueContent) {
        this.answerEntry = answerEntry;
        this.displayOrder = dispalyOrder;
        this.surveyUsrResps = surveyUsrResps;
        this.surveyQueContent = surveyQueContent;
    }

    /** default constructor */
    public SurveyAnsContent() {
    }

    /** minimal constructor */
    public SurveyAnsContent(SurveyQueContent surveyQueContent) {
        this.surveyQueContent = surveyQueContent;
    }
    /**
     * @param newQueContent
     * @return
     */
    public static SurveyAnsContent newInstance(SurveyAnsContent ansContent,
                                               SurveyQueContent newQueContent)
    {
        return new SurveyAnsContent(ansContent.getAnswerEntry(),
                                    ansContent.getDisplayOrder(),
                                    new TreeSet(),
                                    newQueContent);
    }
    /** 
     * @hibernate.id generator-class="increment" type="java.lang.Long"
     *               column="survey_ans_content_id"
     *         
     */
    public Long getSurveyAnsContentId() {
        return this.surveyAnsContentId;
    }

    public void setSurveyAnsContentId(Long surveyAnsContentId) {
        this.surveyAnsContentId = surveyAnsContentId;
    }

    /** 
     * @hibernate.property column="answer_entry" length="255"
     *         
     */
    public String getAnswerEntry() {
        return this.answerEntry;
    }

    public void setAnswerEntry(String answerEntry) {
        this.answerEntry = answerEntry;
    }

    /** 
     * @hibernate.property column="dispaly_order" length="11"
     *         
     */
    public int getDisplayOrder() {
        return this.displayOrder;
    }

    public void setDisplayOrder(int displayOrder) {
        this.displayOrder = displayOrder;
    }

    /** 
     * @hibernate.set lazy="false" inverse="true" cascade="none"
     * @hibernate.collection-key column="survey_ans_content_id"
     * @hibernate.collection-one-to-many
     *            class="org.lamsfoundation.lams.tool.survey.SurveyUsrResp"
     *         
     */
    public Set getSurveyUsrResps() {
        if (this.surveyUsrResps == null)
            setSurveyUsrResps(new TreeSet());
        return this.surveyUsrResps;
    }

    public void setSurveyUsrResps(Set surveyUsrResps) {
        this.surveyUsrResps = surveyUsrResps;
    }

    /** 
     * @hibernate.many-to-one not-null="true"
     * @hibernate.column name="survey_que_content_id"         
     *         
     */
    public SurveyQueContent getSurveyQueContent() {
        return this.surveyQueContent;
    }

    public void setSurveyQueContent(SurveyQueContent surveyQueContent) {
        this.surveyQueContent = surveyQueContent;
    }

    public String toString() {
        return new ToStringBuilder(this).append("surveyAnsContentId", getSurveyAnsContentId())
            						    .append("answer entry",getAnswerEntry())
            						    .append("display order",getDisplayOrder())
            						    .append("user responses",getSurveyUsrResps())
            						    .append("question content",getSurveyQueContent())
            						    .append("number of responses",getNumberOfResponse())
                                        .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SurveyAnsContent) ) return false;
        SurveyAnsContent castOther = (SurveyAnsContent) other;
        return new EqualsBuilder()
            .append(this.getSurveyAnsContentId(), castOther.getSurveyAnsContentId())
            .append(this.getDisplayOrder(),castOther.getDisplayOrder())
            .append(this.getAnswerEntry(),castOther.getAnswerEntry())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getSurveyAnsContentId())
            .append(getDisplayOrder())
            .append(getAnswerEntry())
            .toHashCode();
    }

    /**
     * validate null value id. throw exception if it is null.
     */
    public void checkForID()
    {
        if(this.surveyAnsContentId==null)
            throw new SurveyApplicationException("The id for requested " +
            		"candidate answer is null.");
    }
    /**
     * @return Returns the numberOfResponse.
     */
    public int getNumberOfResponse()
    {
        return numberOfResponse=this.getSurveyUsrResps().size();
    }
    /**
     * This object should not be null.
     * @see org.lamsfoundation.lams.tool.survey.Nullable#isNull()
     */
    public boolean isNull()
    {
        return false;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o)
    {
        SurveyAnsContent ansContent = (SurveyAnsContent)o;
        //always display new negative display order after positive
        if(displayOrder>0&&ansContent.displayOrder<0)
            return -1;
        if(displayOrder<0&&ansContent.displayOrder>0)
            return 1;

        //if they both negative or positive
        int diff = displayOrder - ansContent.displayOrder;
        if(diff!=0)
            return diff;
        
        if(surveyAnsContentId==null&&ansContent.surveyAnsContentId!=null)
            return 1;
        
        if(surveyAnsContentId!=null&&ansContent.surveyAnsContentId==null)
            return -1;
        
        if(surveyAnsContentId==null&&ansContent.surveyAnsContentId==null)
            return -1;
            
        //compare candidateAnswersId if displayOrders are the same
        //this only happens when they are both negative
        return (int)(surveyAnsContentId.longValue()-ansContent.surveyAnsContentId.longValue());

    }
}
