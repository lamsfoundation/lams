/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2005 
 * Created on 20/01/2005
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey.dao;

import java.util.List;


/**
 * 
 * @author Jacky Fang 20/01/2005
 * 
 */
public interface IQuestionTypeDAO
{

    public List getAllQuestionTypes();
    
}
