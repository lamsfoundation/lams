package org.lamsfoundation.lams.tool.survey.web;

import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

import org.lamsfoundation.lams.lesson.Lesson;
import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveyContent;
import org.lamsfoundation.lams.tool.survey.SurveyQueContent;
import org.lamsfoundation.lams.tool.survey.SurveySession;



/**
 * Struts form bean class.As we are using dyna formbean, all bean attributs 
 * are implemented in the Struts configuration file.
 * 
 * @author Jacky Fang
 *  
 */
public class ReportForm extends DynaValidatorForm
{
    //---------------------------------------------------------------------
    // Inherited Methods
    //---------------------------------------------------------------------
    
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        //do nothing.
    }

    /**
     * Nothing needs to be validated in the form so far.
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {

        ActionErrors errors = new ActionErrors();

        return errors;
    }
    //---------------------------------------------------------------------
    // Form bean data transformation Methods
    //---------------------------------------------------------------------
    /**
     * Build the reporting form bean using domain data object.
     * @param request A standard Servlet HttpServletRequest class.
     * @param survey the SurSurveyVO domain object
     * @param curLesson the LearningSession domain data object.
     * @param surveyClassSize the number of total learner of the survey session
     * @param numberOfLeanerCompleted the number of completed learner
     */
    public void buildReportForm(HttpServletRequest request,
                                SurveySession surveySession,
                                Lesson curLesson,
                                int surveyClassSize,
                                int numberOfLeanerCompleted)
    {
        //validate passed in parameters before us move on
        if (surveySession == null || surveySession.getSurveyContent()==null||
                surveySession.getSurveyContent().getSurveyQueContents() == null)
            throw new SurveyApplicationException("The requested survey is not available"
                    + " in the database.");

        this.set("sessionId", surveySession.getSurveySessionId());
        //this.set("learningSequenceName", curLesson.getLearningDesign().getTitle());
        //TODO change this to above implementation once core is done
        this.set("learningSequenceName", "TEST DESIGN");
        this.set("totalLearnerNum", new Integer(surveyClassSize));
        this.set("NumOfCompletedLeaner", new Integer(numberOfLeanerCompleted));
        this.set("startDate",surveySession.getSessionStartDate());
        this.set("survey", surveySession.getSurveyContent());

    }

    /**
     * Retrieve a paticular question object from survey reporting object.
     * @param questionId the question id we want to retrieve.
     * @return the question domain value object.
     * @throws SystemException the known error status for lams
     */
    public SurveyQueContent getQuestionFromSurvey(String questionId)
    {
        //validate pre-condition of this method
        if (questionId == null)
            throw new SurveyApplicationException("Fail to get question identifier for "
                    + "question report");
        //get survey data oject from form bean
        SurveyContent survey = (SurveyContent) this.get("survey");
        
        for (Iterator i = survey.getSurveyQueContents().iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();
            if (q.getDisplayOrder() == Integer.parseInt(questionId))
                return q;
        }
        throw new SurveyApplicationException("The requested question does not exist!");

    }

    /**
     * Build the xls report for survey data.
     * @return the XLS format String with all survey reporting data
     */
    public String buildXLSReport()
    {
        //get variables
        int totalLeaners = ((Integer)this.get("totalLearnerNum")).intValue();
        int completedLeaners =((Integer)this.get("NumOfCompletedLeaner")).intValue();
        int percent = Math.round((float)completedLeaners/(float)totalLeaners*100);
        SurveyContent survey = (SurveyContent) this.get("survey");
        
        //Let's build the report 
        StringBuffer sb = new StringBuffer();        
        //general survey information
        sb.append("Sequence Name:\t"+(String)this.get("learningSequenceName")+"\n")
          .append("Start Date:\t"+survey.getDateCreated().toString()+" \n")
          .append("Total number of students in class:\t"+totalLeaners+" \n")
          .append("Total number of students that completed survey:\t"+completedLeaners+" ("+percent+"%)\n")
          .append("\n\n");
        //append question report
        for(Iterator i=survey.getSurveyQueContents().iterator();i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent)i.next();
            sb.append(q.getXLSCandidateAnswerString())
              .append("\n")
              .append(q.getXLSQuestionUserString())
              .append("\n\n");
            
        }
       
        return sb.toString();
    }

}
