package org.lamsfoundation.lams.tool.survey.dao.hibernate;

import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import org.lamsfoundation.lams.tool.survey.SurveySession;
import org.lamsfoundation.lams.tool.survey.dao.ISurveySessionDAO;


/**
 * @author Jacky Fang
 *
 */
public class SurveySessionDAO extends HibernateDaoSupport implements
                                                         ISurveySessionDAO
{

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveySessionDAO#getSurveySessionById(long)
     */
    public SurveySession getSurveySessionById(Long surveySessionId)
    {
        return (SurveySession)this.getHibernateTemplate().load(SurveySession.class,surveySessionId);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveySessionDAO#CreateSurveySession(com.lamsinternational.tool.survey.domain.SurveySession)
     */
    public void CreateSurveySession(SurveySession session)
    {
        this.getHibernateTemplate().save(session);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveySessionDAO#UpdateSurveySession(com.lamsinternational.tool.survey.domain.SurveySession)
     */
    public void UpdateSurveySession(SurveySession session)
    {
        this.getHibernateTemplate().update(session);
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.interfaces.ISurveySessionDAO#deleteSurveySession(com.lamsinternational.tool.survey.domain.SurveySession)
     */
    public void deleteSurveySession(SurveySession surSession)
    {
        this.getHibernateTemplate().delete(surSession);
    }

}
