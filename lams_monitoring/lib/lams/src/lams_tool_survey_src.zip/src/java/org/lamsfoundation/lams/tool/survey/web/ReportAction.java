package org.lamsfoundation.lams.tool.survey.web;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;


import org.lamsfoundation.lams.lesson.Lesson;
import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveyQueContent;
import org.lamsfoundation.lams.tool.survey.SurveySession;
import org.lamsfoundation.lams.tool.survey.service.ISurveyService;
import org.lamsfoundation.lams.tool.survey.service.SurveyServiceProxy;
import org.lamsfoundation.lams.util.WebUtil;


/**
 * <p>Action class that controls the logic of survey reporting behavior. 
 * It loads the survey data from database and show a specific question report.
 * It also provides the exporting functionality.
 * </p>
 * <p>Note that Struts action class only has the responsibility to navigate 
 * page flow. All database operation should go to service layer and data 
 * transformation from domain model to struts form bean should go to form 
 * bean class. This ensure clean and maintainable code.
 * </p>
 * 
 * <code>SystemException</code> is thrown whenever an known error condition is
 * identified. No system exception error handling code should appear in the 
 * Struts action class as all of them are handled in 
 * <code>CustomStrutsExceptionHandler<code>.
 * 
 * ----------------XDoclet Tags--------------------
 * 
 * @struts:action path="/tool/survey/report" name="ReportForm"
 *                attribute="ReportForm" input=".viewReport" parameter="method"
 *                scope="session" validate="false"
 * 
 * @struts.action-exception key="error.system.survey" scope="request"
 *                          type="org.lamsfoundation.lams.tool.survey.SurveyApplicationException"
 *                          path=".systemError"
 * 							handler="org.lamsfoundation.lams.util.CustomStrutsExceptionHandler"
 * 
 * @struts:action-forward name="view" path=".viewReport" 
 * @struts:action-forward name="empty" path=".emptyReport"
 * @struts:action-forward name="question" path=".viewQuestion"
 * @struts:action-forward name="viewchart" path=".viewChart"                         
 * ----------------XDoclet Tags--------------------
 */
public class ReportAction extends DispatchAction
{

    //---------------------------------------------------------------------
    // Instance variables
    //---------------------------------------------------------------------
    private static Logger log = Logger.getLogger(ReportAction.class);

    //---------------------------------------------------------------------
    // Class level constants - Struts forward
    //---------------------------------------------------------------------
    private static final String VIEW_REPORT = "view";
    private static final String VIEW_EMPTY_REPORT = "empty";
    private static final String EXPORT_REPORT = "export";
    private static final String VIEW_QUESTION = "question";
    private static final String VIEW_CHART = "viewchart";
    //---------------------------------------------------------------------
    // Class level constants - Session attributs
    //---------------------------------------------------------------------
    private static final String PARAM_CHART_TYPE = "chartType";
    private static final String PARAM_QUESTION_ID = "questionId";
    private static final String REPORT_NAME = "lams_survey";
    private static final String ATTR_CHART_TYPE = "chartType";
    private static final String ATTR_QUESTION = "question";
    private static final boolean MODE_OPTIONAL = false;

    //---------------------------------------------------------------------
    // Struts dispatch actions
    //---------------------------------------------------------------------
    /** 
     * Struts dispatch method. This method loads the survey from database 
     * and populate report form bean for reporting. 
     * 
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     * @throws SystemException the known runtime exception 
     * 
     */
    public ActionForward loadMonitorReport(ActionMapping mapping,
                                           ActionForm form,
                                           HttpServletRequest request,
                                           HttpServletResponse response)
    {

        ReportForm reportForm = (ReportForm) form;

        ISurveyService surveyService = SurveyServiceProxy.getSurveyService(getServlet().getServletContext());

         if (reportForm != null)
        {
            //It is ensured to be not null by dyna validator.
            long toolSessionId = ((Long) reportForm.get("sessionId")).longValue();
            
            //long lessonId = WebUtil.getCurrentLessonId(request);
            //TODO need to change to above implementation once core is done
            long lessonId = 1;
            
            //get survey data and learning session data for reporting
            SurveySession surveySession = surveyService.retrieveSurveySession(toolSessionId);
            int totalNumberofUserResponsed = surveyService.countTotalNumberOfUserResponsed(surveySession.getSurveyContent());

            //display empty report page if no response can been found
            if (totalNumberofUserResponsed == 0)
                return (mapping.findForward(VIEW_EMPTY_REPORT));

            Lesson curLesson = surveyService.getCurrentLesson(lessonId);
            int surveyClassSize = surveyService.getSurveyClassSize(surveySession.getSurveyContent().getSurveyContentId());

            //hand the data over to form bean to construt reporting form bean
            reportForm.buildReportForm(request,
                                       surveySession,
                                       curLesson,
                                       surveyClassSize,
                                       totalNumberofUserResponsed);
        }
        else
        {
            log.error("Fail to load the survey report for monitor!");
            throw new SurveyApplicationException("Fail to load the survey report for monitor!");
        }
        //populate http session.
        request.getSession().setAttribute("ReportForm", reportForm);
        return (mapping.findForward(VIEW_REPORT));
    }

    /** 
     * Struts dispatch method. This method construts single reporting object
     * for single question and navigate to individual question page for 
     * reporting.
     * 
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     * @throws SystemException the known runtime exception 
     * 
     */
    public ActionForward loadQuestionReport(ActionMapping mapping,
                                            ActionForm form,
                                            HttpServletRequest request,
                                            HttpServletResponse response) throws IOException,
                                                                         ServletException
    {
        String questionId = WebUtil.readStrParam(request, PARAM_QUESTION_ID);

        ReportForm reportForm = (ReportForm) form;

        SurveyQueContent curQuestion = reportForm.getQuestionFromSurvey(questionId);

        request.getSession().setAttribute("question", curQuestion);
        return (mapping.findForward(VIEW_QUESTION));
    }

    /** 
     * Struts dispatch method. Ask form bean to transform the survey data into
     * xls format for exporting.
     * 
     * Return to tell browser not to go to a new page but display a popup 
     * attachment downloading dialog. 
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     * @throws SystemException the known runtime exception 
     * 
     */
    public ActionForward exportReport(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response) throws IOException,
                                                                   ServletException
    {
        ReportForm reportForm = (ReportForm) form;

        response.setContentType("application/vnd.ms-excel");
        PrintWriter out = response.getWriter();

        out.print(reportForm.buildXLSReport());
        //set response header to pop up downloading window
        response.setHeader("Content-disposition", "attachment;filename="
                + REPORT_NAME + ".xls");

        return null;
    }

    /**
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * 
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward viewChart(ActionMapping mapping,
                                   ActionForm form,
                                   HttpServletRequest request,
                                   HttpServletResponse response) throws IOException,
                                                                ServletException
    {
        String chartType = WebUtil.readStrParam(request, PARAM_CHART_TYPE);
        String questionId = WebUtil.readStrParam(request, PARAM_QUESTION_ID);

        ReportForm reportForm = (ReportForm) form;

        SurveyQueContent curQuestion = reportForm.getQuestionFromSurvey(questionId);

        request.getSession().setAttribute(ATTR_QUESTION, curQuestion);
        request.setAttribute(ATTR_CHART_TYPE, chartType);

        return (mapping.findForward(VIEW_CHART));
    }

    /**
     * 
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * 
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     * @throws IOException
     * @throws ServletException
     */
    public ActionForward loadChartPic(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response) throws IOException,
                                                                   ServletException
    {
        SurveyQueContent question = (SurveyQueContent) request.getSession()
                                                        .getAttribute(ATTR_QUESTION);
        String chartType = WebUtil.readStrParam(request, PARAM_CHART_TYPE);
        OutputStream out = response.getOutputStream();

        JFreeChart chart = null;

        if (chartType.equals("piechart"))
            chart = question.createPieChart();
        else if (chartType.equals("columnchart"))
            chart = question.createColumnChart();

        if (chart != null)
        {
            response.setContentType("image/png");
            ChartUtilities.writeChartAsPNG(out, chart, 400, 300);
        }

        return null;
    }
}
