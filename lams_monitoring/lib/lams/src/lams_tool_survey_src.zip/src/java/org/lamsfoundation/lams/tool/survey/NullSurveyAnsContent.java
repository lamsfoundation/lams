/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2004 
 * Created on 2004-12-3
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey;


/**
 * Null version of SurveyAnsContent object.
 * 
 * @author Jacky Fang 2004-12-3
 * 
 */
public class NullSurveyAnsContent extends SurveyAnsContent 
{

    /**
     * Empty constructor
     */
    public NullSurveyAnsContent()
    {
        super();
    }

    /**
     * This object should be null.
     * @see org.lamsfoundation.lams.tool.survey.Nullable#isNull()
     */
    public boolean isNull()
    {
        return true;
    }

}
