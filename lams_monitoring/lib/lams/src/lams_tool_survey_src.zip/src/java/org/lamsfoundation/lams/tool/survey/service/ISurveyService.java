package org.lamsfoundation.lams.tool.survey.service;

import java.util.List;


import org.lamsfoundation.lams.lesson.Lesson;
import org.lamsfoundation.lams.tool.survey.SurveyContent;
import org.lamsfoundation.lams.tool.survey.SurveySession;
import org.lamsfoundation.lams.usermanagement.User;



/**
 * This interface define the contract that all Survey service provider must
 * follow.
 * 
 * @author Jacky Fang
 */
public interface ISurveyService 
{
   /**
    * Save the user response into database based on a list of response 
    * retrieved from presentation tier. If the responses are already exist
    * in the database, it should update all records and delete the records
    * no longer needs according to the new response list.
    * 
    * @param responses the list of response from web layer
    * @param toolSessionId the runtime instance id that survey tool linked to
    * @param username the current logged on user
    */
    public void saveUserResponses(List responses, long toolSessionId, User user);
    
    /**
     * Returns the survey value object according to the specific run time 
     * task instance. The taskinstanceId must not equal 0 and must exist in
     * the task_instance table.
     * 
     * @param toolSessionId the runtime survey session id.
     * @return the survey value object
     */
    public SurveyContent retrieveSurveyBySession(long toolSessionId);
    
    /**
     * Return the survey object according to the requested content id.
     * @param toolContentId the tool content id
     * @return the survey object
     */
    public SurveyContent retrieveSurvey(long toolContentId);
    
    public void updateSurvey(SurveyContent survey);
    
    /**
     * Returns the survey session according to the tool session id.
     * @param toolSessionId
     * @return the current survey session
     */
    public SurveySession retrieveSurveySession(long toolSessionId);
    
    /**
     * Return the learning session object that current learner is running.
     * This method assume the learning session id is cached in the http session.
     * 
     * @param lsessionId the learning session id cached in the http session.
     * @return the learning session value object
     */
    public Lesson getCurrentLesson(long lessonId);
    
    /**
     * Return the number of total learner who should participate the survey 
     * instance.
     * @param surveyContentId the tool content id for survey..
     * @return the number of total learner for current survey
     */
    public int getSurveyClassSize(Long surveyContentId);
    
    /**
     * Count how many leaner in current class have taken the survey
     * @param survey the current survey
     * @return the number of leaner
     */
    public int countTotalNumberOfUserResponsed(SurveyContent survey);
    
    /**
     * Retrieve the complete user information for display
     * @param username the username of the current logged in user
     * @return UserData that wraps all user information.
     */
    public User getCurrentUserData(String username);

    public void saveSurveyContent(SurveyContent survey);

    public List getQuestionTypes();

}
