package org.lamsfoundation.lams.tool.survey.web;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

import org.lamsfoundation.lams.tool.survey.SurveyApplicationException;
import org.lamsfoundation.lams.tool.survey.SurveyConstants;
import org.lamsfoundation.lams.tool.survey.SurveyQueContent;
import org.lamsfoundation.lams.tool.survey.SurveySession;
import org.lamsfoundation.lams.usermanagement.User;
import org.lamsfoundation.lams.util.WebUtil;


import java.util.Arrays;

/**
 * Struts form bean class. As we are using dyna formbean, all bean attributs 
 * are implemented in the Struts configuration file.
 * 
 * @author Jacky Fang
 *  
 */
public class QuestionnaireForm extends DynaValidatorForm
{

    private static final String PARAM_RESET = "reset";
    private static final String PARAM_VALIDATE = "validate";
    private static final boolean OPTIONAL = true;

    //---------------------------------------------------------------------
    // Inherited Methods
    //---------------------------------------------------------------------

    /**
     * Reset the form to its valid initial status. In our case, we need to
     * reset multibox related property to 0 length. Otherwise, unchecked 
     * check box item won't be submitted with the form. This is known issue 
     * with http form as well as Struts multibox tag.
     * @param mapping the Struts action mapping.
     * @param request the coming http request
     * 
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        if (shouldWeReset(request))
        {
            resetSurveyQuestions();
        }
    }

    /**
     * Clean up all the user responses for all survey questions.
     */
    public void resetSurveyQuestions()
    {
        ArrayList questions = (ArrayList) this.get("surveyQuestions");
        ArrayList newQuestions = new ArrayList();
        for (Iterator i = questions.iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();
            q.setUserResponses(new String[0]);
            q.setOtherResponse("");
            newQuestions.add(q);
        }
        this.set("surveyQuestions", newQuestions);
    }

    /**
     * Perform the validation on Struts form items. Generate proper error 
     * message if necessary.
     * @param mapping the Struts action mapping.
     * @param request the coming http request
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {

        ActionErrors errors = new ActionErrors();

        if (shouldWeValidate(request))
        {
            checkForCompulsoryQuestions("error.question.compulsory",
                                        (ArrayList) super.get("surveyQuestions"),
                                        errors);
            checkForSimpleChoiceQuestion("error.response.invalid",
                                         (ArrayList) super.get("surveyQuestions"),
                                         errors);
        }

        return errors;
    }

    //---------------------------------------------------------------------
    // Validation Methods
    //---------------------------------------------------------------------
    /**
     * Check the form data to see whether all compulsory fields are filled.
     * If not, an action error will be created to notify users.
     * 
     * @param fieldKey the error key defined in the properties file
     * @param questions a list of questions need to be validated
     * @param errors the errors will be thrown to the page
     */
    private void checkForCompulsoryQuestions(String fieldKey,
                                             ArrayList questions,
                                             ActionErrors errors)
    {
        //create dynamic error message that will be displayed on the page
        StringBuffer errorMsg = new StringBuffer();
        for (Iterator i = questions.iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();
            if (isEmptyResForCompulsoryQues(q))
            {
                errorMsg.append("Question [" + q.getDisplayOrder() + "] ");
            }
        }
        //creat error
        if (errorMsg.length() != 0)
        {
            ActionError error = new ActionError("error.question.compulsory",
                                                errorMsg);
            errors.add(fieldKey, error);
        }
    }

    /**
     * Check for the simple choice question. It is not allowed to provide 
     * more than one reponse for a simple choice question
     * 
     * @param fieldKey the error key defined in the properties file
     * @param questions a list of questions need to be validated
     * @param errors the errors will be thrown to the page
     */
    private void checkForSimpleChoiceQuestion(String fieldKey,
                                              ArrayList questions,
                                              ActionErrors errors)
    {
        for (Iterator i = questions.iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();
            if (q.getSurveyQueType()
                 .getName()
                 .equals(SurveyConstants.SIMPLE_CHOICE)
                    && isMultipleRespForSimpleChoice(q))
            {
                ActionError error = new ActionError("error.response.invalid",
                                                    "Question ["
                                                            + q.getDisplayOrder()
                                                            + "] ");
                errors.add(fieldKey, error);
            }
        }

    }

    //---------------------------------------------------------------------
    // Form bean data transformation Methods
    //---------------------------------------------------------------------
    /**
     * <p>
     * Build the questionnaire from using the survey value object. Use
     * <code>BeanUtils.copyProperties(dest, original)</code> to copy the form
     * data around.
     * </p>
     * <p>
     * To achieve the deep copy between value object and form bean, we have to
     * manually convert the questions set into questions arraylist. You might be
     * wondering why not make these two attributes type consist. Here are the
     * reasons:
     * </p>
     * <ul>
     * <li>1. We want to use Set in hibernate value object because Hibernate
     * doesn't support the lazy loading of list type collection.</li>
     * <li>2. We want to use list in the form bean because the index feature of
     * list gives us powerful ways of manipulating bean presentations on the JSP.
     * </li>
     * </ul>
     * 
     * 
     * @param username the current survey user.
     * @param survey the survey value object.
     */
    public void buildQuestionnaireForm(String username, SurveySession session)
    {
        //validate passed in parameters before us move on
        if (session == null || session.getSurveyContent().getSurveyQueContents() == null)
            throw new SurveyApplicationException("The requested survey is not available"
                    + " in the database.");
        try
        {

            BeanUtils.copyProperties(this, session.getSurveyContent());
            //setup questions
            session.getSurveyContent().setUpStrutsQuestionResponse(username);
            ArrayList surveyQuestions = new ArrayList(Arrays.asList(session.getSurveyContent().getSurveyQueContents()
                                                                          .toArray()));
            this.set("surveyQuestions", surveyQuestions);
            this.set("surveySession",session);

        }
        catch (IllegalAccessException e)
        {
            throw new SurveyApplicationException("IllegalAccessException occured when "
                                                         + "the survey is building questionnaire form",
                                                 e);
        }
        catch (InvocationTargetException e)
        {
            throw new SurveyApplicationException("InvocationTargetException occured when "
                                                         + "the survey is building questionnaire form",
                                                 e);
        }
        this.set("startDate", (new Date(System.currentTimeMillis())).toString());
    }

    /**
     * Build the list of response according to domain model SurUserResponseVO.
     * 
     * @param request A standard Servlet HttpServletRequest class.
     * @throws SystemException the exception to indicate known error states of 
     * 						   Lams.
     */
    public List buildUserResponses(HttpServletRequest request, User user)
    {
        //validate the pre-condition of this method
        ArrayList questions = (ArrayList) this.get("surveyQuestions");
        SurveySession session = (SurveySession)this.get("surveySession");
        //TODO need to be removed when validation are implemented
        if (!isQuestionReady(questions))
            throw new SurveyApplicationException("Fail to get responses from users;");
        //setup response value object
        ArrayList responses = new ArrayList();

        for (Iterator i = questions.iterator(); i.hasNext();)
        {
            SurveyQueContent q = (SurveyQueContent) i.next();
            responses.addAll(q.getUserResponsesAsList(user,session));
        }

        return responses;

    }

    //---------------------------------------------------------------------
    // Helper Methods
    //---------------------------------------------------------------------

    /**
     * Validate whether the compulsory question is empty.
     * @param q the question needs to be validated
     * @return whether there is a response for compulsory question.
     */
    private boolean isEmptyResForCompulsoryQues(SurveyQueContent q)
    {
        if (q.getIsOptional())
        {
            if (q.getOtherResponse() == null
                    && q.getUserResponses().length == 0)
                return true;
            else if (q.getUserResponses().length == 0
                    && q.getOtherResponse().trim().equals(""))
                return true;
        }
        return false;
    }

    /**
     * Validate whether the simple choice question has more than one answer
     * @param q the question needs to be validated
     * @return return true if more than one response found.
     */
    private boolean isMultipleRespForSimpleChoice(SurveyQueContent question)
    {
        //We don't do the null check because userResponses is initialized 
        //as empty String array. 
        if (question.getUserResponses().length > 2)
            return true;
        if (question.getUserResponses().length > 0
                && question.isOtherResponseAvailable())
            return true;
        return false;
    }

    /**
     * Validate the question list we got. Return false if it doesn't meet our
     * pre-condition for processing.
     * @param questions the list of questions to be validated.
     * @return whether the question pre-condition is met.
     */
    private boolean isQuestionReady(ArrayList questions)
    {
        if (questions == null || questions.size() == 0)
            return false;
        return true;
    }

    /**
     * <p>Check out whether the current tool session has been runned before.</p>
     * 
     * <p>Pre-condition:Session status is availabe in the http session. It
     * 	 				should be created by tool session initialization
     * 				    method</p>
     * 
     * @param request a standard Servlet HttpServletRequest class.
     * @return whether we are in resume mode or not.
     */
    private boolean isIncompleteToolSession(HttpServletRequest request)
    {
        String sessionStatus = (String)request.getSession().getAttribute(WebUtil.ATTR_SESSION_STATUS); 
        //TODO need to be removed when progress engine is done.
        if(sessionStatus==null)
            sessionStatus = (String)WebUtil.readStrParam(request,WebUtil.PARAM_SESSION_STATUS);
        
        if(sessionStatus == null)
            throw new SurveyApplicationException("Null Survey Session Status ");
        
        if (sessionStatus.equals(SurveySession.INCOMPLETE))
            return true;

        return false;
    }

    /**
     * Check out the mode and reset parameter to decide whether we should
     * reset our form.
     * @param request
     * @return the decision of resetting form
     */
    private boolean shouldWeReset(HttpServletRequest request)
    {
        //"reset" is passed as parameter by "completeSession" method 
        //on the summaryContent.jsp
        String reset = WebUtil.readStrParam(request, PARAM_RESET, OPTIONAL);

        //we don't reset if survey session status is Incomplete.
        if (isIncompleteToolSession(request))
            return false;
        //reset it if new reset mode has been identified or it is set to true
        if (reset == null || reset.equals("true"))
            return true;

        return false;
    }

    /**
     * Check out request parameter to decide whether we should validate or not.
     * @param request
     * @return whether we should validate or not
     */
    private boolean shouldWeValidate(HttpServletRequest request)
    {
        String validate = WebUtil.readStrParam(request,
                                               PARAM_VALIDATE,
                                               OPTIONAL);
        //we don't validate the form if the user is resuming the survey
        if (validate != null && validate.equals("true"))
            return true;
        return false;
    }
}
