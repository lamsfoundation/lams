/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2004 
 * Created on 2004-12-2
 ******************************************************************************** */
package org.lamsfoundation.lams.tool.survey;


/**
 * <p>This exception wraps all basic exception occured in the survey tool. It is 
 * not suppose to be try and catched in any level. The struts should be taking
 * care of handling this exception.</p>
 * 
 * @author Jacky Fang 2004-12-2
 * 
 */
public class SurveyApplicationException extends RuntimeException
{

    /**
     * Default Constructor
     */
    public SurveyApplicationException()
    {
        super();
    }

    /**
     * Constructor for customized error message
     * @param message
     */
    public SurveyApplicationException(String message)
    {
        super(message);
    }

    /**
     * Constructor for wrapping the throwable object
     * @param cause
     */
    public SurveyApplicationException(Throwable cause)
    {
        super(cause);
    }

    /**
     * Constructor for wrapping both the customized error message and 
     * throwable exception object.
     * @param message
     * @param cause
     */
    public SurveyApplicationException(String message, Throwable cause)
    {
        super(message, cause);
    }

}
