package org.lamsfoundation.lams.tool.survey;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/** 
 * @hibernate.class table="tool_lasr10_survey_que_type" mutable="false"
 *     
 */
public class SurveyQueType implements Serializable,Comparable {

    /** identifier field */
    private Long questionTypeId;

    /** identifier field */
    private String name;
    
    /** nullable persistent field */
    private String description;

    //---------------------------------------------------------------------
    // Class level constants
    //---------------------------------------------------------------------
    public static final String SIMPLE_CHOICE="simpleChoice";
    public static final String CHOICE_MULTIPLE="choiceMultiple";
    public static final String TEXT_ENTRY="textEntry";
    public static final String COMPOSITE_CHOICE="compositeChoice";
    

    /** full constructor */
    public SurveyQueType(Long questionTypeId, String description) {
        this.questionTypeId = questionTypeId;
        this.description = description;
    }

    /** default constructor */
    public SurveyQueType() {
    }

    /** minimal constructor */
    public SurveyQueType(Long questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    /** 
     * @hibernate.id  generator-class="assigned" type="java.lang.Long"
     *                column="question_type_id"
     *         
     */
    public Long getQuestionTypeId() {
        return this.questionTypeId;
    }

    public void setQuestionTypeId(Long questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    /**
     * @hibernate.property column="name" length="128"
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /** 
     * @hibernate.property column="description" length="65535"
     *         
     */
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String toString() {
        return new ToStringBuilder(this).append("questionTypeId", getQuestionTypeId())
                                        .append("description",getDescription())
                                        .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof SurveyQueType) ) return false;
        SurveyQueType castOther = (SurveyQueType) other;
        return new EqualsBuilder()
            .append(this.getQuestionTypeId(), castOther.getQuestionTypeId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getQuestionTypeId())
            .toHashCode();
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o)
    {
        SurveyQueType type = (SurveyQueType)o;
        return questionTypeId.intValue()-type.questionTypeId.intValue();
    }


}
