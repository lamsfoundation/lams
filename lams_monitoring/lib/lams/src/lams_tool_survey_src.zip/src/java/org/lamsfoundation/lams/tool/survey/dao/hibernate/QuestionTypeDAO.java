/* ********************************************************************************
 *  Copyright Notice
 *  =================
 * This file contains propriety information of LAMS Foundation. 
 * Copying or reproduction with prior written permission is prohibited.
 * Copyright (c) 2005 
 * Created on 20/01/2005
 ******************************************************************************** */

package org.lamsfoundation.lams.tool.survey.dao.hibernate;

import java.util.List;

import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import org.lamsfoundation.lams.tool.survey.SurveyQueType;
import org.lamsfoundation.lams.tool.survey.dao.IQuestionTypeDAO;


/**
 * 
 * @author Jacky Fang 20/01/2005
 * 
 */
public class QuestionTypeDAO extends HibernateDaoSupport implements IQuestionTypeDAO
{

    /**
     * 
     */
    public QuestionTypeDAO()
    {
        super();
    }

    /**
     * @see org.lamsfoundation.lams.tool.survey.dao.IQuestionTypeDAO#getAllQuestionTypes()
     */
    public List getAllQuestionTypes()
    {
        return this.getHibernateTemplate().loadAll(SurveyQueType.class);
    }

}
