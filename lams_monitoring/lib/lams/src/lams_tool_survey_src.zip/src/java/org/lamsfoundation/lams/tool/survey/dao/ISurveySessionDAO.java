
package org.lamsfoundation.lams.tool.survey.dao;

import org.lamsfoundation.lams.tool.survey.SurveySession;


/**
 * 
 * @author Jacky Fang
 */
public interface ISurveySessionDAO
{

    public SurveySession getSurveySessionById(Long surveySessionId);
    
    public void CreateSurveySession(SurveySession session);
    
    public void UpdateSurveySession(SurveySession session);
    
    public void deleteSurveySession(SurveySession session);
}
