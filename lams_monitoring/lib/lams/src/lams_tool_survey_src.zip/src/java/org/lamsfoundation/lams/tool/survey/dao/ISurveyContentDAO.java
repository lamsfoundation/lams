package org.lamsfoundation.lams.tool.survey.dao;

import org.lamsfoundation.lams.tool.survey.SurveyContent;


/**
 * 
 * @author Jacky Fang
 *
 */
public interface ISurveyContentDAO
{
    public SurveyContent getSurveyById(Long surveyId);
    
    public SurveyContent getSurveyBySession(Long sessionId);

    public void SaveSurvey(SurveyContent survey);
    
    public void UpdateSurvey(SurveyContent survey);

    public void removeSurvey(Long surveyContentId);
    
    public void removeAllSurveySession(SurveyContent content);
    /**
     * @param survey
     * @return
     */
    public int countUserResponsed(SurveyContent survey);
}
