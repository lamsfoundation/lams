/****************************************************************
 * Copyright (C) 2005 LAMS Foundation (http://lamsfoundation.org)
 * =============================================================
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 * 
 * http://www.gnu.org/licenses/gpl.txt
 * ****************************************************************
 */
package org.lamsfoundation.lams.authoring.service;

import java.io.IOException;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.lamsfoundation.lams.authoring.LDWDDXValueObjectFactory;
import org.lamsfoundation.lams.authoring.LDWDDXValueObjectStorer;
import org.lamsfoundation.lams.authoring.util.WDDXTAGS;
import org.lamsfoundation.lams.learningdesign.dao.hibernate.ActivityDAO;
import org.lamsfoundation.lams.learningdesign.dao.hibernate.GroupingDAO;
import org.lamsfoundation.lams.learningdesign.dao.hibernate.LearningDesignDAO;
import org.lamsfoundation.lams.learningdesign.dao.hibernate.LearningLibraryDAO;
import org.lamsfoundation.lams.learningdesign.dao.hibernate.LicenseDAO;
import org.lamsfoundation.lams.learningdesign.dao.hibernate.TransitionDAO;
import org.lamsfoundation.lams.learningdesign.Activity;
import org.lamsfoundation.lams.learningdesign.ChosenGrouping;
import org.lamsfoundation.lams.learningdesign.ComplexActivity;
import org.lamsfoundation.lams.learningdesign.GateActivity;
import org.lamsfoundation.lams.learningdesign.Grouping;
import org.lamsfoundation.lams.learningdesign.GroupingActivity;
import org.lamsfoundation.lams.learningdesign.LearningDesign;
import org.lamsfoundation.lams.learningdesign.LearningLibrary;
import org.lamsfoundation.lams.learningdesign.OptionsActivity;
import org.lamsfoundation.lams.learningdesign.ParallelActivity;
import org.lamsfoundation.lams.learningdesign.PermissionGateActivity;
import org.lamsfoundation.lams.learningdesign.RandomGrouping;
import org.lamsfoundation.lams.learningdesign.ScheduleGateActivity;
import org.lamsfoundation.lams.learningdesign.SequenceActivity;
import org.lamsfoundation.lams.learningdesign.SynchGateActivity;
import org.lamsfoundation.lams.learningdesign.ToolActivity;
import org.lamsfoundation.lams.learningdesign.Transition;
import org.lamsfoundation.lams.authoring.service.IAuthoringService;
import org.lamsfoundation.lams.tool.dao.hibernate.ToolDAO;
import org.lamsfoundation.lams.usermanagement.User;
import org.lamsfoundation.lams.usermanagement.WorkspaceFolder;
import org.lamsfoundation.lams.usermanagement.dao.hibernate.UserDAO;
import org.lamsfoundation.lams.usermanagement.dao.hibernate.WorkspaceFolderDAO;
import org.lamsfoundation.lams.authoring.util.FlashMessage;
import org.lamsfoundation.lams.authoring.util.WDDXProcessor;

/**
 * @author Manpreet Minhas 
 */
public class AuthoringService implements IAuthoringService {
	
	/** Required DAO's */
	protected LearningDesignDAO learningDesignDAO;
	protected LearningLibraryDAO learningLibraryDAO;
	protected ActivityDAO activityDAO;
	protected UserDAO userDAO;
	protected WorkspaceFolderDAO workspaceFolderDAO;
	protected TransitionDAO transitionDAO;
	protected ToolDAO toolDAO;
	protected LicenseDAO licenseDAO;
	protected GroupingDAO groupingDAO;
	
	public void setGroupingDAO(GroupingDAO groupingDAO) {
		this.groupingDAO = groupingDAO;
	}
	/** for sending acknowledgment/error messages back to flash */
	private FlashMessage flashMessage;
	
	/**
	 * @param transitionDAO The transitionDAO  to set
	 */
	public void setTransitionDAO(TransitionDAO transitionDAO) {
		this.transitionDAO = transitionDAO;
	}
	/**
	 * @param learningDesignDAO The learningDesignDAO to set.
	 */
	public void setLearningDesignDAO(LearningDesignDAO learningDesignDAO) {
		this.learningDesignDAO = learningDesignDAO;
	}	
	/**
	 * @param learningLibraryDAO The learningLibraryDAO to set.
	 */
	public void setLearningLibraryDAO(LearningLibraryDAO learningLibraryDAO) {
		this.learningLibraryDAO = learningLibraryDAO;
	}
	/**
	 * @param userDAO The userDAO to set.
	 */
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	/**
	 * @param activityDAO The activityDAO to set.
	 */
	public void setActivityDAO(ActivityDAO activityDAO) {
		this.activityDAO = activityDAO;
	}	
	/**
	 * @param workspaceFolderDAO The workspaceFolderDAO to set.
	 */
	public void setWorkspaceFolderDAO(WorkspaceFolderDAO workspaceFolderDAO) {
		this.workspaceFolderDAO = workspaceFolderDAO;
	}
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#getLearningDesign(java.lang.Long)
	 */
	public LearningDesign getLearningDesign(Long learningDesignID){
		return learningDesignDAO.getLearningDesignById(learningDesignID);
	}
	
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#saveLearningDesign(org.lamsfoundation.lams.learningdesign.LearningDesign)
	 */
	public void saveLearningDesign(LearningDesign learningDesign){
		learningDesignDAO.insert(learningDesign);
	}
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#getAllLearningDesigns()
	 */
	public List getAllLearningDesigns(){
		return learningDesignDAO.getAllLearningDesigns();		
	}
	
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#updateLearningDesign(org.lamsfoundation.lams.learningdesign.LearningDesign)
	 */
	public void updateLearningDesign(LearningDesign learningDesign) {		
		learningDesignDAO.update(learningDesign);
	}
	
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#getAllLearningLibraries()
	 */
	public List getAllLearningLibraries(){
		return learningLibraryDAO.getAllLearningLibraries();		
	}
	
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#requestLearningLibraryListWDDX()
	 */
	public String requestLearningLibraryListWDDX()throws IOException{
		String wddxPacket = null;
		LearningLibrary library = null;
		List libraries = getAllLearningLibraries();
		Hashtable result = null;
		result = new LDWDDXValueObjectFactory(activityDAO,toolDAO).requestLearningLibraryList(libraries);
		flashMessage = new FlashMessage("requestLearningLibraryListWDDX",result);
		try{			
			wddxPacket = WDDXProcessor.serialize(flashMessage);
		}catch(IOException e){
			throw new IOException("An exception occured while serializing" + e.getMessage());
		}		
		return wddxPacket;
	}
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#requestLearningLibraryWDDX(java.lang.Long)
	 */
	public String requestLearningLibraryWDDX(Long learningLibraryID){
		return null;
	}
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#requestLearningDesignListWDDX()
	 */
	public String requestLearningDesignListWDDX() throws IOException{
		String wddxPacket = null;
		List designs = learningDesignDAO.getAllLearningDesigns();		
		Hashtable result = null;
		result = LDWDDXValueObjectFactory.getInstance().requestLearningDesignList(designs);
		flashMessage = new FlashMessage("requestLearningDesignListWDDX",result);
		try{
			wddxPacket = WDDXProcessor.serialize(flashMessage);
		}catch(IOException e){
			throw new IOException("An exception occured while serializing" + e.getMessage());
		}		
		return wddxPacket;		
	}
	
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#requestLearningDesignWDDX(java.lang.Long)
	 */
	public String requestLearningDesignWDDX(Long learningDesignID)throws IOException{
		String wddxPacket = null;
		LearningDesign design = learningDesignDAO.getLearningDesignById(learningDesignID);
		Hashtable result = null;		
		LDWDDXValueObjectFactory factory = new LDWDDXValueObjectFactory(activityDAO,toolDAO);
		if(design==null)
			flashMessage = new FlashMessage("requestLearningDesignWDDX",
											"No such learning design exists with a learning_design_id of " +learningDesignID + " exists",
											FlashMessage.ERROR);
		else{
			result = factory.buildLearningDesignObject(design);
			flashMessage = new FlashMessage("requestLearningDesignWDDX",result);
		}
		try{
				wddxPacket = WDDXProcessor.serialize(flashMessage);				
		}catch(IOException ie){
			throw new IOException("An exception occured while serializing" + ie.getMessage());	
		}
		return wddxPacket;
	}
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#requestLearningDesignWDDX(org.lamsfoundation.lams.usermanagement.User)
	 */
	public String requestLearningDesignWDDX(User user)throws IOException{
		Long userID = new Long(user.getUserId().longValue());		
		List designs = learningDesignDAO.getLearningDesignByUserId(userID);
		String wddxPacket = null;
		Hashtable result = null;
		if(designs!=null){
			result = LDWDDXValueObjectFactory.getInstance().requestLearningDesignList(designs);
			flashMessage = new FlashMessage("requestLearningDesignWDDX",result);
		}else{
			flashMessage = new FlashMessage("requestLearningDesignWDDX","No designs exist for given user",FlashMessage.ERROR);
		}
		try{
			wddxPacket = WDDXProcessor.serialize(flashMessage);
		}catch(IOException e){
			throw new IOException("An exception occured while serializing " + e.getMessage());
		}
		return wddxPacket;
	}
	
	/**
	 * @param wddxPacket The WDDX Packet received from the flash side to be stored/updated
	 * 					 in the database
	 * @return String An acknowledgement message in WDDX format
	 */
	public String storeWDDXData(String wddxPacket)throws Exception{
		Hashtable wddxData = null;		
		Long learningDesignID = null;
		String resultWddx=null;
		LDWDDXValueObjectStorer storer = null;
		
		if(containsNulls(wddxPacket))
		{
			flashMessage = new FlashMessage("storeWDDXData",
											"Unable to store the WDDX packet as it contains null",
											FlashMessage.ERROR);
			try{
				resultWddx = WDDXProcessor.serialize(flashMessage);
			}catch(IOException ie){
				throw new IOException("An exception occured while serializing" + ie.getMessage());
			}
			return resultWddx;
		}
		
		try{
			wddxData =(Hashtable)WDDXProcessor.deserialize(wddxPacket);			
		}catch(Exception e){
			throw new Exception("Unable to deserialize WDDX packet " + e.getMessage());
		}
		
		if(wddxData==null){
			flashMessage = new FlashMessage("storeWDDXData",
											"The WDDX packet returned is NULL",
											FlashMessage.ERROR);
		}
		else{
			String objectType =(String)wddxData.get(WDDXTAGS.OBJECT_TYPE);
			if(objectType.equals(LearningDesign.DESIGN_OBJECT)){
				try{
					storer = new LDWDDXValueObjectStorer(learningDesignDAO,learningLibraryDAO,userDAO,activityDAO,workspaceFolderDAO,licenseDAO,groupingDAO);
					learningDesignID = storer.processLearningDesign(wddxData);
					flashMessage = new FlashMessage("storeWDDXData",
													(learningDesignID!=null?learningDesignID.toString():""));					
				}catch(Exception e){
					flashMessage = new FlashMessage("storeWDDXData",e.getMessage(),FlashMessage.ERROR);
					throw new Exception("Exception occured while serializing " + e.getMessage());
				}				
			}
		}
		
		try{
			resultWddx = WDDXProcessor.serialize(flashMessage);
		}catch(IOException ie){
			throw new IOException("An exception occured while serializing " + ie.getMessage());
		}
		return resultWddx;
	}		
	/**
	 * Checks whether the WDDX packet contains any invalid
	 * "<null/>". It returns true if there exists any such null
	 */
	private boolean containsNulls(String packet)
	{
		if (packet.indexOf("<null />") != -1)
			return true;
		else
			return false;
	}
	
	
	/**
	 * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#copyLearningDesign(org.lamsfoundation.lams.learningdesign.LearningDesign, java.lang.Integer, org.lamsfoundation.lams.usermanagement.User)
	 */
	public LearningDesign copyLearningDesign(LearningDesign originalLearningDesign,Integer copyType,User user){
		return copyLearningDesign(originalLearningDesign,copyType,user, originalLearningDesign.getWorkspaceFolder());
	}
	
    /**
     * @see org.lamsfoundation.lams.authoring.service.IAuthoringService#copyLearningDesign(org.lamsfoundation.lams.learningdesign.LearningDesign, java.lang.Integer, org.lamsfoundation.lams.usermanagement.User, org.lamsfoundation.lams.usermanagement.WorkspaceFolder)
     */
    public LearningDesign copyLearningDesign(LearningDesign originalLearningDesign,Integer copyType,User user, WorkspaceFolder workspaceFolder)
    {
    	LearningDesign newLearningDesign  = LearningDesign.createLearningDesignCopy(originalLearningDesign,copyType);
    	newLearningDesign.setUser(user);    	
    	newLearningDesign.setWorkspaceFolder(workspaceFolder);    	
    	learningDesignDAO.insert(newLearningDesign);
    	updateDesignActivities(originalLearningDesign,newLearningDesign); 
    	calculateFirstActivity(originalLearningDesign,newLearningDesign);
    	updateDesignTransitions(originalLearningDesign,newLearningDesign);
        return newLearningDesign;
    }
    /**
     * Calculates the First activity of the LearningDesign.
     * <p> 
     * The <em>activity_ui_id</em> is unique per LearningDesign. So when a LearningDesign is deep-copied
     * all the activities in the newDesign would have the same <em>activity_ui_id</em> as the oldDesign.  
     * This mean that the firstActivity of the newDesign would have the same <em>activity_ui_id</em>
     * as the oldDesign.So in order to determine the firstActivity of the newDesign we look for an 
     * activity which has an <em>activity_ui_id</em> same as that of the oldDesign and 
     * <em>learning_design_id</em> as the newDesign
     * </p>
     *   
     * @param oldDesign The LearningDesign to be copied
     * @param newDesign The copy of the originalLearningDesign
     */
    private void calculateFirstActivity(LearningDesign oldDesign,LearningDesign newDesign){
    	Integer oldUIID  = oldDesign.getFirstActivity().getActivityUIID();
    	Activity firstActivity = activityDAO.getActivityByUIID(oldUIID,newDesign);
    	newDesign.setFirstActivity(firstActivity);
    	Integer learning_design_ui_id = new Integer(newDesign.getLearningDesignId().intValue());
    	newDesign.setLearningDesignUIID(learning_design_ui_id);
    }
    
    /**
     * Updates the Activity information in the newLearningDesign based 
     * on the originalLearningDesign
     * 
     * @param originalLearningDesign The LearningDesign to be copied
     * @param newLearningDesign The copy of the originalLearningDesign
     */
    private void updateDesignActivities(LearningDesign originalLearningDesign, LearningDesign newLearningDesign){
    	HashSet oldParentActivities = originalLearningDesign.getParentActivities();
    	Iterator iterator = oldParentActivities.iterator();    	
    	while(iterator.hasNext()){
    		Object parentActivity = iterator.next();
    		Activity newParentActivity = getActivityCopy(parentActivity);
    		newParentActivity.setLearningDesign(newLearningDesign);
    		activityDAO.insert(newParentActivity);
    		
    		HashSet oldChildActivities = getChildActivities((Activity)parentActivity);
    		Iterator childIterator = oldChildActivities.iterator();
    		
    		while(childIterator.hasNext()){
    			Activity childActivity = (Activity)childIterator.next();
    			Activity newChildActivity = getActivityCopy(childActivity);
    			newChildActivity.setParentActivity(newParentActivity);
    			newChildActivity.setParentUIID(newParentActivity.getActivityUIID());
    			newChildActivity.setLearningDesign(newLearningDesign);
    			activityDAO.insert(newChildActivity);
    		}
    	}     
    }
    
    /**
     * Updates the Transition information in the newLearningDesign based 
     * on the originalLearningDesign
     * 
     * @param originalLearningDesign The LearningDesign to be copied 
     * @param newLearningDesign The copy of the originalLearningDesign
     */
    public void updateDesignTransitions(LearningDesign originalLearningDesign, LearningDesign newLearningDesign){
    	Set oldTransitions = originalLearningDesign.getTransitions();
    	Iterator iterator = oldTransitions.iterator();
    	while(iterator.hasNext()){
    		Transition transition = (Transition)iterator.next();
    		Transition newTransition = Transition.createCopy(transition);    		
    		Activity toActivity = null;
        	Activity fromActivity=null;
    		if(newTransition.getToUIID()!=null)
    			toActivity = activityDAO.getActivityByUIID(newTransition.getToUIID(),newLearningDesign);
    		if(newTransition.getFromUIID()!=null)
    			fromActivity = activityDAO.getActivityByUIID(newTransition.getFromUIID(),newLearningDesign);
    		newTransition.setToActivity(toActivity);
    		newTransition.setFromActivity(fromActivity);
    		newTransition.setLearningDesign(newLearningDesign);
    		transitionDAO.insert(newTransition);    		
    	}
    }
    /**
     * Determines the type of activity and returns a deep-copy of the same
     * 
     * @param activity The object to be deep-copied
     * @return Activity The new deep-copied Activity object
     */
    private Activity getActivityCopy(Object activity){
    	if(activity instanceof GroupingActivity){    		
    		GroupingActivity newGroupingActivity = GroupingActivity.createCopy((GroupingActivity)activity);
    		createGroupingForGroupingActivity(newGroupingActivity,(GroupingActivity)activity);
    		return newGroupingActivity;
    	}
    	else if(activity instanceof ComplexActivity)
    		return createComplexActivityCopy(activity);
    	else if(activity instanceof GateActivity)
    		return createGateActivityCopy(activity);
    	else 
    		return ToolActivity.createCopy((ToolActivity)activity);    	
    } 
    /**
     * This function creates a new Grouping for the new GroupingActivity
     * based on the grouping type of the old GroupingActivity from
     * which it has been deep-copied.
     * 
     * @param groupingActivity The new GroupingActivity
     * @param oldActivity The old GroupingActivity
     */
    private void createGroupingForGroupingActivity(GroupingActivity groupingActivity, GroupingActivity oldActivity){
    	Grouping grouping = oldActivity.getCreateGrouping();
    	
    	if(grouping.getGroupingTypeId()==Grouping.CHOSEN_GROUPING_TYPE){
    		ChosenGrouping chosenGrouping = ChosenGrouping.createCopy((ChosenGrouping)grouping);    		
    		groupingDAO.insert(chosenGrouping);
    		groupingActivity.setCreateGrouping(chosenGrouping);
    	}
    	else{
    		RandomGrouping randomGrouping = RandomGrouping.createCopy((RandomGrouping)grouping);
    		groupingDAO.insert(randomGrouping);
    		groupingActivity.setCreateGrouping(randomGrouping);
    	}    	
    }
    /**
     * This function creates a deep copy of ComplexActivity object
     * 
     * @param activity The object to be deep copied
     * @return Activity The deep-copied object
     */
    private Activity createComplexActivityCopy(Object activity){    	    	
    	if(activity instanceof OptionsActivity)
    		return OptionsActivity.createCopy((OptionsActivity)activity);
    	else if (activity instanceof ParallelActivity)
    		return ParallelActivity.createCopy((ParallelActivity)activity);
    	else
    		return SequenceActivity.createCopy((SequenceActivity)activity);
    	
    }
    /**
     * This function creates a deep copy of the GateActivity object
     *  
     * @param activity The object to be deep copied
     * @return Activity The deep-copied object
     */
    private Activity createGateActivityCopy(Object activity){
    	if(activity instanceof ScheduleGateActivity)
    		return ScheduleGateActivity.createCopy((ScheduleGateActivity)activity);
    	else if (activity instanceof PermissionGateActivity)
    		return PermissionGateActivity.createCopy((PermissionGateActivity)activity);
    	else
    		return SynchGateActivity.createCopy((SynchGateActivity)activity);
    }
    /**
     * Returns a set of child activities for the given parent activitity
     * 
     * @param parentActivity The parent activity 
     * @return HashSet Set of the activities that belong to the parentActivity 
     */
    private HashSet getChildActivities(Activity parentActivity){
    	HashSet childActivities = new HashSet();
    	List list = activityDAO.getActivitiesByParentActivityId(parentActivity.getActivityId());
    	if(list!=null)
    		childActivities.addAll(list);
    	return childActivities;
    }
	/**
	 * @param toolDAO The toolDAO to set 
	 */
	public void setToolDAO(ToolDAO toolDAO) {
		this.toolDAO = toolDAO;
	}
	/**
	 * @param licenseDAO The licenseDAO to set
	 */
	public void setLicenseDAO(LicenseDAO licenseDAO) {
		this.licenseDAO = licenseDAO;
	}
}
