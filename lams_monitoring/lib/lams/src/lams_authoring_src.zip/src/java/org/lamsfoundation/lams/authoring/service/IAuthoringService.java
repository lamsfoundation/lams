/***************************************************************************
 * Copyright (C) 2005 LAMS Foundation (http://lamsfoundation.org)
 * =============================================================
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 * 
 * http://www.gnu.org/licenses/gpl.txt
 * ************************************************************************
 */
package org.lamsfoundation.lams.authoring.service;

import java.io.IOException;
import java.util.List;
import org.lamsfoundation.lams.learningdesign.LearningDesign;
import org.lamsfoundation.lams.usermanagement.User;
import org.lamsfoundation.lams.usermanagement.WorkspaceFolder;

/**
 * @author Manpreet Minhas 
 */
public interface IAuthoringService {
	
	
	/**
	 * Returns a populated LearningDesign object corresponding to the given learningDesignID
	 * 
	 * @param learningDesignID The learning_design_id of the design which has to be fetched
	 * @return LearningDesign The populated LearningDesign object corresponding to the given learningDesignID
	 */
	public LearningDesign getLearningDesign(Long learningDesignID);
	
	
	/**
	 * Create a copy of learning design as per the requested learning design 
	 * and saves it in the default workspacefolder.
	 * 
	 * @param originalLearningDesign The source learning design id.
	 * @param copyType purpose of copying the design. Can have one of the follwing values
	 * <ul>
	 * <li>LearningDesign.COPY_TYPE_NONE (for authoring enviornment)</li>
	 * <li>LearningDesign.COPY_TYPE_LESSON (for monitoring enviornment while creating a Lesson)</li>
	 * <li>LearningDesign.COPY_TYPE_PREVIEW (for previewing purposes)</li>
	 * </ul>
	 * @param user The user who has sent this request(author/teacher)
	 * @return LearningDesign The new copy of learning design.
	 */
	public LearningDesign copyLearningDesign(LearningDesign originalLearningDesign,Integer copyType,User user);
	
	/**
	 * Create a copy of learning design as per the requested learning design
	 * and saves it in the given workspacefoler
	 * 
	 * @param originalLearningDesingID the source learning design id.
	 * @param copyType purpose of copying the design. Can have one of the follwing values
	 * <ul>
	 * <li>LearningDesign.COPY_TYPE_NONE (for authoring enviornment)</li>
	 * <li>LearningDesign.COPY_TYPE_LESSON (for monitoring enviornment while creating a Lesson)</li>
	 * <li>LearningDesign.COPY_TYPE_PREVIEW (for previewing purposes)</li>
	 * </ul>
	 * @param user The user who has sent this request(author/teacher)
	 * @param workspaceFolder The workspacefolder where this copy of the design would be saved
	 * @return LearningDesign The new copy of learning design. 
	 */
	public LearningDesign copyLearningDesign(LearningDesign originalLearningDesign,Integer copyType,User user, WorkspaceFolder workspaceFolder);
	/**
	 * @return List Returns the list of all the available LearningDesign's   
	 * */
	public List getAllLearningDesigns();
	/**
	 * Saves the LearningDesign to the database
	 * @param learningDesign The LearningDesign to be saved 
	 * */
	public void saveLearningDesign(LearningDesign learningDesign);
	/**
	 * Updates and existing LearningDesign in the database
	 * @param learningDesign The learningDesign to be updated 
	 **/
	public void updateLearningDesign(LearningDesign learningDesign);
	 
	/**
	 * @return List Returns a list of all available Learning Libraries
	 */
	public List getAllLearningLibraries();
	
	/**
	 * Returns a string representing the requested LearningLibrary in WDDX format
	 * @param learningLibraryID he learning_library_id of the library whose WDDX packet is requested
	 * @return String Returns a string representation of the LearningLibrary in WDDX format
	 */
	public String requestLearningLibraryWDDX(Long learningLibraryID);
	
	/**
	 * Returns a string representing the list of all available Learning Libraries in WDDX format
	 * 
	 * @return String The requested list of all available Learning Libraries in WDDX format
	 * @throws Exception
	 */
	public String requestLearningLibraryListWDDX() throws IOException;
	
	/**
	 * Returns a string representing the requested LearningDesign in WDDX format
	 * 
	 * @param learningDesignID The learning_design_id of the design whose WDDX packet is requested 
	 * @return String The requested LearningDesign in WDDX format
	 * @throws Exception
	 */
	public String requestLearningDesignWDDX(Long learningDesignID)throws IOException;
	
	/**
	 * Returns a string representing the list of all available LearningDesign's in WDDX format
	 * 
	 * @return String The requested list of all available LearningDesign's in WDDX format
	 * @throws Exception
	 */
	public String requestLearningDesignListWDDX()throws IOException;
	
	/**
	 * Returns a string representing the list of LearningDesign's 
	 * in WDDX format, for which the User has write/modify access
	 *  
	 * @param user The User for whom the designs are to be fetched 
	 * @return The requested list LearningDesign's in WDDX format
	 * @throws Exception
	 */
	public String requestLearningDesignWDDX(User user) throws IOException;
	
	/**
	 * This method saves the information which comes in WDDX format 
	 * into the database. It returns An acknowledgemnet message 
	 * telling FLASH the status of the operation, i.e. whether the 
	 * design has been successfully saved or not. If Yes it returns 
	 * the learning_design_id of the design just saved. This information
	 * is sent back in a format understood by FLASH, WDDX.
	 * 
	 * @param wddxPacket The WDDX packet to be stored in the database
	 * @return String The acknowledgemnet message 
	 * @throws Exception
	 */
	public String storeWDDXData(String wddxPacket)throws Exception;

}
