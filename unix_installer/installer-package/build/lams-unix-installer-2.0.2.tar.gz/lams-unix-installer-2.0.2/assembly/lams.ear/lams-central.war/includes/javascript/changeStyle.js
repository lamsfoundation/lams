<!--
	function changeStyle(obj, new_style) { 
		obj.className=new_style;
	}
//-->
