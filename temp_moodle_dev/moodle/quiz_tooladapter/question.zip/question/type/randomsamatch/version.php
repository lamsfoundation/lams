<?PHP // $Id: version.php,v 1.3.2.1 2007/11/02 16:20:48 tjhunt Exp $

$plugin->version  = 2006042800;
$plugin->requires = 2007101000;

?>
