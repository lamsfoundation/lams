<?PHP // $Id: version.php,v 1.7.2.1 2007/11/02 16:20:34 tjhunt Exp $

$plugin->version  = 2007081700;
$plugin->requires = 2007101000;

?>
