<?PHP // $Id: version.php,v 1.2.2.2 2008/05/09 15:50:45 tjhunt Exp $

$plugin->version  = 2008050800;
$plugin->requires = 2007101509;

?>
