<?PHP // $Id: version.php,v 1.3.2.1 2007/11/02 16:21:05 tjhunt Exp $

$plugin->version  = 2006121500;
$plugin->requires = 2007101000;

?>
