<?PHP // $Id: version.php,v 1.3 2008/09/18 00:02:16 jliew Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of lamstwo
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2008091800;  // The current module version (Date: YYYYMMDDXX)
$module->requires = 2007021400;  // Requires this Moodle version (1.8)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
