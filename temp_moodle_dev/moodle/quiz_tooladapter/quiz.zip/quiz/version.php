<?php // $Id: version.php,v 1.128.2.3 2008/08/19 21:39:05 skodak Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the version of quiz
//  This fragment is called by moodle_needs_upgrading() and /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2007101510;   // The (date) version of this module
$module->requires = 2007101509;   // Requires this Moodle version
$module->cron     = 0;            // How often should cron check this module (seconds)?

?>
