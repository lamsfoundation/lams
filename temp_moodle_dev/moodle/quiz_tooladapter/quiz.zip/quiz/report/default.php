<?php  // $Id: default.php,v 1.11.2.6 2008/02/29 21:44:08 nicolasconnault Exp $ 

////////////////////////////////////////////////////////////////////
/// Default class for report plugins                            
///                                                               
/// Doesn't do anything on it's own -- it needs to be extended.   
/// This class displays quiz reports.  Because it is called from 
/// within /mod/quiz/report.php you can assume that the page header
/// and footer are taken care of.
/// 
/// This file can refer to itself as report.php to pass variables 
/// to itself - all these will also be globally available.  You must 
/// pass "id=$cm->id" or q=$quiz->id", and "mode=reportname".
////////////////////////////////////////////////////////////////////

// Included by ../report.php
class quiz_default_report {

    function display($cm, $course, $quiz) {     /// This function just displays the report
        return true;
    }

    function print_header_and_tabs($cm, $course, $quiz, $reportmode="overview", $meta=""){
        global $CFG;
    /// Define some strings
        $strquizzes = get_string("modulenameplural", "quiz");
        $strquiz  = get_string("modulename", "quiz");
    /// Print the page header
        $navigation = build_navigation('', $cm);
    //if Lams we include a parameter to the header function so it won't we displayed
    print_header_simple(format_string($quiz->name), "", $navigation,
                     '', $meta, true, update_module_button($cm->id, $course->id, $strquiz), navmenu($course, $cm),false,'',false,$cm->is_lams);
	//old print_header_simple(format_string($quiz->name), "", $navigation,
                    // '', $meta, true, update_module_button($cm->id, $course->id, $strquiz), navmenu($course, $cm));
	    
    /// Print the tabs 

        $currenttab = 'reports';
        $mode = $reportmode;
        require($CFG->dirroot . '/mod/quiz/tabs.php');
        $course_context = get_context_instance(CONTEXT_COURSE, $course->id);
        if (has_capability('gradereport/grader:view', $course_context) && has_capability('moodle/grade:viewall', $course_context)) {
            //If is Lams we don't need to display 'see all course grades' 
            if($cm->is_lams!=1){
        	 echo '<div class="allcoursegrades"><a href="' . $CFG->wwwroot . '/grade/report/grader/index.php?id=' . $course->id . '">' 
                . get_string('seeallcoursegrades', 'grades') . '</a></div>';
            }
        }

    }
}

?>
