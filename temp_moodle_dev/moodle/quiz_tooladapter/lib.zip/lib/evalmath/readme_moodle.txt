Description of EvalMath library import into Moodle

Our changes:
* implicit multiplication not allowed
* new custom calc emulation functions
* removed e and pi constants - not use din calc
* removed sample files
* Fix a == FALSE that should have been === FALSE.

To see all changes diff against version 1.1, available from:
http://www.phpclasses.org/browse/package/2695.html

skodak, Tim Hunt