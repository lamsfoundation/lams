Description of HTML Purifier v2.1.5 Lite library import into Moodle

Changes:
 * HMLTModule/Text.php - added  <nolink>, <tex>, <lang> and <algebra> tags
 * HMLTModule/XMLCommonAttributes.php - remove xml:lang - needed for multilang
 * AttrDef/Lang.php - relax lang check - needed for multilang

skodak

$Id: readme_moodle.txt,v 1.4.2.4 2008/09/24 21:24:17 skodak Exp $
