Spreadsheet WriteExcel
----------------------

This software is under the LGPL license.

Homepage: http://freshmeat.net/projects/spreadsheet_writeexcel
