//$Id: ArithmeticNode.java,v 1.3 2005/04/13 07:51:46 oneovthafew Exp $
package org.hibernate.hql.ast;

import org.hibernate.Hibernate;
import org.hibernate.type.Type;

import antlr.SemanticException;

public class ArithmeticNode extends AbstractSelectExpression {

	public Type getDataType() {
		Type x = ( (SelectExpression) getFirstChild() ).getDataType();
		Type y = ( (SelectExpression) getFirstChild().getNextSibling() ).getDataType();
		if ( x==Hibernate.DOUBLE || y==Hibernate.DOUBLE ) return Hibernate.DOUBLE;
		if ( x==Hibernate.FLOAT || y==Hibernate.FLOAT ) return Hibernate.FLOAT;
		if ( x==Hibernate.BIG_DECIMAL || y==Hibernate.BIG_DECIMAL ) return Hibernate.BIG_DECIMAL;
		if ( x==Hibernate.BIG_INTEGER || y==Hibernate.BIG_INTEGER ) return Hibernate.BIG_DECIMAL;
		if ( x==Hibernate.LONG || y==Hibernate.LONG ) return Hibernate.LONG;
		if ( x==Hibernate.INTEGER || y==Hibernate.INTEGER ) return Hibernate.INTEGER;
		return x;
	}

	public void setScalarColumnText(int i) throws SemanticException {
		ColumnHelper.generateSingleScalarColumn( this, i );
	}

}
