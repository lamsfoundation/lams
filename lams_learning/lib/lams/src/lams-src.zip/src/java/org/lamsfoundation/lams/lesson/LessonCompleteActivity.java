/*
 * Created on 16/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.lamsfoundation.lams.lesson;

import org.lamsfoundation.lams.learningdesign.NullActivity;

/**
 * @author dgarth
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LessonCompleteActivity extends NullActivity {

}
