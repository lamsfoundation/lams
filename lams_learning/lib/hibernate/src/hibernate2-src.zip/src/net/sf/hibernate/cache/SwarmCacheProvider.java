//$Id: SwarmCacheProvider.java,v 1.7 2004/09/24 08:02:00 oneovthafew Exp $
package net.sf.hibernate.cache;

import java.util.Properties;

import net.sf.swarmcache.CacheConfiguration;
import net.sf.swarmcache.CacheConfigurationManager;
import net.sf.swarmcache.CacheFactory;
import net.sf.swarmcache.ObjectCache;

/**
 * Support for SwarmCache replicated cache. SwarmCache does not support
 * locking, so strict "read-write" semantics are unsupported.
 * @author Jason Carreira
 */
public class SwarmCacheProvider implements CacheProvider {

    public Cache buildCache(String regionName, Properties properties) throws CacheException {
        CacheConfiguration config = CacheConfigurationManager.getConfig(properties);
        CacheFactory factory = new CacheFactory(config);
        ObjectCache cache = factory.createCache(regionName);
        if (cache==null) throw new CacheException("SwarmCache did not create a cache: " + regionName);
        return new SwarmCache(cache);
    }

    public long nextTimestamp() {
        return System.currentTimeMillis() / 100;
    }

}
